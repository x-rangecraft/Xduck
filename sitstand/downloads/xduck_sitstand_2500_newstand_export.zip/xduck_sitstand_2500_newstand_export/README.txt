Xduck 新默认站姿 2500 轮导出包
xduck_sitstand_2500_newstand.onnx：确定性actor，输入obs float32[1,61]，输出actions float32[1,14]，opset17。
actor观测归一化关闭。policy_io.json中的默认角与限幅来自实际训练环境，已核对新站姿。
ONNX输出是原始动作，需做tanh、增量积分和限幅后才能成为关节目标，不要直接当目标位置。
策略关节顺序：左腿5、头部4、右腿5；硬件日志顺序：左腿5、右腿5、头部4。转换索引见policy_io。嘴部不在14维策略中。
策略接管时，用实际关节位置初始化积分目标；坐下/起立命令切换时保持积分状态，不要每周期重置。
posture命令0=站立/起立，1=坐下；两个剩余twist槽为0；头部偏移和六个body命令槽按61维布局填入。
参考数值函数见reference_adapter.py；它需要接入实际硬件API。控制周期20ms，GF参数未改。
默认新站姿、积分历史参考、限幅都要一起使用本包policy_io，不要混用旧2000包配置。
包含完整PT检查点、原训练配置、物理模型及GF源码快照。ONNX数值一致性证据见export_validation.json。
