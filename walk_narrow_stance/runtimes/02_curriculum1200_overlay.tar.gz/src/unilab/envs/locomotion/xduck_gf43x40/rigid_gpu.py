"""Current rigid asset adapter; historical rewards, sampler and motor unchanged."""
from dataclasses import dataclass
import mujoco
import numpy as np
from unilab.base import registry
from .velocity import XDuckGF43X40VelocityCfg, XDuckGF43X40VelocityEnv, XDuckDRProvider


@registry.envcfg('XDuckHistoricalRigid')
@dataclass
class HistoricalRigidCfg(XDuckGF43X40VelocityCfg):
    warp_compiled_model_file: str | None = None
    physics_microsteps: int = 1
    reset_root_z_offset_m: float = 0.
    audit_velocity: float | None = None
    sole_tilt_dr_enabled: bool = True
    sole_tilt_range_deg: tuple[float,float] = (-3.,3.)
    sole_tilt_seed: int = 20260929
    physical_action_scale_rad: list[float] | None = None
    stage_schedule_enabled: bool = False
    rollout_steps: int = 24
    reference_path: str | None = None
    reference_weight_after300: float = 0.45
    reference_height_std: float = 0.015
    reference_pitch_std: float = 0.2617993877991494
    dr_base_com_m: float = 0.00627
    dr_base_head_com_m: float = 0.00627
    dr_base_push_m_s: float = 0.4337049688440288
    dr_base_noise_level: float = 1.0
    dr_base_sole_tilt_deg: float = 3.0
    dr_base_armature_halfwidth: float = 0.1
    audit_twist: tuple[float,float,float] | None = None
    cadence_target_cycle_s: float = 0.5632857142856981
    cadence_cycle_std_s: float = 0.06
    cadence_weight_after300: float = 0.15
    target_walk_fraction_after300: float = 0.15
    target_walk_velocity_range: tuple[float,float] = (0.15,0.20)



class RigidModelReset(XDuckDRProvider):
    def _finalize_reset_pose(self,env,plan):
        plan=super()._finalize_reset_pose(env,plan)
        # Preserve the old random spawn-height interval relative to the new
        # model's nominal ground height. No per-reset geometry modification.
        plan.qpos[:,env._passive_qpos_indices]=0.
        plan.qpos[:,env._policy_qpos_indices]=np.clip(plan.qpos[:,env._policy_qpos_indices],env._reset_joint_limits[:,0]+.01,env._reset_joint_limits[:,1]-.01)
        plan.qpos[:,2]+=env.cfg.reset_root_z_offset_m
        return plan


@registry.env('XDuckHistoricalRigid',sim_backend='mjwarp')
@registry.env('XDuckHistoricalRigid',sim_backend='mujoco')
class HistoricalRigidEnv(XDuckGF43X40VelocityEnv):
    def _make_dr_provider(self):
        return StagedSoleTiltReset() if self._cfg.stage_schedule_enabled else SoleTiltReset()

    def _create_backend(self,cfg,num_envs,backend_type):
        if backend_type=='mujoco':
            if cfg.sole_tilt_dr_enabled:raise ValueError('Sole geometry DR is GPU-owned; disable it for CPU model compilation.')
            from unilab.base.backend import create_backend,env_backend_kwargs
            from unilab.actuators.gf43x40 import GF43X40Parameters
            p=GF43X40Parameters.from_bundle();m=mujoco.MjModel.from_xml_path(cfg.scene.model_file)
            ids=m.jnt_dofadr[m.actuator_trnid[:,0]]
            arm=m.dof_armature.copy();arm[ids]=p.physics['armature']
            damp=m.dof_damping.copy();damp[ids]=0
            friction=m.dof_frictionloss.copy();friction[ids]=0
            limit=p.physics['mechanical_torque_limit']
            return create_backend(backend_type,cfg.scene,num_envs,cfg.sim_dt,base_name=cfg.asset.base_name,
                push_body_name=cfg.domain_rand.push_body_name,add_body_sensors=True,
                position_actuator_gains={'kp':1.,'kd':0.},actuator_ctrl_range=(-limit-p.registers['pmax'],limit+p.registers['pmax']),
                actuator_force_range=(-limit,limit),dof_armature=arm,dof_damping=damp,dof_frictionloss=friction,**env_backend_kwargs(cfg))
        if backend_type!='mjwarp' or not cfg.warp_compiled_model_file or cfg.physics_microsteps!=1:
            raise ValueError('Historical rigid GPU requires a compiled model and 20 x 1ms mechanics')
        from unilab.base.backend.mjwarp.xduck_gf import XDuckGF43X40WarpBackend
        return XDuckGF43X40WarpBackend(cfg.scene,num_envs,cfg.sim_dt,
            compiled_model_file=cfg.warp_compiled_model_file,physics_microsteps=1,
            base_name=cfg.asset.base_name,push_body_name=cfg.domain_rand.push_body_name)

    def _sample_velocity_commands(self,count):
        if self._cfg.audit_twist is not None:return np.tile(self._cfg.audit_twist,(count,1))
        if self._cfg.audit_velocity is not None:return np.tile([self._cfg.audit_velocity,0.,0.],(count,1))
        cmd=super()._sample_velocity_commands(count)
        if self._cfg.stage_schedule_enabled and self.step_counter//self._cfg.rollout_steps>=300:
            mask=np.random.random(count)<self._cfg.target_walk_fraction_after300
            n=int(mask.sum());lo,hi=self._cfg.target_walk_velocity_range
            cmd[mask]=np.c_[np.random.uniform(lo,hi,n),np.zeros((n,2))]
        return cmd

    def _sample_head_commands(self,count):
        if self._cfg.audit_twist is not None:return np.zeros((count,4))
        if self._cfg.audit_velocity is None:return super()._sample_head_commands(count)
        return np.zeros((count,4))

    def _sample_body_commands(self,count):
        if self._cfg.audit_twist is not None:return np.zeros((count,6))
        if self._cfg.audit_velocity is None:return super()._sample_body_commands(count)
        return np.zeros((count,6))

    def __init__(self,cfg,num_envs=1,backend_type='mujoco'):
        self._dr_multiplier=1.0
        self._reference_weight=0.0
        self._cadence_weight=0.0
        self._cadence_last_touch_s=np.full((num_envs,2),-1e6)
        self._cadence_period_s=np.zeros((num_envs,2))
        self._cadence_previous_contact=np.zeros((num_envs,2),dtype=bool)
        self._dr_episode_multiplier=np.ones(num_envs)
        # Geometry is loaded only on the cold path. Flat-ground task only.
        m=mujoco.MjModel.from_xml_path(cfg.scene.model_file)
        floor=m.geom('floor').id
        assert m.geom_type[floor]==mujoco.mjtGeom.mjGEOM_PLANE
        self._ground_z=float(m.geom_pos[floor,2])
        self._active_names=[m.joint(j).name for j in m.actuator_trnid[:,0]]
        self._sole_rng=np.random.default_rng(cfg.sole_tilt_seed)
        self._sole_angles=np.zeros((num_envs,2))
        self._sole_delta_quat=np.zeros((num_envs,2,4));self._sole_delta_quat[:,:,0]=1
        d=mujoco.MjData(m);mujoco.mj_resetDataKeyframe(m,d,m.key('STAND').id);mujoco.mj_forward(m,d)
        self._sole_axes=[];self._sole_geom_centers=[]
        self._sole_vertices=[];body_names=[]
        self._sole_normals=[]
        self._sole_world_pitch=np.zeros((num_envs,2))
        self._reference=None
        if cfg.reference_path:
            with np.load(cfg.reference_path) as ref:self._reference={k:ref[k].copy() for k in ref.files}
            assert self._reference['height'].shape==(64,2) and self._reference['pitch'].shape==(64,2)
            assert np.all(self._reference['duration']>0)
        for side in ['left','right']:
            g=m.geom(side+'_foot_collision').id;k=m.geom_dataid[g]
            assert m.geom_type[g]==mujoco.mjtGeom.mjGEOM_MESH
            vertices=m.mesh_vert[m.mesh_vertadr[k]:m.mesh_vertadr[k]+m.mesh_vertnum[k]].copy()
            rot=np.empty(9);mujoco.mju_quat2Mat(rot,m.geom_quat[g])
            self._sole_vertices.append(vertices@rot.reshape(3,3).T+m.geom_pos[g])
            _,eig=np.linalg.eigh(np.cov(vertices.T));normal=rot.reshape(3,3)@eig[:,0]
            if (d.xmat[m.geom_bodyid[g]].reshape(3,3)@normal)[2]<0:normal=-normal
            self._sole_normals.append(normal)
            self._sole_axes.append(d.xmat[m.geom_bodyid[g]].reshape(3,3).T@d.xmat[1].reshape(3,3)[:,1])
            body_names.append(m.body(m.geom_bodyid[g]).name)
        self._sole_body_ids=np.array([m.body(name).id for name in body_names],dtype=np.int32)
        self._physical_scales=np.asarray(cfg.physical_action_scale_rad,dtype=float)
        assert self._physical_scales.shape==(14,) and np.all(self._physical_scales>0)
        self._actual_clip_fraction=0.
        super().__init__(cfg,num_envs=num_envs,backend_type=backend_type)
        self._sole_body_ids=np.array([self._backend.get_body_id(name) for name in body_names],dtype=np.int32)
        bm=mujoco.MjModel.from_binary_path(cfg.warp_compiled_model_file) if backend_type=='mjwarp' else self._backend.get_playback_model(0)
        self._nominal_geom_pos=bm.geom_pos.copy();self._nominal_geom_quat=bm.geom_quat.copy()
        self._sole_geom_ids=[self._backend.get_geom_id(side+'_foot_collision') for side in ['left','right']]
        self._foot_geom_ids=np.array([self._backend.get_geom_id(side+'_'+part+'_collision') for side in ['left','right'] for part in ['foot','ankle']],dtype=np.int32)

    def _refresh_foot_height(self):
        pos,quat=self._backend.get_body_pose_w(self._sole_body_ids)
        for j,vertices in enumerate(self._sole_vertices):
            q=quat[:,j,None,:];v=vertices[None,:,:]
            dq=self._sole_delta_quat[:,j,None,:]
            v=v+2*np.cross(dq[:,:,1:],np.cross(dq[:,:,1:],v)+dq[:,:,:1]*v)
            rotated=v+2*np.cross(q[:,:,1:],np.cross(q[:,:,1:],v)+q[:,:,:1]*v)
            self._foot_height[:,j]=np.maximum(0.,np.min(rotated[:,:,2],axis=1)+pos[:,j,2]-self._ground_z)
            n=np.broadcast_to(self._sole_normals[j],(self.num_envs,3));delta=self._sole_delta_quat[:,j]
            n=n+2*np.cross(delta[:,1:],np.cross(delta[:,1:],n)+delta[:,:1]*n)
            bodyq=quat[:,j];n=n+2*np.cross(bodyq[:,1:],np.cross(bodyq[:,1:],n)+bodyq[:,:1]*n)
            w,x,y,z=self._backend.get_base_quat().T
            yaw=np.arctan2(2*(w*z+x*y),1-2*(y*y+z*z))
            self._sole_world_pitch[:,j]=np.arctan2(np.cos(yaw)*n[:,0]+np.sin(yaw)*n[:,1],n[:,2])

    def _apply_stage_schedule(self):
        if not self._cfg.stage_schedule_enabled:return
        cfg=self._cfg;iteration=self.step_counter//cfg.rollout_steps
        self._cfg.reward_config.air_time_threshold_min=.1 if iteration<300 else (.14 if iteration<600 else (.18 if iteration<900 else .22))
        self._dr_multiplier=1.0 if iteration<300 else (1.5 if iteration<600 else (2.0 if iteration<900 else 2.5))
        self._reference_weight=0.0 if iteration<300 else cfg.reference_weight_after300
        self._cadence_weight=0.0 if iteration<300 else cfg.cadence_weight_after300
        m=self._dr_multiplier
        self._com_range=cfg.dr_base_com_m*m;self._head_com_range=cfg.dr_base_head_com_m*m
        cfg.domain_rand.velocity_push_xy=[-cfg.dr_base_push_m_s*m,cfg.dr_base_push_m_s*m]
        cfg.domain_rand.dof_armature_multiplier_range=[1-cfg.dr_base_armature_halfwidth*m,1+cfg.dr_base_armature_halfwidth*m]
        cfg.noise_config.level=cfg.dr_base_noise_level*m
        cfg.sole_tilt_range_deg=(-cfg.dr_base_sole_tilt_deg*m,cfg.dr_base_sole_tilt_deg*m)

    def _update_curriculum(self):
        super()._update_curriculum()
        self._apply_stage_schedule()

    def _reset_episode_history(self,env_ids):
        super()._reset_episode_history(env_ids)
        self._cadence_last_touch_s[env_ids]=-1e6
        self._cadence_period_s[env_ids]=0
        self._cadence_previous_contact[env_ids]=False

    def _cadence_component(self,state):
        now=self.step_counter*self._cfg.ctrl_dt
        touchdown=self._contact&(~self._cadence_previous_contact)&(self._landed_air_time>=.08)
        old=self._cadence_last_touch_s.copy()
        elapsed=now-old
        valid_touch=touchdown&(old>-1e5)
        self._cadence_period_s[valid_touch]=elapsed[valid_touch]
        self._cadence_last_touch_s[touchdown]=now
        self._cadence_previous_contact[:]=self._contact
        cmd=state.info['commands']
        gate=(cmd[:,0]>=.10)&(cmd[:,0]<=.25)&(np.abs(cmd[:,1])<.05)&(np.abs(cmd[:,2])<.1)
        supported=self._contact.sum(axis=1)==1
        period=self._cadence_period_s
        age=now-self._cadence_last_touch_s
        target=self._cfg.cadence_target_cycle_s
        valid=(period>.2)&(period<1.)&(age<=1.5*target)
        score=np.where(valid,np.exp(-((period-target)/self._cfg.cadence_cycle_std_s)**2),0.)
        value=np.sum(score,axis=1)/np.maximum(valid.sum(axis=1),1)
        value*=gate&supported
        log=state.info.setdefault('log',{})
        log['audit/cadence_score']=float(np.mean(value))
        if valid.any():log['audit/cadence_steps_per_s']=float(np.mean(2/period[valid]))
        return value

    def _compute_reward(self,state,linvel,gyro,upvector,dof_pos):
        cadence=self._cadence_component(state)
        reward=super()._compute_reward(state,linvel,gyro,upvector,dof_pos)
        if self._reference_weight==0:return reward
        ref=self._reference
        if ref is None:raise ValueError('A reference is required after300')
        h=np.empty_like(self._air_time);p=np.empty_like(self._air_time)
        for side in range(2):
            phase=np.clip(self._air_time[:,side]/ref['duration'][side],0,1)
            h[:,side]=np.interp(phase,ref['phase'],ref['height'][:,side])
            p[:,side]=np.interp(phase,ref['phase'],ref['pitch'][:,side])
        h_score=np.exp(-((self._foot_height-h)/self._cfg.reference_height_std)**2)
        p_score=np.exp(-((self._sole_world_pitch-p)/self._cfg.reference_pitch_std)**2)
        cmd=state.info['commands']
        moving=(np.linalg.norm(cmd[:,:2],axis=1)+np.abs(cmd[:,2]))>.01
        forward=(cmd[:,0]>.05)&(np.abs(cmd[:,1])<.05)&(np.abs(cmd[:,2])<.1)
        supported=(~self._contact)&self._contact[:,::-1]
        # Height is direction-independent. Pitch imitation is limited to the demonstrated straight-forward gait.
        value=np.sum((.5*h_score*moving[:,None]+.5*p_score*forward[:,None])*supported,axis=1)
        reward+=((self._reference_weight*value+self._cadence_weight*cadence)*self._cfg.ctrl_dt).astype(reward.dtype,copy=False)
        state.info.setdefault('log',{})['audit/reference_score']=float(np.mean(value))
        return reward

    def apply_action(self,actions,state):
        from .velocity import LocomotionBaseEnv
        raw=LocomotionBaseEnv.apply_action(self,actions,state)
        target=self.default_angles+(raw-self.default_angles)*self._physical_scales
        self._actual_clip_fraction=float(np.mean((target<self._target_low)|(target>self._target_high)))
        target=np.clip(target,self._target_low,self._target_high)
        self._previous_action_target[:]=self._current_action_target
        self._current_action_target[:]=target
        return target

    def _log_physical_audit(self,log,dof_vel,torque,action):
        super()._log_physical_audit(log,dof_vel,torque,action)
        log['audit/action_target_clip_fraction']=self._actual_clip_fraction
        log['curriculum/iteration']=float(self.step_counter//self._cfg.rollout_steps)
        log['curriculum/air_time_threshold_ms']=self._cfg.reward_config.air_time_threshold_min*1000
        log['curriculum/dr_multiplier']=self._dr_multiplier
        log['curriculum/reference_weight']=self._reference_weight
        log['curriculum/cadence_weight']=self._cadence_weight
        log['curriculum/dr_episode_min']=float(self._dr_episode_multiplier.min())
        log['curriculum/dr_episode_max']=float(self._dr_episode_multiplier.max())
        target=self._current_action_target
        log['audit/action_target_outside_hard_limit_fraction']=float(np.mean((target<self._joint_limits[:,0])|(target>self._joint_limits[:,1])))

    def _action_rate_cost(self,state):
        # Preserve the original 0.12-rad action unit while using actual targets.
        # Per-joint exploration scaling must not amplify the cost of hip sway.
        delta=(self._current_action_target-self._previous_action_target)/.12
        return np.sum(delta*delta,axis=1)

    def _init_buffers(self):
        super()._init_buffers()
        self._motor_pos_indices=self._backend.get_joint_dof_pos_indices(self._active_names)
        self._motor_vel_indices=self._backend.get_joint_dof_vel_indices(self._active_names)
        self._policy_qpos_indices=self._motor_pos_indices+7
        self._passive_qpos_indices=np.setdiff1d(np.arange(7,len(self._init_qpos)),self._policy_qpos_indices)
        self.default_angles=self._init_qpos[self._policy_qpos_indices].copy()

    def _get_policy_joint_range(self):
        return self._backend.get_joint_range()[self._motor_pos_indices]

    def get_dof_pos(self):
        return self._backend.get_dof_pos()[:,self._motor_pos_indices]

    def get_dof_vel(self):
        return self._backend.get_dof_vel()[:,self._motor_vel_indices]


class SoleTiltReset(RigidModelReset):
    def validate(self,env,capabilities):
        super().validate(env,capabilities)
        if env.cfg.sole_tilt_dr_enabled:
            assert capabilities.supports_reset_term('geom_pos') and capabilities.supports_reset_term('geom_quat')

    def build_reset_plan(self,env,env_ids):
        plan=super().build_reset_plan(env,env_ids)
        if not env.cfg.sole_tilt_dr_enabled:return plan
        from unilab.dr.types import ResetRandomizationPayload
        from unilab.utils.rotation import np_quat_mul
        n=len(env_ids);lo,hi=np.deg2rad(env.cfg.sole_tilt_range_deg)
        angles=env._sole_rng.uniform(lo,hi,(n,2))
        qp=np.broadcast_to(env._nominal_geom_pos,(n,*env._nominal_geom_pos.shape)).copy()
        qq=np.broadcast_to(env._nominal_geom_quat,(n,*env._nominal_geom_quat.shape)).copy()
        for j,g in enumerate(env._sole_geom_ids):
            theta=angles[:,j];axis=env._sole_axes[j]
            dq=np.c_[np.cos(theta/2),np.sin(theta/2)[:,None]*axis]
            v=qp[:,g].copy();u=dq[:,1:]
            qp[:,g]=v+2*np.cross(u,np.cross(u,v)+dq[:,:1]*v)
            qq[:,g]=np_quat_mul(dq,qq[:,g])
            env._sole_delta_quat[env_ids,j]=dq
        env._sole_angles[env_ids]=angles
        if plan.randomization is None:plan.randomization=ResetRandomizationPayload()
        plan.randomization.geom_pos=qp;plan.randomization.geom_quat=qq
        plan.info_updates['sole_tilt_deg']=np.rad2deg(angles)
        return plan


class StagedSoleTiltReset(SoleTiltReset):
    def build_reset_plan(self,env,env_ids):
        env._apply_stage_schedule();plan=super().build_reset_plan(env,env_ids);m=env._dr_multiplier
        ratio=1+(env._mass_inertia_scale[env_ids]-1)*m
        plan.randomization.body_mass[:,env._trunk_body_id]=env._base_body_mass[env._trunk_body_id]*ratio
        plan.randomization.body_inertia[:,env._trunk_body_id,:]=env._base_body_inertia[env._trunk_body_id,:]*ratio[:,None]
        if env.cfg.domain_rand.randomize_foot_friction:
            mu=1+(env._foot_friction[env_ids]-1)*m
            plan.randomization.geom_friction[:,env._foot_geom_ids,0]=mu[:,None]
        env._dr_episode_multiplier[env_ids]=m;plan.info_updates['dr_multiplier']=m
        return plan
