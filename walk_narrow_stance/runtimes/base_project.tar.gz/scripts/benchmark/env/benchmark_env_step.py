"""Benchmark env.step performance for a given task and backend.

Usage:
    # Run all task-side benchmark specs over their benchmark backends:
    uv run scripts/benchmark/env/benchmark_env_step.py

    # Single task + backend:
    uv run scripts/benchmark/env/benchmark_env_step.py task=g1_walk_flat/motrix
    uv run scripts/benchmark/env/benchmark_env_step.py task=g1_walk_rough/mujoco

    # mjwarp backend (Phase 1: g1_walk_flat only) requires extra deps:
    uv run --with mujoco-warp --with warp-lang \\
        scripts/benchmark/env/benchmark_env_step.py task=g1_walk_flat/mjwarp

    # Override bench params:
    uv run scripts/benchmark/env/benchmark_env_step.py task=go1_joystick_flat/mujoco num_envs=4096 num_steps=500

    # Save to custom locations:
    uv run scripts/benchmark/env/benchmark_env_step.py --out-json tmp/env_step.json --plot-dir tmp/env_step_plots
"""

import importlib.util
import json
import subprocess
import sys
import tempfile
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any, cast

import numpy as np

plt: Any = None
mpatches: Any = None

try:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.patches as _mpatches
    import matplotlib.pyplot as _plt

    mpatches = _mpatches
    plt = _plt
except Exception:
    pass

ROOT_DIR = Path(__file__).resolve().parents[3]
CORE_DIR = ROOT_DIR / "scripts" / "benchmark" / "core"
DEFAULT_OUTPUT_JSON = ROOT_DIR / "scripts" / "benchmark" / "outputs" / "env_step" / "results.json"


def _load_helper_module(module_name: str, relative_path: str):
    spec = importlib.util.spec_from_file_location(module_name, CORE_DIR / relative_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Failed to load helper module {module_name} from {relative_path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


_DEVICE_INFO = _load_helper_module("bench_env_step_device_info", "device_info.py")
_MEM_PROFILE = _load_helper_module("bench_env_step_mem_profile", "mem_profile.py")
_OUTPUT = _load_helper_module("bench_env_step_output", "output.py")

get_device_info_dict = _DEVICE_INFO.get_device_info_dict
get_device_info_line = _DEVICE_INFO.get_device_info_line
MEMORY_METRICS = _MEM_PROFILE.MEMORY_METRICS
_build_memory_summary = _MEM_PROFILE.build_memory_summary
_format_mb = _MEM_PROFILE.format_mb
_mb = _MEM_PROFILE.mb
_memory_snapshot = _MEM_PROFILE.memory_snapshot
save_json = _OUTPUT.save_json


def _install_mjwarp_patch() -> bool:
    """Route ``backend_type == "mjwarp"`` to ``scripts/benchmark/mjwarp`` via factory patch.

    Must run before any task env module (e.g. ``unilab.envs.locomotion.g1.joystick``)
    is imported, because those modules bind ``create_backend`` at module load
    time via ``from unilab.base.backend import create_backend``.

    Returns True if ``mujoco_warp`` + ``warp`` are importable, False otherwise.
    Idempotent.
    """
    try:
        import mujoco_warp  # noqa: F401
        import warp  # noqa: F401
    except ImportError:
        return False

    import unilab.base.backend as _ub_backend

    if getattr(_ub_backend, "_mjwarp_patched", False):
        return True

    # scripts/benchmark/ is not an installed package, so we load the adapter the same
    # way device_info/mem_profile/output are loaded above (importlib by path).
    mjwarp_backend_module = _load_helper_module(
        "bench_env_step_mjwarp_backend",
        "../mjwarp/backend.py",
    )
    mjwarp_backend_cls = mjwarp_backend_module.MjwarpBackend

    _orig_create_backend = _ub_backend.create_backend

    def _patched_create_backend(backend_type, scene, num_envs, sim_dt, **kwargs):
        if backend_type == "mjwarp":
            # Strip kwargs that only apply to other backends so MjwarpBackend's
            # signature stays narrow.
            kwargs.pop("motrix_max_iterations", None)
            return mjwarp_backend_cls(scene, num_envs, sim_dt, **kwargs)
        return _orig_create_backend(backend_type, scene, num_envs, sim_dt, **kwargs)

    _ub_backend.create_backend = _patched_create_backend
    _ub_backend._mjwarp_patched = True
    return True


MJWARP_AVAILABLE = _install_mjwarp_patch()

BACKENDS = ["mujoco", "motrix", "mjwarp"]


@dataclass(frozen=True)
class TaskConfig:
    task_id: str
    env_name: str
    cfg_factory: Callable[[str, list[str]], Any]
    env_cls_factory: Callable[[], type]
    backends: tuple[str, ...] = ("mujoco", "motrix")
    aliases: tuple[str, ...] = ()
    cfg_finalizer: Callable[[Any, str], None] | None = None
    include_in_matrix: bool = True

    def build_cfg(self, backend: str, config_overrides: list[str] | None = None) -> Any:
        return self.cfg_factory(backend, config_overrides or [])

    def finalize_cfg(self, cfg: Any, backend: str) -> None:
        if self.cfg_finalizer is not None:
            self.cfg_finalizer(cfg, backend)

    def matches_task_path(self, task_path: str) -> bool:
        return task_path in {self.task_id, self.env_name, *self.aliases}


def _owner_yaml_cfg(
    *,
    config_root: str,
    algo_name: str,
    overrides: list[str],
    config_overrides: list[str],
    env_cfg_cls: Callable[[], Any],
) -> Any:
    from hydra import compose, initialize_config_dir
    from hydra.core.global_hydra import GlobalHydra

    from unilab.base.registry import apply_cfg_overrides
    from unilab.training import BackendAdapter

    GlobalHydra.instance().clear()
    with initialize_config_dir(config_dir=str(ROOT_DIR / "conf" / config_root), version_base="1.3"):
        owner_cfg = compose(
            config_name="config",
            overrides=[
                *overrides,
                *config_overrides,
                "hydra.run.dir=.",
                "hydra.output_subdir=null",
                "hydra/job_logging=disabled",
                "hydra/hydra_logging=disabled",
            ],
        )

    env_cfg_override = BackendAdapter(
        owner_cfg,
        root_dir=ROOT_DIR,
        algo_name=algo_name,
    ).build_task_env_cfg_override()

    cfg = env_cfg_cls()
    apply_cfg_overrides(cfg, env_cfg_override)
    return cfg


# Backends that do not own a task YAML reuse the mujoco YAML during cfg
# composition. The actual backend selection happens later when the env
# constructs its SimBackend via the (monkey-patched) create_backend factory.
_HYDRA_YAML_BACKEND_ALIAS = {"mjwarp": "mujoco"}


def _hydra_yaml_backend(backend: str) -> str:
    return _HYDRA_YAML_BACKEND_ALIAS.get(backend, backend)


def _ppo_owner_yaml_cfg(
    task_id: str,
    backend: str,
    env_cfg_cls: Callable[[], Any],
    config_overrides: list[str],
) -> Any:
    yaml_backend = _hydra_yaml_backend(backend)
    return _owner_yaml_cfg(
        config_root="ppo",
        algo_name="ppo",
        overrides=[f"task={task_id}/{yaml_backend}"],
        config_overrides=config_overrides,
        env_cfg_cls=env_cfg_cls,
    )


def _sac_owner_yaml_cfg(
    task_id: str,
    backend: str,
    env_cfg_cls: Callable[[], Any],
    config_overrides: list[str],
) -> Any:
    yaml_backend = _hydra_yaml_backend(backend)
    return _owner_yaml_cfg(
        config_root="offpolicy",
        algo_name="sac",
        overrides=["algo=sac", f"task=sac/{task_id}/{yaml_backend}"],
        config_overrides=config_overrides,
        env_cfg_cls=env_cfg_cls,
    )


def _materialize_g1_rough_benchmark_scene() -> str:
    import shutil
    import xml.etree.ElementTree as ET

    source_dir = ROOT_DIR / "src" / "unilab" / "assets" / "robots" / "g1"
    output_dir = Path("/tmp/unilab_benchmark_g1_rough_scene")
    output_dir.mkdir(parents=True, exist_ok=True)

    for name in ("g1.xml",):
        shutil.copy2(source_dir / name, output_dir / name)
    for name in ("assets", "textures", "hfields"):
        shutil.copytree(source_dir / name, output_dir / name, dirs_exist_ok=True)

    tree = ET.parse(source_dir / "scene_rough.xml")
    hfield = tree.getroot().find("./asset/hfield[@name='hfield']")
    if hfield is not None:
        hfield.set("file", "hfields/hfield.png")
    output_path = output_dir / "scene_rough.xml"
    tree.write(output_path)
    return str(output_path)


def _materialize_sharpa_motrix_scene() -> str:
    import xml.etree.ElementTree as ET

    source_dir = ROOT_DIR / "src" / "unilab" / "assets" / "robots" / "sharpa_wave"
    output_dir = Path("/tmp/unilab_benchmark_sharpa_scene")
    output_dir.mkdir(parents=True, exist_ok=True)

    robot_tree = ET.parse(source_dir / "right_sharpa_wave.xml")
    robot_root = robot_tree.getroot()
    compiler = robot_root.find("compiler")
    if compiler is not None:
        compiler.set("meshdir", str((source_dir / "meshes").resolve()))

    contact = robot_root.find("contact")
    if contact is not None:
        for exclude in list(contact.findall("exclude")):
            if exclude.get("body1") == exclude.get("body2"):
                contact.remove(exclude)
    robot_tree.write(output_dir / "right_sharpa_wave.xml")

    scene_tree = ET.parse(source_dir / "scene.xml")
    output_path = output_dir / "scene.xml"
    scene_tree.write(output_path)
    return str(output_path)


def _go1_cfg(backend: str, config_overrides: list[str]) -> Any:
    from unilab.envs.locomotion.go1.joystick import Go1JoystickCfg

    return _ppo_owner_yaml_cfg("go1_joystick_flat", backend, Go1JoystickCfg, config_overrides)


def _go1_env_cls() -> type:
    from unilab.envs.locomotion.go1.joystick import Go1WalkTask

    return Go1WalkTask


def _go2_cfg(backend: str, config_overrides: list[str]) -> Any:
    from unilab.envs.locomotion.go2.joystick import Go2JoystickCfg

    return _ppo_owner_yaml_cfg("go2_joystick_flat", backend, Go2JoystickCfg, config_overrides)


def _go2_env_cls() -> type:
    from unilab.envs.locomotion.go2.joystick import Go2WalkTask

    return Go2WalkTask


def _go2_rough_cfg(backend: str, config_overrides: list[str]) -> Any:
    from unilab.envs.locomotion.go2.rough import Go2JoystickRoughCfg

    return _ppo_owner_yaml_cfg("go2_joystick_rough", backend, Go2JoystickRoughCfg, config_overrides)


def _go2_rough_env_cls() -> type:
    from unilab.envs.locomotion.go2.rough import Go2JoystickRoughEnv

    return Go2JoystickRoughEnv


def _go2w_cfg(backend: str, config_overrides: list[str]) -> Any:
    from unilab.envs.locomotion.go2w.joystick import Go2WJoystickCfg

    return _ppo_owner_yaml_cfg("go2w_joystick_flat", backend, Go2WJoystickCfg, config_overrides)


def _go2w_rough_cfg(backend: str, config_overrides: list[str]) -> Any:
    from unilab.envs.locomotion.go2w.rough import Go2WJoystickRoughCfg

    return _ppo_owner_yaml_cfg(
        "go2w_joystick_rough", backend, Go2WJoystickRoughCfg, config_overrides
    )


def _go2w_env_cls() -> type:
    from unilab.envs.locomotion.go2w.joystick import Go2WJoystickEnv

    return Go2WJoystickEnv


def _go2w_rough_env_cls() -> type:
    from unilab.envs.locomotion.go2w.rough import Go2WJoystickRoughEnv

    return Go2WJoystickRoughEnv


def _g1_flat_cfg(backend: str, config_overrides: list[str]) -> Any:
    from unilab.envs.locomotion.g1.joystick import G1WalkFlatCfg

    return _ppo_owner_yaml_cfg("g1_walk_flat", backend, G1WalkFlatCfg, config_overrides)


def _g1_rough_cfg(backend: str, config_overrides: list[str]) -> Any:
    from unilab.envs.locomotion.g1.joystick import G1WalkRoughCfg

    return _sac_owner_yaml_cfg("g1_walk_rough", backend, G1WalkRoughCfg, config_overrides)


def _g1_motion_tracking_cfg(backend: str, config_overrides: list[str]) -> Any:
    from unilab.envs.motion_tracking.g1.tracking import G1MotionTrackingEnvCfg

    return _ppo_owner_yaml_cfg(
        "g1_motion_tracking",
        backend,
        G1MotionTrackingEnvCfg,
        config_overrides,
    )


def _sharpa_inhand_cfg(backend: str, config_overrides: list[str]) -> Any:
    from hydra import compose, initialize_config_dir
    from hydra.core.global_hydra import GlobalHydra

    from unilab.base.registry import apply_cfg_overrides
    from unilab.envs.manipulation.sharpa_inhand.rotation import SharpaInhandRotationCfg
    from unilab.training import BackendAdapter

    yaml_backend = _hydra_yaml_backend(backend)
    GlobalHydra.instance().clear()
    with initialize_config_dir(config_dir=str(ROOT_DIR / "conf" / "ppo"), version_base="1.3"):
        owner_cfg = compose(
            config_name="config",
            overrides=[
                f"task=sharpa_inhand/{yaml_backend}",
                "env.grasp_cache_path=/tmp/unilab_benchmark_sharpa_grasp",
                *config_overrides,
                "hydra.run.dir=.",
                "hydra.output_subdir=null",
                "hydra/job_logging=disabled",
                "hydra/hydra_logging=disabled",
            ],
        )

    env_cfg_override = BackendAdapter(
        owner_cfg,
        root_dir=ROOT_DIR,
        algo_name="ppo",
    ).build_task_env_cfg_override()

    cfg = SharpaInhandRotationCfg()
    apply_cfg_overrides(cfg, env_cfg_override)
    return cfg


def _ensure_sharpa_benchmark_grasp_cache(cfg: Any, _: str) -> None:
    from unilab.envs.manipulation.sharpa_inhand.base import (
        SOURCE_DEFAULT_HAND_JOINT_POS_DEG,
        resolve_grasp_cache_file,
    )

    if not str(cfg.grasp_cache_path).startswith("/tmp/unilab_benchmark_sharpa_grasp"):
        return

    hand_qpos = np.deg2rad(np.asarray(SOURCE_DEFAULT_HAND_JOINT_POS_DEG, dtype=np.float64))
    object_height = 0.5 * (float(cfg.reset_height_lower) + float(cfg.reset_height_upper))
    object_pose = np.asarray([0.0, 0.0, object_height, 1.0, 0.0, 0.0, 0.0], dtype=np.float64)
    cache_row = np.concatenate([hand_qpos, object_pose], axis=0)

    for scale_value in np.asarray(cfg.domain_rand.scale_list, dtype=np.float64):
        cache_file = resolve_grasp_cache_file(cfg.grasp_cache_path, float(scale_value))
        cache_file.parent.mkdir(parents=True, exist_ok=True)
        np.save(cache_file, cache_row[None, :])


def _g1_walk_env_cls() -> type:
    from unilab.envs.locomotion.g1.joystick import G1WalkEnv

    return G1WalkEnv


def _g1_motion_tracking_env_cls() -> type:
    from unilab.envs.motion_tracking.g1.tracking import G1MotionTrackingEnv

    return G1MotionTrackingEnv


def _sharpa_inhand_env_cls() -> type:
    from unilab.envs.manipulation.sharpa_inhand.rotation import SharpaInhandRotationEnv

    return SharpaInhandRotationEnv


TASK_CONFIGS: dict[str, TaskConfig] = {
    "go1": TaskConfig(
        task_id="go1_joystick_flat",
        env_name="Go1JoystickFlat",
        cfg_factory=_go1_cfg,
        env_cls_factory=_go1_env_cls,
        backends=("mujoco", "motrix", "mjwarp"),
    ),
    "go2": TaskConfig(
        task_id="go2_joystick_flat",
        env_name="Go2JoystickFlat",
        cfg_factory=_go2_cfg,
        env_cls_factory=_go2_env_cls,
        backends=("mujoco", "motrix", "mjwarp"),
    ),
    "go2_rough": TaskConfig(
        task_id="go2_joystick_rough",
        env_name="Go2JoystickRough",
        cfg_factory=_go2_rough_cfg,
        env_cls_factory=_go2_rough_env_cls,
        backends=("mujoco", "motrix", "mjwarp"),
    ),
    "go2w": TaskConfig(
        task_id="go2w_joystick_flat",
        env_name="Go2WJoystickFlat",
        cfg_factory=_go2w_cfg,
        env_cls_factory=_go2w_env_cls,
        backends=("mujoco", "motrix", "mjwarp"),
    ),
    "go2w_rough": TaskConfig(
        task_id="go2w_joystick_rough",
        env_name="Go2WJoystickRough",
        cfg_factory=_go2w_rough_cfg,
        env_cls_factory=_go2w_rough_env_cls,
        backends=("mujoco", "motrix", "mjwarp"),
    ),
    "g1": TaskConfig(
        task_id="g1_walk_flat",
        env_name="G1WalkFlat",
        cfg_factory=_g1_flat_cfg,
        env_cls_factory=_g1_walk_env_cls,
        backends=("mujoco", "motrix", "mjwarp"),
    ),
    "g1_rough": TaskConfig(
        task_id="g1_walk_rough",
        env_name="G1WalkRough",
        cfg_factory=_g1_rough_cfg,
        env_cls_factory=_g1_walk_env_cls,
        aliases=("sac/g1_walk_rough",),
        backends=("mujoco", "motrix", "mjwarp"),
    ),
    "g1_mt": TaskConfig(
        task_id="g1_motion_tracking",
        env_name="G1MotionTracking",
        cfg_factory=_g1_motion_tracking_cfg,
        env_cls_factory=_g1_motion_tracking_env_cls,
        backends=("mujoco", "motrix", "mjwarp"),
    ),
    "sharpa_inhand": TaskConfig(
        task_id="sharpa_inhand",
        env_name="SharpaInhandRotation",
        cfg_factory=_sharpa_inhand_cfg,
        env_cls_factory=_sharpa_inhand_env_cls,
        cfg_finalizer=_ensure_sharpa_benchmark_grasp_cache,
        backends=("mujoco", "motrix", "mjwarp"),
    ),
}

# Default benchmark parameters
DEFAULT_NUM_ENVS = 2048
DEFAULT_NUM_STEPS = 20
DEFAULT_WARMUP_STEPS = 5

TASK_COLORS = {
    "go1": "#4C78A8",
    "go2": "#54A24B",
    "go2_rough": "#8CD17D",
    "g1": "#F58518",
    "g1_mt": "#B279A2",
    "g1_rough": "#E45756",
    "go2w": "#72B7B2",
    "go2w_rough": "#499894",
    "go2w_rough_tiles": "#499894",
    "sharpa_inhand": "#D37295",
}
BACKEND_STYLES = {
    "mujoco": {"marker": "o", "linestyle": "-", "hatch": "//"},
    "motrix": {"marker": "s", "linestyle": "--", "hatch": "xx"},
    "mjwarp": {"marker": "^", "linestyle": ":", "hatch": ".."},
}
BACKEND_TICK_LABELS = {
    "mujoco": "mj",
    "motrix": "mx",
    "mjwarp": "wp",
}
BREAKDOWN_SEGMENTS = [
    ("apply_action_ms", "apply_action", "#4C78A8"),
    ("backend_set_ctrl_ms", "set_ctrl", "#F58518"),
    ("backend_physics_ms", "physics", "#54A24B"),
    ("backend_refresh_cache_ms", "refresh_cache", "#E45756"),
    ("step_core_other_ms", "step_core_other", "#9D755D"),
    ("update_state_ms", "update_state", "#72B7B2"),
    ("reset_done_ms", "reset_done", "#B279A2"),
    ("env_step_other_ms", "env_step_other", "#BAB0AC"),
]


def _is_matrix_mode(argv: list[str]) -> bool:
    """Return True when user didn't specify task or backend explicitly."""
    for arg in argv:
        if arg.startswith("task=") or arg.startswith("training.sim_backend="):
            return False
    return True


def _parse_cli_args(args: list[str]) -> tuple[dict[str, str], dict[str, Any], list[str]]:
    """Parse benchmark/output args and return (bench_kwargs, output_kwargs, hydra_overrides).

    Benchmark args:
        num_envs=XXX, num_steps=XXX, warmup_steps=XXX
    Output args:
        --out-json PATH / --out-json=PATH / out_json=PATH
        --plot-dir PATH / --plot-dir=PATH / plot_dir=PATH
        --skip-plots / skip_plots=true|false

    Non-Hydra args are extracted before config composition.
    """
    bench_kwargs: dict[str, str] = {}
    output_kwargs: dict[str, Any] = {
        "out_json": None,
        "plot_dir": None,
        "skip_plots": False,
    }
    hydra_overrides: list[str] = []

    i = 0
    while i < len(args):
        arg = args[i]
        if arg.startswith("num_envs="):
            bench_kwargs["num_envs"] = arg.split("=", 1)[1]
        elif arg.startswith("num_steps="):
            bench_kwargs["num_steps"] = arg.split("=", 1)[1]
        elif arg.startswith("warmup_steps="):
            bench_kwargs["warmup_steps"] = arg.split("=", 1)[1]
        elif arg.startswith("out_json="):
            output_kwargs["out_json"] = arg.split("=", 1)[1]
        elif arg.startswith("plot_dir="):
            output_kwargs["plot_dir"] = arg.split("=", 1)[1]
        elif arg.startswith("skip_plots="):
            output_kwargs["skip_plots"] = arg.split("=", 1)[1].lower() in {
                "1",
                "true",
                "yes",
                "on",
            }
        elif arg == "--out-json":
            i += 1
            if i >= len(args):
                raise ValueError("--out-json requires a path")
            output_kwargs["out_json"] = args[i]
        elif arg.startswith("--out-json="):
            output_kwargs["out_json"] = arg.split("=", 1)[1]
        elif arg == "--plot-dir":
            i += 1
            if i >= len(args):
                raise ValueError("--plot-dir requires a path")
            output_kwargs["plot_dir"] = args[i]
        elif arg.startswith("--plot-dir="):
            output_kwargs["plot_dir"] = arg.split("=", 1)[1]
        elif arg == "--skip-plots":
            output_kwargs["skip_plots"] = True
        else:
            hydra_overrides.append(arg)
        i += 1

    return bench_kwargs, output_kwargs, hydra_overrides


def _split_task_choice(task_choice: str) -> tuple[str, str | None]:
    """Return (task path without backend, backend if present)."""
    normalized = task_choice.strip()
    if normalized.startswith("task="):
        normalized = normalized.split("=", 1)[1]
    for backend in BACKENDS:
        suffix = f"/{backend}"
        if normalized.endswith(suffix):
            return normalized[: -len(suffix)], backend
    return normalized, None


def _matching_task_config(task_path: str) -> TaskConfig | None:
    for task_config in TASK_CONFIGS.values():
        if task_config.matches_task_path(task_path):
            return task_config
    return None


def _resolve_task_and_backend(hydra_overrides: list[str]) -> tuple[str, TaskConfig, str]:
    """Resolve the benchmark owner selected by ``task=<task>/<backend>``."""
    task_key = "go1"
    task_config = TASK_CONFIGS[task_key]
    sim_backend: str | None = None

    for arg in hydra_overrides:
        if arg.startswith("task="):
            task_path, backend = _split_task_choice(arg)
            matched = _matching_task_config(task_path)
            if matched is None:
                available = ", ".join(task_config.task_id for task_config in TASK_CONFIGS.values())
                raise ValueError(f"Unknown benchmark task {task_path!r}. Available: {available}")
            task_config = matched
            task_key = next(
                key for key, candidate in TASK_CONFIGS.items() if candidate is task_config
            )
            sim_backend = backend or sim_backend
        elif arg.lstrip("+").startswith("training.sim_backend="):
            raise ValueError(
                "Do not switch benchmark backends with training.sim_backend; "
                "select the backend owner with task=<task>/<backend>."
            )

    if sim_backend is None:
        sim_backend = task_config.backends[0]
    if sim_backend not in task_config.backends:
        supported = ", ".join(task_config.backends)
        raise ValueError(
            f"Benchmark task {task_config.task_id!r} supports backend(s) {supported}; "
            f"got {sim_backend!r}."
        )
    return task_key, task_config, sim_backend


def _owner_config_overrides(hydra_overrides: list[str]) -> list[str]:
    config_overrides: list[str] = []
    for arg in hydra_overrides:
        key = arg.split("=", 1)[0].lstrip("+~")
        if key == "task":
            continue
        if key == "training.sim_backend":
            raise ValueError(
                "Do not switch benchmark backends with training.sim_backend; "
                "select the backend owner with task=<task>/<backend>."
            )
        if key.startswith(("env.", "reward.")):
            config_overrides.append(arg)
            continue
        raise ValueError(
            f"Unsupported benchmark config override {arg!r}; "
            "only task=..., env.* and reward.* are accepted."
        )
    return config_overrides


def _run_single(extra_args: list[str]) -> dict[str, Any]:
    """Run a single task-side benchmark and return timing records."""
    bench_kwargs, _, hydra_overrides = _parse_cli_args(extra_args)
    _, task_config, sim_backend = _resolve_task_and_backend(hydra_overrides)
    config_overrides = _owner_config_overrides(hydra_overrides)

    num_envs = int(bench_kwargs.get("num_envs", DEFAULT_NUM_ENVS))
    num_steps = int(bench_kwargs.get("num_steps", DEFAULT_NUM_STEPS))
    warmup_steps = int(bench_kwargs.get("warmup_steps", DEFAULT_WARMUP_STEPS))

    cfg = task_config.build_cfg(sim_backend, config_overrides)
    task_config.finalize_cfg(cfg, sim_backend)
    cfg.validate()

    env = None
    timing_records: dict[str, list[float]] = {}
    memory_samples: dict[str, dict[str, Any]] = {}
    try:
        memory_samples["before_env"] = _memory_snapshot("before_env")
        env_cls = task_config.env_cls_factory()
        env = env_cls(cfg, num_envs=num_envs, backend_type=sim_backend)

        nu = env._backend.num_actuators  # type: ignore[reportAttributeAccessIssue]
        env.init_state()

        for _ in range(warmup_steps):
            actions = np.random.uniform(-1, 1, size=(num_envs, nu)).astype(np.float32)
            env.step(actions)

        for _ in range(num_steps):
            actions = np.random.uniform(-1, 1, size=(num_envs, nu)).astype(np.float32)
            state = env.step(actions)
            timing = state.info.get("timing", {})
            for k, v in timing.items():
                timing_records.setdefault(k, []).append(float(v))
        memory_samples["after_benchmark"] = _memory_snapshot("after_benchmark")
    finally:
        if env is not None:
            env.close()
            memory_samples["after_close"] = _memory_snapshot("after_close")

    return {
        "task_name": task_config.env_name,
        "sim_backend": str(sim_backend),
        "num_envs": num_envs,
        "num_steps": num_steps,
        "warmup_steps": warmup_steps,
        "timing_records": timing_records,
        "memory": _build_memory_summary(memory_samples, num_envs),
    }


def _result_label(result: dict[str, Any]) -> str:
    return (
        f"{result.get('task_key', _short_task_label(result['task_name']))}/{result['sim_backend']}"
    )


def _compute_result_summary(result: dict[str, Any]) -> dict[str, Any]:
    tr = result["timing_records"]
    total_arr = np.array(tr.get("env_step_total_ms", []), dtype=np.float64)
    total_s = float(total_arr.sum() / 1000.0)
    steps_per_env = result["num_steps"] * result["num_envs"]
    throughput = float(steps_per_env / total_s) if total_s > 0 else 0.0

    summary: dict[str, Any] = {
        "label": _result_label(result),
        "total_time_s": total_s,
        "mean_step_ms": float(total_arr.mean()) if total_arr.size else 0.0,
        "median_step_ms": float(np.median(total_arr)) if total_arr.size else 0.0,
        "std_step_ms": float(total_arr.std()) if total_arr.size else 0.0,
        "min_step_ms": float(total_arr.min()) if total_arr.size else 0.0,
        "max_step_ms": float(total_arr.max()) if total_arr.size else 0.0,
        "throughput_env_steps_per_s": throughput,
        "timing_mean_ms": {},
        "timing_median_ms": {},
        "memory": result.get("memory", {}),
    }
    for key, values in tr.items():
        arr = np.array(values, dtype=np.float64)
        summary["timing_mean_ms"][key] = float(arr.mean()) if arr.size else 0.0
        summary["timing_median_ms"][key] = float(np.median(arr)) if arr.size else 0.0
    return summary


def _serialize_result(result: dict[str, Any]) -> dict[str, Any]:
    summary = _compute_result_summary(result)
    memory = result.get("memory", {})
    preferred_metric = str(memory.get("preferred_metric", "rss"))
    return {
        "task_name": result["task_name"],
        "task_key": result.get("task_key"),
        "sim_backend": result["sim_backend"],
        "num_envs": result["num_envs"],
        "num_steps": result["num_steps"],
        "warmup_steps": result["warmup_steps"],
        "memory": memory,
        "plot_data": {
            "label": summary["label"],
            "median_step_ms": summary["median_step_ms"],
            "throughput_env_steps_per_s": summary["throughput_env_steps_per_s"],
            "total_rss_delta_mb": _mb(memory.get("total_rss_delta_bytes")),
            "total_uss_delta_mb": _mb(memory.get("total_uss_delta_bytes")),
            "preferred_memory_metric": preferred_metric,
            "total_preferred_delta_mb": _mb(memory.get(f"total_{preferred_metric}_delta_bytes")),
            "retained_preferred_delta_after_close_mb": _mb(
                memory.get(f"retained_{preferred_metric}_delta_after_close_bytes")
            ),
            "breakdown_median_ms": {
                key: _median_timing_ms(result, key) for key, _, _ in BREAKDOWN_SEGMENTS
            },
        },
    }


def _print_single_report(result: dict[str, Any]) -> None:
    tr = result["timing_records"]
    summary = _compute_result_summary(result)

    print(f"\n{'=' * 60}")
    print(f"  Task:       {result['task_name']}")
    print(f"  Backend:    {result['sim_backend']}")
    print(f"  Num envs:   {result['num_envs']}")
    print(f"  Steps:      {result['num_steps']} (warmup: {result['warmup_steps']})")
    print(f"{'=' * 60}")
    print(f"  Total time:       {summary['total_time_s']:.3f}s")
    print(f"  Mean step time:   {summary['mean_step_ms']:.3f}ms")
    print(f"  Median step time: {summary['median_step_ms']:.3f}ms")
    print(f"  Std step time:    {summary['std_step_ms']:.3f}ms")
    print(f"  Min step time:    {summary['min_step_ms']:.3f}ms")
    print(f"  Max step time:    {summary['max_step_ms']:.3f}ms")
    print(f"  Throughput:       {summary['throughput_env_steps_per_s']:.0f} env-steps/s")
    memory = result.get("memory", {})
    if memory:
        preferred_metric = str(memory.get("preferred_metric", "rss"))
        print(
            "  Memory RSS:       "
            f"total Δ={_format_mb(memory.get('total_rss_delta_bytes'))}, "
            f"after step={_format_mb(memory.get('after_benchmark_rss_bytes'), signed=False)}"
        )
        if memory.get("total_uss_delta_bytes") is not None:
            print(
                "  Memory USS:       "
                f"total Δ={_format_mb(memory.get('total_uss_delta_bytes'))}, "
                f"after step={_format_mb(memory.get('after_benchmark_uss_bytes'), signed=False)}"
            )
        print(
            "  Memory retained:  "
            f"after close Δ={_format_mb(memory.get(f'retained_{preferred_metric}_delta_after_close_bytes'))} "
            f"({preferred_metric.upper()})"
        )
        print(
            "  Memory baseline:  "
            f"before env={_format_mb(memory.get('before_env_rss_bytes'), signed=False)} "
            f"(source: {memory.get('rss_source', 'unavailable')})"
        )
    if tr:
        print(f"{'- ' * 30}")
        print("  Breakdown:")
        for k, v in tr.items():
            if k == "env_step_total_ms":
                continue
            arr = np.array(v)
            print(f"    {k:25s}  mean={arr.mean():.3f}ms  median={np.median(arr):.3f}ms")
    print(f"{'=' * 60}")


def _short_task_label(task_name: str) -> str:
    """Shorten 'Go1JoystickFlat' → 'go1'."""
    name = task_name.lower()
    if "motiontracking" in name:
        return "g1_mt"
    if name.startswith("sharpainhand"):
        return "sharpa_inhand"
    if "rough" in name and name.startswith("g1"):
        return "g1_rough"
    if name.startswith("go2w") and "roughtiles" in name:
        return "go2w_rough_tiles"
    if name.startswith("go2w"):
        return "go2w"
    for prefix in ("go1", "go2", "g1"):
        if name.startswith(prefix):
            return prefix
    return task_name[:8]


def _print_comparison_table(results: list[dict[str, Any]]) -> None:
    rows_spec: list[tuple[str, str]] = [
        # (display_label, timing_key_or_special)
        ("total", "env_step_total_ms"),
        ("  apply_action", "apply_action_ms"),
        ("  set_ctrl", "backend_set_ctrl_ms"),
        ("  physics", "backend_physics_ms"),
        ("  refresh_cache", "backend_refresh_cache_ms"),
        ("  step_core_other", "step_core_other_ms"),
        ("  update_state", "update_state_ms"),
        ("  reset_done", "reset_done_ms"),
        ("  env_step_other", "env_step_other_ms"),
        ("throughput", "__throughput__"),
        ("memory RSS Δ", "__total_rss_delta_mb__"),
        ("memory USS Δ", "__total_uss_delta_mb__"),
        ("close USS Δ", "__close_uss_delta_mb__"),
    ]

    # Build short column labels
    col_labels = [
        f"{r.get('task_key', _short_task_label(r['task_name']))}/{r['sim_backend']}"
        for r in results
    ]

    metric_w = 16
    col_w = max(12, max(len(c) for c in col_labels) + 2)

    def hline(left: str, mid: str, right: str, fill: str = "─") -> str:
        return left + fill * metric_w + mid + mid.join(fill * col_w for _ in results) + right

    # Header
    print()
    print(hline("┌", "┬", "┐"))
    header = "│" + "metric".center(metric_w) + "│"
    header += "│".join(c.center(col_w) for c in col_labels) + "│"
    print(header)

    unit_row = "│" + "(ms / MB)".center(metric_w) + "│"
    unit_row += "│".join(" " * col_w for _ in results) + "│"
    print(unit_row)
    print(hline("├", "┼", "┤"))

    # Data rows
    for label, key in rows_spec:
        cells: list[str] = []
        if key == "__throughput__":
            for r in results:
                total_arr = _timing_array(r, "env_step_total_ms")
                total_s = total_arr.sum() / 1000.0
                steps_per_env = r["num_steps"] * r["num_envs"]
                cells.append(f"{steps_per_env / total_s:,.0f}" if total_s > 0 else "-")
        elif key == "__total_rss_delta_mb__":
            for r in results:
                cells.append(_format_mb(r.get("memory", {}).get("total_rss_delta_bytes")))
        elif key == "__total_uss_delta_mb__":
            for r in results:
                cells.append(_format_mb(r.get("memory", {}).get("total_uss_delta_bytes")))
        elif key == "__close_uss_delta_mb__":
            for r in results:
                cells.append(
                    _format_mb(r.get("memory", {}).get("retained_uss_delta_after_close_bytes"))
                )
        else:
            for r in results:
                arr = _timing_array(r, key)
                cells.append(f"{np.median(arr):.3f}" if arr.size else "-")

        row = "│" + label.ljust(metric_w) + "│"
        row += "│".join(v.rjust(col_w - 1) + " " for v in cells) + "│"

        # Separator before throughput
        if key == "__throughput__":
            print(hline("├", "┼", "┤"))

        print(row)

    print(hline("└", "┴", "┘"))
    if results:
        r0 = results[0]
        print(f"  ({r0['num_envs']} envs, {r0['num_steps']} steps, throughput = env-steps/s)")


def _task_key(result: dict[str, Any]) -> str:
    return cast(str, result.get("task_key", _short_task_label(result["task_name"])))


def _task_color(task_key: str) -> str:
    return TASK_COLORS.get(task_key, "#4C78A8")


def _backend_style(backend: str) -> dict[str, str]:
    return BACKEND_STYLES.get(backend, {"marker": "o", "linestyle": "-", "hatch": ""})


def _ordered_results(results: list[dict[str, Any]]) -> list[dict[str, Any]]:
    task_order = {task_key: idx for idx, task_key in enumerate(TASK_CONFIGS)}
    backend_order = {backend: idx for idx, backend in enumerate(BACKENDS)}
    return sorted(
        results,
        key=lambda result: (
            task_order.get(_task_key(result), len(task_order)),
            backend_order.get(result["sim_backend"], len(backend_order)),
            result["task_name"],
        ),
    )


def _align_timing_array(arr: np.ndarray, target_size: int) -> np.ndarray:
    if arr.size == target_size:
        return arr
    if arr.size == 0:
        return np.zeros(target_size, dtype=np.float64)
    if arr.size > target_size:
        return arr[:target_size]
    padded = np.zeros(target_size, dtype=np.float64)
    padded[: arr.size] = arr
    return padded


def _timing_array(result: dict[str, Any], key: str) -> np.ndarray:
    timing_records = result["timing_records"]
    if key in timing_records:
        return np.asarray(timing_records[key], dtype=np.float64)

    if key == "step_core_other_ms":
        step_core = _timing_array(result, "step_core_ms")
        if step_core.size == 0:
            return step_core
        backend_total = (
            _align_timing_array(_timing_array(result, "backend_set_ctrl_ms"), step_core.size)
            + _align_timing_array(_timing_array(result, "backend_physics_ms"), step_core.size)
            + _align_timing_array(_timing_array(result, "backend_refresh_cache_ms"), step_core.size)
        )
        return cast(np.ndarray, np.clip(step_core - backend_total, a_min=0.0, a_max=None))

    if key == "env_step_other_ms":
        total = _timing_array(result, "env_step_total_ms")
        if total.size == 0:
            return total
        measured = (
            _align_timing_array(_timing_array(result, "apply_action_ms"), total.size)
            + _align_timing_array(_timing_array(result, "step_core_ms"), total.size)
            + _align_timing_array(_timing_array(result, "update_state_ms"), total.size)
            + _align_timing_array(_timing_array(result, "reset_done_ms"), total.size)
        )
        return cast(np.ndarray, np.clip(total - measured, a_min=0.0, a_max=None))

    return np.array([], dtype=np.float64)


def _median_timing_ms(result: dict[str, Any], key: str) -> float:
    arr = _timing_array(result, key)
    return float(np.median(arr)) if arr.size else 0.0


def _grouped_positions(
    results: list[dict[str, Any]],
    *,
    bar_spacing: float = 1.0,
    group_gap: float = 1.1,
) -> tuple[list[dict[str, Any]], np.ndarray, list[dict[str, Any]]]:
    ordered = _ordered_results(results)
    positions: list[float] = []
    groups: list[dict[str, Any]] = []
    cursor = 0.0
    group_start = 0

    for idx, result in enumerate(ordered):
        positions.append(cursor)
        task_key = _task_key(result)
        next_result = ordered[idx + 1] if idx + 1 < len(ordered) else None
        cursor += bar_spacing
        if next_result is None or _task_key(next_result) != task_key:
            group_positions = positions[group_start : idx + 1]
            groups.append(
                {
                    "task_key": task_key,
                    "label": task_key,
                    "start": group_positions[0],
                    "end": group_positions[-1],
                    "center": float(sum(group_positions) / len(group_positions)),
                }
            )
            group_start = idx + 1
            if next_result is not None:
                cursor += group_gap

    return ordered, np.array(positions, dtype=np.float64), groups


def _decorate_grouped_xaxis(
    ax,
    ordered_results: list[dict[str, Any]],
    positions: np.ndarray,
    groups: list[dict[str, Any]],
) -> None:
    if not ordered_results:
        return

    ax.set_xticks(positions)
    ax.set_xticklabels(
        [
            BACKEND_TICK_LABELS.get(result["sim_backend"], result["sim_backend"])
            for result in ordered_results
        ],
        rotation=0,
        ha="center",
        fontsize=9,
    )

    for idx, group in enumerate(groups):
        ax.axvspan(
            group["start"] - 0.48,
            group["end"] + 0.48,
            color=_task_color(group["task_key"]),
            alpha=0.05,
            zorder=0,
        )
        ax.text(
            group["center"],
            -0.18,
            group["label"],
            transform=ax.get_xaxis_transform(),
            ha="center",
            va="top",
            fontsize=9,
            fontweight="bold",
        )
        if idx < len(groups) - 1:
            boundary = (group["end"] + groups[idx + 1]["start"]) / 2.0
            ax.axvline(boundary, color="#9AA0A6", linewidth=1.0, alpha=0.7)

    ax.set_xlim(float(positions[0] - 0.7), float(positions[-1] + 0.7))


def _backend_legend_handles() -> list[Any]:
    if mpatches is None:
        return []
    return [
        mpatches.Patch(
            facecolor="#FFFFFF",
            edgecolor="#444444",
            hatch=_backend_style(backend)["hatch"],
            label=backend,
        )
        for backend in BACKENDS
    ]


def _breakdown_segments_for_results(results: list[dict[str, Any]]) -> list[tuple[str, str, str]]:
    visible_segments: list[tuple[str, str, str]] = []
    for key, label, color in BREAKDOWN_SEGMENTS:
        if key in {"step_core_other_ms", "env_step_other_ms"}:
            if max((_median_timing_ms(result, key) for result in results), default=0.0) <= 0.05:
                continue
        visible_segments.append((key, label, color))
    return visible_segments


def _save_single_metric_plot(
    results: list[dict[str, Any]],
    output_path: Path,
    *,
    values: list[float],
    ylabel: str,
    title: str,
    add_zero_line: bool = False,
) -> bool:
    if plt is None or not results:
        return False

    output_path.parent.mkdir(parents=True, exist_ok=True)
    ordered, x, groups = _grouped_positions(results)
    width = 0.78

    fig, ax = plt.subplots(figsize=(max(10, len(ordered) * 1.4), 5.5))
    for idx, result in enumerate(ordered):
        style = _backend_style(result["sim_backend"])
        color = _task_color(_task_key(result))
        ax.bar(
            x[idx],
            values[idx],
            width=width,
            color=color,
            edgecolor="#444444",
            hatch=style["hatch"],
            alpha=0.92,
        )

    if add_zero_line:
        ax.axhline(0.0, color="#5F6368", linewidth=0.8)
    ax.set_ylabel(ylabel)
    ax.set_title(f"{title}\n{get_device_info_line()}")
    ax.grid(axis="y", alpha=0.3)
    _decorate_grouped_xaxis(ax, ordered, x, groups)

    handles = _backend_legend_handles()
    if handles:
        ax.legend(handles=handles, fontsize=8, loc="upper right")
    fig.subplots_adjust(bottom=0.24, top=0.88)
    fig.savefig(output_path, dpi=160, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved: {output_path.resolve()}")
    return True


def _save_summary_plots(
    results: list[dict[str, Any]],
    *,
    latency_path: Path,
    throughput_path: Path,
    memory_path: Path,
) -> list[Path]:
    """Save Latency / Throughput / Memory as three separate images.

    The previous single 3-subplot figure became unreadable as task count grew;
    each metric now lives in its own image so the x-axis labels stay legible.
    """
    if plt is None or not results:
        return []

    ordered, _, _ = _grouped_positions(results)
    summaries = [_compute_result_summary(result) for result in ordered]
    median_ms = [summary["median_step_ms"] for summary in summaries]
    throughput = [summary["throughput_env_steps_per_s"] for summary in summaries]
    memory_metric = [str(summary["memory"].get("preferred_metric", "rss")) for summary in summaries]
    total_memory_delta_mb = [
        _mb(summary["memory"].get(f"total_{memory_metric[idx]}_delta_bytes")) or 0.0
        for idx, summary in enumerate(summaries)
    ]

    saved: list[Path] = []
    if _save_single_metric_plot(
        results,
        latency_path,
        values=median_ms,
        ylabel="median env.step time (ms)",
        title="Env step latency",
    ):
        saved.append(latency_path)
    if _save_single_metric_plot(
        results,
        throughput_path,
        values=throughput,
        ylabel="throughput (env-steps/s)",
        title="Env step throughput",
    ):
        saved.append(throughput_path)
    if _save_single_metric_plot(
        results,
        memory_path,
        values=total_memory_delta_mb,
        ylabel="memory delta (MB, USS preferred)",
        title="Env step memory",
        add_zero_line=True,
    ):
        saved.append(memory_path)
    return saved


def _save_breakdown_plot(results: list[dict[str, Any]], output_path: Path) -> bool:
    if plt is None or not results:
        return False

    output_path.parent.mkdir(parents=True, exist_ok=True)
    ordered, x, groups = _grouped_positions(results)
    width = 0.78
    cumulative = np.zeros(len(ordered), dtype=np.float64)
    segments = _breakdown_segments_for_results(ordered)

    fig, ax = plt.subplots(figsize=(max(10, len(ordered) * 1.6), 5.8))
    for timing_key, display_name, color in segments:
        values_np = np.array(
            [_median_timing_ms(result, timing_key) for result in ordered], dtype=np.float64
        )
        for idx, result in enumerate(ordered):
            style = _backend_style(result["sim_backend"])
            ax.bar(
                x[idx],
                values_np[idx],
                width,
                bottom=cumulative[idx],
                label=display_name if idx == 0 else "_nolegend_",
                color=color,
                edgecolor="#444444",
                hatch=style["hatch"],
                alpha=0.94,
            )
        cumulative += values_np

    _decorate_grouped_xaxis(ax, ordered, x, groups)
    ax.set_ylabel("median step time (ms)")
    ax.set_title(f"Env step median breakdown\n{get_device_info_line()}")
    ax.grid(axis="y", alpha=0.3)
    handles, legend_labels = ax.get_legend_handles_labels()
    backend_handles = _backend_legend_handles()
    if backend_handles:
        handles.extend(backend_handles)
        legend_labels.extend([handle.get_label() for handle in backend_handles])
    ax.legend(handles, legend_labels, ncol=2, fontsize=8, loc="upper left")
    fig.subplots_adjust(bottom=0.24, top=0.86)
    fig.savefig(output_path, dpi=160, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved: {output_path.resolve()}")
    return True


def _save_breakdown_markdown_table(results: list[dict[str, Any]], output_path: Path) -> bool:
    """Write per-case median breakdown (ms) as a Markdown table.

    One row per case (task/backend), one column per ``BREAKDOWN_SEGMENTS`` entry
    plus total and throughput. Mirrors the data that the stacked breakdown plot
    visualizes, but in a form that's easy to paste into a PR description.
    """
    if not results:
        return False

    ordered, _, _ = _grouped_positions(results)
    headers = ["task/backend", "total_ms"]
    headers += [label for _, label, _ in BREAKDOWN_SEGMENTS]
    headers.append("throughput/s")

    rows: list[list[str]] = []
    for result in ordered:
        label = f"{_task_key(result)}/{result['sim_backend']}"
        total_arr = _timing_array(result, "env_step_total_ms")
        total_ms = float(np.median(total_arr)) if total_arr.size else 0.0
        total_s = float(total_arr.sum() / 1000.0)
        steps_per_env = result["num_steps"] * result["num_envs"]
        throughput = steps_per_env / total_s if total_s > 0 else 0.0

        row = [label, f"{total_ms:.3f}"]
        for key, _label, _color in BREAKDOWN_SEGMENTS:
            row.append(f"{_median_timing_ms(result, key):.3f}")
        row.append(f"{throughput:,.0f}")
        rows.append(row)

    col_widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            col_widths[i] = max(col_widths[i], len(cell))

    def _format_row(cells: list[str]) -> str:
        return "| " + " | ".join(cell.ljust(col_widths[i]) for i, cell in enumerate(cells)) + " |"

    separator = "| " + " | ".join("-" * col_widths[i] for i in range(len(headers))) + " |"

    if results:
        r0 = ordered[0]
        params_line = (
            f"_num_envs={r0['num_envs']}, num_steps={r0['num_steps']}, "
            f"warmup_steps={r0['warmup_steps']}; values are medians over steps in ms; "
            f"throughput = env-steps/s_"
        )
    else:
        params_line = ""

    lines = [
        "# Env step breakdown (median ms per segment)",
        "",
        get_device_info_line(),
        "",
        params_line,
        "",
        _format_row(headers),
        separator,
    ]
    lines.extend(_format_row(row) for row in rows)
    lines.append("")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text("\n".join(lines), encoding="utf-8")
    print(f"Saved: {output_path.resolve()}")
    return True


def _persist_outputs(
    results: list[dict[str, Any]],
    *,
    mode: str,
    out_json: Path,
    plot_dir: Path | None,
    skip_plots: bool,
    failures: list[dict[str, str]] | None = None,
) -> None:
    plot_files: list[str] = []
    effective_plot_dir = plot_dir or out_json.parent

    if not skip_plots:
        latency_path = effective_plot_dir / "env_step_latency.png"
        throughput_path = effective_plot_dir / "env_step_throughput.png"
        memory_path = effective_plot_dir / "env_step_memory.png"
        breakdown_path = effective_plot_dir / "env_step_breakdown.png"

        saved_summary = _save_summary_plots(
            results,
            latency_path=latency_path,
            throughput_path=throughput_path,
            memory_path=memory_path,
        )
        if saved_summary:
            plot_files.extend(str(path.resolve()) for path in saved_summary)
        elif plt is None and results:
            print("matplotlib unavailable; skipped env step summary plots.")

        if _save_breakdown_plot(results, breakdown_path):
            plot_files.append(str(breakdown_path.resolve()))
        elif plt is None and results:
            print("matplotlib unavailable; skipped env step breakdown plot.")

    breakdown_md_path = effective_plot_dir / "env_step_breakdown.md"
    if _save_breakdown_markdown_table(results, breakdown_md_path):
        plot_files.append(str(breakdown_md_path.resolve()))

    meta: dict[str, Any] = {
        "mode": mode,
        "device_info": get_device_info_dict(),
        "matplotlib_available": plt is not None,
        "plot_files": plot_files,
        "memory_measurement": {
            "single_case": "in_process",
            "matrix": "case_subprocess_isolated",
            "growth_range": "before_env_to_after_benchmark",
            "metrics": list(MEMORY_METRICS),
        },
    }
    if failures:
        meta["failures"] = failures

    save_json(out_json, [_serialize_result(result) for result in results], meta)


def _case_runner_args(extra_args: list[str]) -> list[str]:
    args: list[str] = []
    i = 0
    while i < len(extra_args):
        arg = extra_args[i]
        if arg in {"--out-json", "--plot-dir"}:
            i += 2
            continue
        if arg.startswith("--out-json=") or arg.startswith("--plot-dir="):
            i += 1
            continue
        if arg.startswith("out_json=") or arg.startswith("plot_dir="):
            i += 1
            continue
        if arg == "--skip-plots" or arg.startswith("skip_plots="):
            i += 1
            continue
        args.append(arg)
        i += 1
    return args


def _tail_text(text: str, *, max_lines: int = 24) -> str:
    lines = text.splitlines()
    return "\n".join(lines[-max_lines:])


def _run_single_isolated(label: str, args: list[str]) -> dict[str, Any]:
    # mjwarp cases need their optional deps re-declared in the subprocess
    # because the case is launched via a fresh `uv run` (the parent's
    # ephemeral --with environment doesn't propagate).
    needs_mjwarp = any(
        arg.endswith("/mjwarp") or arg == "training.sim_backend=mjwarp" for arg in args
    )
    with tempfile.TemporaryDirectory(prefix="unilab_env_step_case_") as tmpdir:
        result_json = Path(tmpdir) / "result.json"
        uv_extra: list[str] = []
        if needs_mjwarp:
            uv_extra = ["--with", "mujoco-warp", "--with", "warp-lang"]
        cmd = [
            "uv",
            "run",
            *uv_extra,
            "scripts/benchmark/env/benchmark_env_step.py",
            *args,
            "--emit-full-result-json",
            str(result_json),
        ]
        completed = subprocess.run(
            cmd,
            cwd=ROOT_DIR,
            capture_output=True,
            text=True,
        )
        if completed.returncode != 0:
            details = _tail_text(completed.stdout + "\n" + completed.stderr)
            raise RuntimeError(details or f"case process exited with {completed.returncode}")

        if not result_json.exists():
            details = _tail_text(completed.stdout + "\n" + completed.stderr)
            raise RuntimeError(f"{label} produced no result JSON\n{details}")

        payload = json.loads(result_json.read_text(encoding="utf-8"))
        record = payload.get("result")
        if not isinstance(record, dict):
            raise RuntimeError(f"{label} produced no raw result record")
        return cast(dict[str, Any], record)


def _run_matrix(
    extra_args: list[str], *, out_json: Path, plot_dir: Path | None, skip_plots: bool
) -> None:
    """Run all task x backend combinations and print comparison."""
    from unilab.base.backend import MOTRIX_AVAILABLE

    backends = ["mujoco"]
    if MOTRIX_AVAILABLE:
        backends.append("motrix")
    else:
        print("Note: motrixsim not available; skipping motrix column\n")
    if MJWARP_AVAILABLE:
        backends.append("mjwarp")
    else:
        print(
            "Note: mujoco_warp not available; skipping mjwarp column "
            "(install via `uv run --with mujoco-warp --with warp-lang`)\n"
        )

    results: list[dict] = []
    failures: list[dict[str, str]] = []
    for task_key, task_config in TASK_CONFIGS.items():
        if not task_config.include_in_matrix:
            continue
        for backend in task_config.backends:
            if backend not in backends:
                continue
            label = f"{task_key}/{backend}"
            print(f"Running {label} ...", flush=True)
            try:
                args = [f"task={task_config.task_id}/{backend}"] + _case_runner_args(extra_args)
                result = _run_single_isolated(label, args)
                result["task_key"] = task_key
                results.append(result)
                _print_single_report(result)
            except Exception as e:
                print(f"  FAILED: {e}\n")
                failures.append({"label": label, "error": str(e)})

    if len(results) > 1:
        _print_comparison_table(results)
    _persist_outputs(
        results,
        mode="matrix",
        out_json=out_json,
        plot_dir=plot_dir,
        skip_plots=skip_plots,
        failures=failures,
    )


def _extract_emit_full_result_arg(argv: list[str]) -> tuple[Path | None, list[str]]:
    emit_path: Path | None = None
    remaining: list[str] = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--emit-full-result-json":
            i += 1
            if i >= len(argv):
                raise ValueError("--emit-full-result-json requires a path")
            emit_path = Path(argv[i])
        elif arg.startswith("--emit-full-result-json="):
            emit_path = Path(arg.split("=", 1)[1])
        else:
            remaining.append(arg)
        i += 1
    return emit_path, remaining


def main() -> None:
    argv = sys.argv[1:]
    emit_full_result_json, argv = _extract_emit_full_result_arg(argv)
    if emit_full_result_json is not None:
        result = _run_single(argv)
        emit_full_result_json.parent.mkdir(parents=True, exist_ok=True)
        emit_full_result_json.write_text(json.dumps({"result": result}), encoding="utf-8")
        return

    _, output_kwargs, _ = _parse_cli_args(argv)
    out_json = Path(output_kwargs["out_json"]) if output_kwargs["out_json"] else DEFAULT_OUTPUT_JSON
    plot_dir = Path(output_kwargs["plot_dir"]) if output_kwargs["plot_dir"] else None
    skip_plots = bool(output_kwargs["skip_plots"])

    if _is_matrix_mode(argv):
        _run_matrix(argv, out_json=out_json, plot_dir=plot_dir, skip_plots=skip_plots)
    else:
        result = _run_single(argv)
        _print_single_report(result)
        _persist_outputs(
            [result],
            mode="single",
            out_json=out_json,
            plot_dir=plot_dir,
            skip_plots=skip_plots,
        )


if __name__ == "__main__":
    main()
