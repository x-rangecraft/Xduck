#!/usr/bin/env python3
"""
Benchmark MuJoCo Warp physics execution.

Benchmarks mujoco_warp across current locomotion owner task ids
(go1_joystick_flat/go2_joystick_flat/g1_walk_flat) and outputs JSON + plots
aligned with scripts/benchmark/physics/benchmark_physics_step_mj_step.py.
Legacy env names remain accepted as aliases.

Run without changing repo dependencies:
    uv run --with mujoco-warp --with warp-lang \
        python scripts/benchmark/physics/benchmark_physics_step_mujoco_warp.py

CUDA graph capture (optional) — eager vs captured throughput:
    uv run --with mujoco-warp --with warp-lang \
        python scripts/benchmark/physics/benchmark_physics_step_mujoco_warp.py --capture both

NOTE: the eager path still synchronizes per step (a known measurement bug to be
fixed separately). The captured path syncs once per nstep block, so for now an
eager-vs-graph gap reflects both the sync-granularity bug and the graph speedup.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, cast

_REPO_ROOT = Path(__file__).resolve().parents[3]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

try:
    import mujoco
except ImportError:
    mujoco = None

try:
    import mujoco_warp as mj_warp
except ImportError:
    mj_warp = None

try:
    import warp
except ImportError:
    warp = None

from scripts.benchmark.core import device_info as _device_info
from scripts.benchmark.core import task_names as _task_names

get_device_info_dict = _device_info.get_device_info_dict
get_device_info_line = _device_info.get_device_info_line
canonical_locomotion_task_ids = _task_names.canonical_locomotion_task_ids
locomotion_task_spec = _task_names.locomotion_task_spec
locomotion_task_model_file = _task_names.locomotion_task_model_file
normalize_locomotion_task_id = _task_names.normalize_locomotion_task_id


@dataclass
class BenchRecord:
    task: str
    backend: str
    batch_size: int
    nstep: int
    nthread: int
    avg_time_sec: float
    sps: float


DEFAULT_TASK_IDS = canonical_locomotion_task_ids()
DEFAULT_BATCH_SIZES = [2**k for k in range(8, 15)]  # 256 .. 16384
DEFAULT_NJMAX_BY_TASK = {
    "go1_joystick_flat": 100,
    "go2_joystick_flat": 100,
    "g1_walk_flat": 256,
    "sharpa_inhand": 128,
}


def _display_backend(backend: str) -> str:
    return {
        "mujoco_warp": "mujoco_warp (eager)",
        "mujoco_warp_graph": "mujoco_warp (graph)",
    }.get(backend, backend)


def _uv_run_hint() -> str:
    return (
        "uv run --with mujoco-warp --with warp-lang "
        "python scripts/benchmark/physics/benchmark_physics_step_mujoco_warp.py"
    )


def _require_mujoco_warp() -> None:
    if mujoco is None:
        raise RuntimeError(
            "mujoco is unavailable in the current environment. "
            f"Run with temporary deps instead of editing pyproject.toml:\n  {_uv_run_hint()}"
        )
    if mj_warp is None:
        raise RuntimeError(
            "mujoco_warp is unavailable in the current environment. "
            f"Run with temporary deps instead of editing pyproject.toml:\n  {_uv_run_hint()}"
        )
    if warp is None:
        raise RuntimeError(
            "warp is unavailable in the current environment. "
            f"Run with temporary deps instead of editing pyproject.toml:\n  {_uv_run_hint()}"
        )


def _load_task_model(task_name: str) -> Any:
    return cast(Any, mujoco).MjModel.from_xml_path(locomotion_task_model_file(task_name))


def _task_njmax(task_name: str) -> int:
    return DEFAULT_NJMAX_BY_TASK.get(task_name, -1)


def _make_warp_data(model: Any, batch_size: int, njmax: int):
    mj_warp_mod = cast(Any, mj_warp)
    try:
        if njmax > 0:
            return mj_warp_mod.make_data(model, nworld=batch_size, njmax=njmax, nconmax=njmax)
        return mj_warp_mod.make_data(model, nworld=batch_size)
    except TypeError:
        return mj_warp_mod.make_data(model, nworld=batch_size)


def _run_warp(warp_model, warp_data, nstep: int, niter: int) -> float:
    # NOTE: synchronizes per step (a known measurement bug to be fixed
    # separately). Left as-is on purpose so the captured path below is added
    # without changing the existing eager baseline.
    mj_warp_mod = cast(Any, mj_warp)
    warp_mod = cast(Any, warp)
    t0 = time.perf_counter()
    for _ in range(niter):
        for _ in range(nstep):
            mj_warp_mod.step(warp_model, warp_data)
            warp_mod.synchronize()
    return (time.perf_counter() - t0) / niter


def _warp_device_is_cuda() -> bool:
    """True when warp's default device supports CUDA graph capture."""
    warp_mod = cast(Any, warp)
    try:
        return bool(warp_mod.get_device().is_cuda)
    except Exception:
        return False


def _build_warp_graph(warp_model, warp_data, nstep: int):
    """Capture one nstep block of warp steps into a single CUDA graph.

    A few eager steps run first so warp's lazy module loads / allocations happen
    *before* capture — recording an allocation into a graph is illegal and would
    make the replay throw. No synchronize may occur inside the capture region.
    """
    mj_warp_mod = cast(Any, mj_warp)
    warp_mod = cast(Any, warp)
    for _ in range(nstep):
        mj_warp_mod.step(warp_model, warp_data)
    warp_mod.synchronize()
    with warp_mod.ScopedCapture() as capture:
        for _ in range(nstep):
            mj_warp_mod.step(warp_model, warp_data)
    return capture.graph


def _run_warp_graph(graph, niter: int) -> float:
    """Replay a captured nstep-block graph niter times. Avg seconds per iter.

    One synchronize per block replaces the eager path's per-step synchronize:
    the fused graph launch collapses per-step kernel-launch overhead, which is
    the CUDA graph speedup. The trailing synchronize is still required because
    warp launches are async.
    """
    warp_mod = cast(Any, warp)
    t0 = time.perf_counter()
    for _ in range(niter):
        warp_mod.capture_launch(graph)
        warp_mod.synchronize()
    return (time.perf_counter() - t0) / niter


def _resolve_capture_modes(capture_arg: str) -> List[str]:
    """Map the --capture flag to the list of modes to run.

    ``off`` -> eager only; ``on`` -> graph only; ``both`` -> eager then graph.
    A graph mode is dropped (with a warning) when the warp device is not CUDA,
    so a CPU-only run still produces the eager series instead of crashing.
    """
    if capture_arg == "off":
        modes = ["off"]
    elif capture_arg == "on":
        modes = ["on"]
    elif capture_arg == "both":
        modes = ["off", "on"]
    else:
        raise ValueError(f"--capture must be one of off/on/both, got {capture_arg!r}")

    if "on" in modes and not _warp_device_is_cuda():
        print(
            "Warning: warp device is not CUDA; CUDA graph capture is unavailable, "
            "skipping the captured (graph) series."
        )
        modes = [m for m in modes if m != "on"] or ["off"]
    return modes


def _bench_one_task(
    task_name: str,
    batch_sizes: List[int],
    nstep: int,
    warmup: int,
    iters: int,
    capture_modes: List[str],
) -> List[BenchRecord]:
    task_key = normalize_locomotion_task_id(task_name)
    model = _load_task_model(task_key)
    warp_model = cast(Any, mj_warp).put_model(model)
    njmax = _task_njmax(task_key)

    records: List[BenchRecord] = []
    for batch_size in batch_sizes:
        for mode in capture_modes:
            backend = "mujoco_warp_graph" if mode == "on" else "mujoco_warp"
            # Fresh data per mode keeps the two series independent: a captured
            # graph holds references to the data buffers it was recorded with.
            warp_data = _make_warp_data(model, batch_size, njmax)
            try:
                if mode == "on":
                    graph = _build_warp_graph(warp_model, warp_data, nstep)
                    _run_warp_graph(graph, niter=warmup)
                    avg_t = _run_warp_graph(graph, niter=iters)
                else:
                    _run_warp(warp_model, warp_data, nstep=nstep, niter=warmup)
                    avg_t = _run_warp(warp_model, warp_data, nstep=nstep, niter=iters)
            except Exception as exc:  # graph capture can fail on non-capturable steps
                print(f"[{task_key}] batch={batch_size:5d} {backend} FAILED: {exc}")
                continue

            records.append(
                BenchRecord(
                    task=task_key,
                    backend=backend,
                    batch_size=batch_size,
                    nstep=nstep,
                    nthread=0,
                    avg_time_sec=avg_t,
                    sps=batch_size * nstep / avg_t,
                )
            )
            print(
                f"[{task_key}] batch={batch_size:5d} "
                f"{backend}={avg_t * 1000:.3f}ms ({batch_size * nstep / avg_t / 1e4:.2f}万fps)"
            )

    return records


def _plot_fps(
    records: List[BenchRecord], out_png: Path, batch_sizes: List[int], task_names: List[str]
):
    out_png.parent.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(9, 5))
    ax.set_title(f"Parallel Physics — Total FPS\n{get_device_info_line()}", fontsize=9)

    for task_name in task_names:
        for backend in sorted({r.backend for r in records if r.task == task_name}):
            recs = sorted(
                [r for r in records if r.task == task_name and r.backend == backend],
                key=lambda r: r.batch_size,
            )
            ax.plot(
                [r.batch_size for r in recs],
                [r.sps / 1e4 for r in recs],
                marker="o",
                linestyle="-",
                label=f"{locomotion_task_spec(task_name).display_name} ({_display_backend(backend)})",
            )

    ax.set_xscale("log", base=2)
    ax.set_xticks(batch_sizes)
    ax.set_xticklabels([str(b) for b in batch_sizes], rotation=30, ha="right")
    ax.set_xlabel("Batch Size (Num Envs)")
    ax.set_ylabel("Total FPS (x1e4)")
    ax.grid(True, alpha=0.3)
    ax.legend(fontsize=7)
    fig.tight_layout()
    fig.savefig(out_png, dpi=150)
    plt.close(fig)
    print(f"Saved FPS plot to {out_png}")


def _plot_per_env_sps(
    records: List[BenchRecord], out_png: Path, batch_sizes: List[int], task_names: List[str]
):
    out_png.parent.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(9, 5))
    ax.set_title(f"Parallel Physics — Per-Env SPS\n{get_device_info_line()}", fontsize=9)

    for task_name in task_names:
        for backend in sorted({r.backend for r in records if r.task == task_name}):
            recs = sorted(
                [r for r in records if r.task == task_name and r.backend == backend],
                key=lambda r: r.batch_size,
            )
            ax.plot(
                [r.batch_size for r in recs],
                [r.sps / r.batch_size for r in recs],
                marker="o",
                linestyle="-",
                label=f"{locomotion_task_spec(task_name).display_name} ({_display_backend(backend)})",
            )

    ax.set_xscale("log", base=2)
    ax.set_xticks(batch_sizes)
    ax.set_xticklabels([str(b) for b in batch_sizes], rotation=30, ha="right")
    ax.set_xlabel("Batch Size (Num Envs)")
    ax.set_ylabel("Per-Env Steps/s")
    ax.grid(True, alpha=0.3)
    ax.legend(fontsize=7)
    fig.tight_layout()
    fig.savefig(out_png, dpi=150)
    plt.close(fig)
    print(f"Saved per-env SPS plot to {out_png}")


def main():
    parser = argparse.ArgumentParser(description="Benchmark MuJoCo Warp physics execution")
    parser.add_argument("--nstep", type=int, default=20)
    parser.add_argument("--warmup", type=int, default=2)
    parser.add_argument("--iters", type=int, default=3)
    parser.add_argument(
        "--capture",
        choices=["off", "on", "both"],
        default="off",
        help="CUDA graph capture: off=eager only (default), on=graph only, "
        "both=run eager and captured series for comparison.",
    )
    parser.add_argument(
        "--tasks",
        type=str,
        default=",".join(DEFAULT_TASK_IDS),
    )
    parser.add_argument(
        "--batch-sizes", type=str, default=",".join(str(x) for x in DEFAULT_BATCH_SIZES)
    )
    parser.add_argument(
        "--out-json",
        type=str,
        default="scripts/benchmark/outputs/physics_step/mujoco_warp/results.json",
    )
    parser.add_argument(
        "--out-dir",
        type=str,
        default="scripts/benchmark/outputs/physics_step/mujoco_warp",
        help="Directory for output plots",
    )
    args = parser.parse_args()

    _require_mujoco_warp()

    task_names = [normalize_locomotion_task_id(x) for x in args.tasks.split(",") if x.strip()]
    batch_sizes = [int(x.strip()) for x in args.batch_sizes.split(",") if x.strip()]
    capture_modes = _resolve_capture_modes(args.capture)

    print("MuJoCo Warp backend available")
    print(f"Tasks: {task_names}")
    print(f"Batch sizes: {batch_sizes}")
    print(f"Capture modes: {capture_modes}")

    records: List[BenchRecord] = []
    for task_name in task_names:
        records.extend(
            _bench_one_task(
                task_name=task_name,
                batch_sizes=batch_sizes,
                nstep=args.nstep,
                warmup=args.warmup,
                iters=args.iters,
                capture_modes=capture_modes,
            )
        )

    out_json = Path(args.out_json)
    out_json.parent.mkdir(parents=True, exist_ok=True)
    payload: Dict[str, object] = {
        "meta": {
            "timestamp_utc": datetime.now(timezone.utc).isoformat(),
            "device_info": get_device_info_dict(),
            "tasks": task_names,
            "batch_sizes": batch_sizes,
            "nstep": args.nstep,
            "nthread": 0,
            "warmup": args.warmup,
            "iters": args.iters,
            "capture": args.capture,
            "capture_modes": capture_modes,
            "backends": sorted({r.backend for r in records}),
            "task_njmax": {task: _task_njmax(task) for task in task_names},
            "warp_available": mj_warp is not None and warp is not None,
        },
        "results": [asdict(r) for r in records],
    }
    out_json.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(f"Saved results to {out_json}")

    out_dir = Path(args.out_dir)
    _plot_fps(records, out_dir / "fps.png", batch_sizes=batch_sizes, task_names=task_names)
    _plot_per_env_sps(
        records, out_dir / "per_env_sps.png", batch_sizes=batch_sizes, task_names=task_names
    )


if __name__ == "__main__":
    main()
