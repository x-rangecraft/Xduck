from __future__ import annotations

import warnings
from typing import TYPE_CHECKING, Any, cast

from unilab.base.scene import SceneCfg

from .base import RenderClosedError, SimBackend

if TYPE_CHECKING:
    from unilab.base.base import EnvCfg

    from .mujoco.xml import materialize_scene_visual_override


def env_backend_kwargs(cfg: "EnvCfg") -> dict:
    """Bundle EnvCfg-level backend tuning fields for create_backend(**...)."""
    return {
        "post_step_forward_sensor": cfg.post_step_forward_sensor,
        "motrix_max_iterations": cfg.motrix_max_iterations,
        "chunk_size": cfg.chunk_size,
        "adaptive_chunk_size": cfg.adaptive_chunk_size,
        "cpu_ids": cfg.cpu_ids,
        "bench_nsteps": cfg.sim_substeps,
        "mjwarp_nconmax": cfg.mjwarp_nconmax,
        "mjwarp_njmax": cfg.mjwarp_njmax,
        "drake_backend_mode": cfg.drake_backend_mode,
        "drake_nthread": cfg.drake_nthread,
    }


_MUJOCO_XML_EXPORTS = frozenset(
    {
        "add_sensor",
        "create_discardvisual_xml",
        "get_named_body_ids",
        "inject_mujoco_tracking_sensors",
        "materialize_mujoco_hfield_attached_scene",
        "materialize_scene_fragments",
        "materialize_scene_visual_override",
        "processed_xml",
    }
)
_MOTRIX_SCENE_EXPORTS = frozenset(
    {
        "add_motrix_tracking_frame_sensors",
        "materialize_motrix_hfield_attached_scene",
        "materialize_motrix_scene",
    }
)


def _load_mujoco_backend() -> Any:
    from .mujoco.backend import MuJoCoBackend

    return MuJoCoBackend


def _load_motrix_backend() -> tuple[Any, bool]:
    from .motrix.backend import MOTRIX_AVAILABLE, MotrixBackend

    return MotrixBackend, bool(MOTRIX_AVAILABLE)


def _load_mjwarp_backend() -> Any:
    """Load the independent optional mujoco-warp backend on demand."""
    from .mjwarp.backend import MjwarpBackend

    return MjwarpBackend


def _mjwarp_available() -> bool:
    from .mjwarp.dependencies import mjwarp_dependencies_available

    return mjwarp_dependencies_available()


def _load_motrix_scene_export(name: str) -> Any:
    from .motrix import scene

    return getattr(scene, name)


def _load_drake_backend() -> Any:
    from .drake.backend import DrakeBackend

    return DrakeBackend


def _drake_available() -> bool:
    from .drake.backend import ensure_drake_batch_available

    return ensure_drake_batch_available()[0]


def create_backend(
    backend_type: str,
    scene: SceneCfg,
    num_envs: int,
    sim_dt: float,
    **kwargs,
) -> SimBackend:
    """Create a simulation backend.

    Args:
        backend_type: ``"mujoco"``, ``"mjwarp"``, ``"motrix"``, or
            ``"drake"``.
        scene: SceneCfg for either static or composed scenes.
        num_envs: Number of environments.
        sim_dt: Simulation timestep.
        **kwargs: Additional backend options such as ``position_actuator_gains``,
            ``iterations``, or ``motrix_max_iterations``.

    Returns:
        SimBackend instance.
    """
    if scene is None:
        raise ValueError("SceneCfg must be provided")

    position_actuator_gains = kwargs.pop("position_actuator_gains", None)
    actuator_force_range = kwargs.pop("actuator_force_range", None)
    actuator_ctrl_range = kwargs.pop("actuator_ctrl_range", None)
    dof_armature = kwargs.pop("dof_armature", None)
    dof_damping = kwargs.pop("dof_damping", None)
    dof_frictionloss = kwargs.pop("dof_frictionloss", None)
    dof_friction_solref = kwargs.pop("dof_friction_solref", None)
    dof_friction_solimp = kwargs.pop("dof_friction_solimp", None)
    motrix_max_iterations = kwargs.pop("motrix_max_iterations", None)
    post_step_forward_sensor = kwargs.pop("post_step_forward_sensor", None)
    iterations = kwargs.pop("iterations", None)
    chunk_size = kwargs.pop("chunk_size", None)
    adaptive_chunk_size = kwargs.pop("adaptive_chunk_size", False)
    cpu_ids = kwargs.pop("cpu_ids", None)
    bench_nsteps = kwargs.pop("bench_nsteps", 1)
    mjwarp_nconmax = kwargs.pop("mjwarp_nconmax", None)
    mjwarp_njmax = kwargs.pop("mjwarp_njmax", None)
    drake_backend_mode = kwargs.pop("drake_backend_mode", "batch")
    drake_nthread = kwargs.pop("drake_nthread", None)
    if backend_type != "mujoco" and any(
        value is not None for value in (actuator_ctrl_range, dof_damping, dof_frictionloss)
    ):
        raise ValueError("actuator_ctrl_range and DOF cold overrides require MuJoCo")
    if backend_type == "mujoco":
        MuJoCoBackend = _load_mujoco_backend()
        if position_actuator_gains is not None:
            kwargs["position_actuator_gains"] = position_actuator_gains
        if actuator_force_range is not None:
            kwargs["actuator_force_range"] = actuator_force_range
        if actuator_ctrl_range is not None:
            kwargs["actuator_ctrl_range"] = actuator_ctrl_range
        if dof_armature is not None:
            kwargs["dof_armature"] = dof_armature
        if dof_damping is not None:
            kwargs["dof_damping"] = dof_damping
        if dof_frictionloss is not None:
            kwargs["dof_frictionloss"] = dof_frictionloss
        if dof_friction_solref is not None:
            kwargs["dof_friction_solref"] = dof_friction_solref
        if dof_friction_solimp is not None:
            kwargs["dof_friction_solimp"] = dof_friction_solimp
        if post_step_forward_sensor is not None:
            kwargs["post_step_forward_sensor"] = post_step_forward_sensor
        kwargs["iterations"] = iterations
        kwargs["chunk_size"] = chunk_size
        kwargs["adaptive_chunk_size"] = adaptive_chunk_size
        kwargs["cpu_ids"] = cpu_ids
        kwargs["bench_nsteps"] = bench_nsteps
        return cast(SimBackend, MuJoCoBackend(scene, num_envs, sim_dt, **kwargs))
    if backend_type == "mjwarp":
        MjwarpBackend = _load_mjwarp_backend()
        if position_actuator_gains is not None:
            raise ValueError(
                "mjwarp does not accept position_actuator_gains in the host compatibility "
                "profile; configure the model on the cold path instead."
            )
        ignored_non_defaults = {
            key: value
            for key, value, default in (
                ("post_step_forward_sensor", post_step_forward_sensor, None),
                ("iterations", iterations, None),
                ("chunk_size", chunk_size, None),
                ("adaptive_chunk_size", adaptive_chunk_size, False),
                ("cpu_ids", cpu_ids, None),
                ("bench_nsteps", bench_nsteps, 1),
            )
            if value != default
        }
        if ignored_non_defaults:
            rendered = ", ".join(f"{key}={value!r}" for key, value in ignored_non_defaults.items())
            warnings.warn(
                "mjwarp ignores non-default MuJoCo-only backend options: " + rendered,
                UserWarning,
                stacklevel=2,
            )
        # These generic EnvCfg fields are routed only to the MuJoCo pool.
        del post_step_forward_sensor, iterations, chunk_size, adaptive_chunk_size, cpu_ids
        del bench_nsteps
        kwargs["nconmax"] = mjwarp_nconmax
        kwargs["njmax"] = mjwarp_njmax
        return cast(SimBackend, MjwarpBackend(scene, num_envs, sim_dt, **kwargs))
    if backend_type == "motrix":
        MotrixBackend, motrix_available = _load_motrix_backend()
        if not motrix_available:
            raise ImportError("MotrixSim not available, install motrixsim package")
        if motrix_max_iterations is not None:
            kwargs["max_iterations"] = motrix_max_iterations
        return cast(SimBackend, MotrixBackend(scene, num_envs, sim_dt, **kwargs))
    if backend_type == "drake":
        DrakeBackend = _load_drake_backend()
        # DrakeUni is a generic batch engine. Task-level body names and scalar
        # gain overrides are consumed by other backends, but Drake reads bodies,
        # actuators, and sensors from the model contract itself.
        kwargs.pop("base_name", None)
        kwargs.pop("push_body_name", None)
        kwargs.pop("add_body_sensors", None)
        kwargs["drake_backend_mode"] = drake_backend_mode
        if drake_nthread is not None:
            kwargs["nthread"] = drake_nthread
        return cast(SimBackend, DrakeBackend(scene, num_envs, sim_dt, **kwargs))
    raise ValueError(f"Unknown backend: {backend_type}")


def __getattr__(name: str):
    if name == "MuJoCoBackend":
        return _load_mujoco_backend()
    if name == "MotrixBackend":
        return _load_motrix_backend()[0]
    if name == "MOTRIX_AVAILABLE":
        return _load_motrix_backend()[1]
    if name == "MjwarpBackend":
        return _load_mjwarp_backend()
    if name == "MJWARP_AVAILABLE":
        return _mjwarp_available()
    if name == "DrakeBackend":
        return _load_drake_backend()
    if name == "DRAKE_AVAILABLE":
        return _drake_available()
    if name in _MUJOCO_XML_EXPORTS:
        from .mujoco import xml

        return getattr(xml, name)
    if name in _MOTRIX_SCENE_EXPORTS:
        return _load_motrix_scene_export(name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "SimBackend",
    "RenderClosedError",
    "MuJoCoBackend",
    "MjwarpBackend",
    "MotrixBackend",
    "DrakeBackend",
    "DRAKE_AVAILABLE",
    "MJWARP_AVAILABLE",
    "add_sensor",
    "create_discardvisual_xml",
    "create_backend",
    "get_named_body_ids",
    "inject_mujoco_tracking_sensors",
    "add_motrix_tracking_frame_sensors",
    "materialize_motrix_hfield_attached_scene",
    "materialize_motrix_scene",
    "materialize_mujoco_hfield_attached_scene",
    "materialize_scene_fragments",
    "materialize_scene_visual_override",
    "processed_xml",
]
