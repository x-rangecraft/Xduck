"""Current rigid asset adapter; historical rewards, sampler and motor unchanged."""
from dataclasses import dataclass
import mujoco
import numpy as np
from unilab.base import registry
from .velocity import XDuckGF43X40VelocityCfg, XDuckGF43X40VelocityEnv, XDuckDRProvider


@registry.envcfg('XDuckHistoricalRigid')
@dataclass
class HistoricalRigidCfg(XDuckGF43X40VelocityCfg):
    warp_compiled_model_file: str | None = None
    physics_microsteps: int = 1
    reset_root_z_offset_m: float = 0.
    audit_velocity: float | None = None
    sole_tilt_dr_enabled: bool = True
    sole_tilt_range_deg: tuple[float,float] = (-3.,3.)
    sole_tilt_seed: int = 20260929
    physical_action_scale_rad: list[float] | None = None


class RigidModelReset(XDuckDRProvider):
    def _finalize_reset_pose(self,env,plan):
        plan=super()._finalize_reset_pose(env,plan)
        # Preserve the old random spawn-height interval relative to the new
        # model's nominal ground height. No per-reset geometry modification.
        plan.qpos[:,env._passive_qpos_indices]=0.
        plan.qpos[:,env._policy_qpos_indices]=np.clip(plan.qpos[:,env._policy_qpos_indices],env._reset_joint_limits[:,0]+.01,env._reset_joint_limits[:,1]-.01)
        plan.qpos[:,2]+=env.cfg.reset_root_z_offset_m
        return plan


@registry.env('XDuckHistoricalRigid',sim_backend='mjwarp')
@registry.env('XDuckHistoricalRigid',sim_backend='mujoco')
class HistoricalRigidEnv(XDuckGF43X40VelocityEnv):
    def _make_dr_provider(self):
        return SoleTiltReset()

    def _create_backend(self,cfg,num_envs,backend_type):
        if backend_type=='mujoco':
            if cfg.sole_tilt_dr_enabled:raise ValueError('Sole geometry DR is GPU-owned; disable it for CPU model compilation.')
            from unilab.base.backend import create_backend,env_backend_kwargs
            from unilab.actuators.gf43x40 import GF43X40Parameters
            p=GF43X40Parameters.from_bundle();m=mujoco.MjModel.from_xml_path(cfg.scene.model_file)
            ids=m.jnt_dofadr[m.actuator_trnid[:,0]]
            arm=m.dof_armature.copy();arm[ids]=p.physics['armature']
            damp=m.dof_damping.copy();damp[ids]=0
            friction=m.dof_frictionloss.copy();friction[ids]=0
            limit=p.physics['mechanical_torque_limit']
            return create_backend(backend_type,cfg.scene,num_envs,cfg.sim_dt,base_name=cfg.asset.base_name,
                push_body_name=cfg.domain_rand.push_body_name,add_body_sensors=True,
                position_actuator_gains={'kp':1.,'kd':0.},actuator_ctrl_range=(-limit-p.registers['pmax'],limit+p.registers['pmax']),
                actuator_force_range=(-limit,limit),dof_armature=arm,dof_damping=damp,dof_frictionloss=friction,**env_backend_kwargs(cfg))
        if backend_type!='mjwarp' or not cfg.warp_compiled_model_file or cfg.physics_microsteps!=1:
            raise ValueError('Historical rigid GPU requires a compiled model and 20 x 1ms mechanics')
        from unilab.base.backend.mjwarp.xduck_gf import XDuckGF43X40WarpBackend
        return XDuckGF43X40WarpBackend(cfg.scene,num_envs,cfg.sim_dt,
            compiled_model_file=cfg.warp_compiled_model_file,physics_microsteps=1,
            base_name=cfg.asset.base_name,push_body_name=cfg.domain_rand.push_body_name)

    def _sample_velocity_commands(self,count):
        if self._cfg.audit_velocity is None:
            return super()._sample_velocity_commands(count)
        return np.tile([self._cfg.audit_velocity,0.,0.],(count,1))

    def _sample_head_commands(self,count):
        if self._cfg.audit_velocity is None:return super()._sample_head_commands(count)
        return np.zeros((count,4))

    def _sample_body_commands(self,count):
        if self._cfg.audit_velocity is None:return super()._sample_body_commands(count)
        return np.zeros((count,6))

    def __init__(self,cfg,num_envs=1,backend_type='mujoco'):
        # Geometry is loaded only on the cold path. Flat-ground task only.
        m=mujoco.MjModel.from_xml_path(cfg.scene.model_file)
        floor=m.geom('floor').id
        assert m.geom_type[floor]==mujoco.mjtGeom.mjGEOM_PLANE
        self._ground_z=float(m.geom_pos[floor,2])
        self._active_names=[m.joint(j).name for j in m.actuator_trnid[:,0]]
        self._sole_rng=np.random.default_rng(cfg.sole_tilt_seed)
        self._sole_angles=np.zeros((num_envs,2))
        self._sole_delta_quat=np.zeros((num_envs,2,4));self._sole_delta_quat[:,:,0]=1
        d=mujoco.MjData(m);mujoco.mj_resetDataKeyframe(m,d,m.key('STAND').id);mujoco.mj_forward(m,d)
        self._sole_axes=[];self._sole_geom_centers=[]
        self._sole_vertices=[];body_names=[]
        for side in ['left','right']:
            g=m.geom(side+'_foot_collision').id;k=m.geom_dataid[g]
            assert m.geom_type[g]==mujoco.mjtGeom.mjGEOM_MESH
            vertices=m.mesh_vert[m.mesh_vertadr[k]:m.mesh_vertadr[k]+m.mesh_vertnum[k]].copy()
            rot=np.empty(9);mujoco.mju_quat2Mat(rot,m.geom_quat[g])
            self._sole_vertices.append(vertices@rot.reshape(3,3).T+m.geom_pos[g])
            self._sole_axes.append(d.xmat[m.geom_bodyid[g]].reshape(3,3).T@d.xmat[1].reshape(3,3)[:,1])
            body_names.append(m.body(m.geom_bodyid[g]).name)
        self._sole_body_ids=np.array([m.body(name).id for name in body_names],dtype=np.int32)
        self._physical_scales=np.asarray(cfg.physical_action_scale_rad,dtype=float)
        assert self._physical_scales.shape==(14,) and np.all(self._physical_scales>0)
        self._actual_clip_fraction=0.
        super().__init__(cfg,num_envs=num_envs,backend_type=backend_type)
        self._sole_body_ids=np.array([self._backend.get_body_id(name) for name in body_names],dtype=np.int32)
        bm=mujoco.MjModel.from_binary_path(cfg.warp_compiled_model_file) if backend_type=='mjwarp' else self._backend.get_playback_model(0)
        self._nominal_geom_pos=bm.geom_pos.copy();self._nominal_geom_quat=bm.geom_quat.copy()
        self._sole_geom_ids=[self._backend.get_geom_id(side+'_foot_collision') for side in ['left','right']]
        self._foot_geom_ids=np.array([self._backend.get_geom_id(side+'_'+part+'_collision') for side in ['left','right'] for part in ['foot','ankle']],dtype=np.int32)

    def _refresh_foot_height(self):
        pos,quat=self._backend.get_body_pose_w(self._sole_body_ids)
        for j,vertices in enumerate(self._sole_vertices):
            q=quat[:,j,None,:];v=vertices[None,:,:]
            dq=self._sole_delta_quat[:,j,None,:]
            v=v+2*np.cross(dq[:,:,1:],np.cross(dq[:,:,1:],v)+dq[:,:,:1]*v)
            rotated=v+2*np.cross(q[:,:,1:],np.cross(q[:,:,1:],v)+q[:,:,:1]*v)
            self._foot_height[:,j]=np.maximum(0.,np.min(rotated[:,:,2],axis=1)+pos[:,j,2]-self._ground_z)

    def apply_action(self,actions,state):
        from .velocity import LocomotionBaseEnv
        raw=LocomotionBaseEnv.apply_action(self,actions,state)
        target=self.default_angles+(raw-self.default_angles)*self._physical_scales
        self._actual_clip_fraction=float(np.mean((target<self._target_low)|(target>self._target_high)))
        target=np.clip(target,self._target_low,self._target_high)
        self._previous_action_target[:]=self._current_action_target
        self._current_action_target[:]=target
        return target

    def _log_physical_audit(self,log,dof_vel,torque,action):
        super()._log_physical_audit(log,dof_vel,torque,action)
        log['audit/action_target_clip_fraction']=self._actual_clip_fraction
        target=self._current_action_target
        log['audit/action_target_outside_hard_limit_fraction']=float(np.mean((target<self._joint_limits[:,0])|(target>self._joint_limits[:,1])))

    def _action_rate_cost(self,state):
        # Preserve the original 0.12-rad action unit while using actual targets.
        # Per-joint exploration scaling must not amplify the cost of hip sway.
        delta=(self._current_action_target-self._previous_action_target)/.12
        return np.sum(delta*delta,axis=1)

    def _init_buffers(self):
        super()._init_buffers()
        self._motor_pos_indices=self._backend.get_joint_dof_pos_indices(self._active_names)
        self._motor_vel_indices=self._backend.get_joint_dof_vel_indices(self._active_names)
        self._policy_qpos_indices=self._motor_pos_indices+7
        self._passive_qpos_indices=np.setdiff1d(np.arange(7,len(self._init_qpos)),self._policy_qpos_indices)
        self.default_angles=self._init_qpos[self._policy_qpos_indices].copy()

    def _get_policy_joint_range(self):
        return self._backend.get_joint_range()[self._motor_pos_indices]

    def get_dof_pos(self):
        return self._backend.get_dof_pos()[:,self._motor_pos_indices]

    def get_dof_vel(self):
        return self._backend.get_dof_vel()[:,self._motor_vel_indices]


class SoleTiltReset(RigidModelReset):
    def validate(self,env,capabilities):
        super().validate(env,capabilities)
        if env.cfg.sole_tilt_dr_enabled:
            assert capabilities.supports_reset_term('geom_pos') and capabilities.supports_reset_term('geom_quat')

    def build_reset_plan(self,env,env_ids):
        plan=super().build_reset_plan(env,env_ids)
        if not env.cfg.sole_tilt_dr_enabled:return plan
        from unilab.dr.types import ResetRandomizationPayload
        from unilab.utils.rotation import np_quat_mul
        n=len(env_ids);lo,hi=np.deg2rad(env.cfg.sole_tilt_range_deg)
        angles=env._sole_rng.uniform(lo,hi,(n,2))
        qp=np.broadcast_to(env._nominal_geom_pos,(n,*env._nominal_geom_pos.shape)).copy()
        qq=np.broadcast_to(env._nominal_geom_quat,(n,*env._nominal_geom_quat.shape)).copy()
        for j,g in enumerate(env._sole_geom_ids):
            theta=angles[:,j];axis=env._sole_axes[j]
            dq=np.c_[np.cos(theta/2),np.sin(theta/2)[:,None]*axis]
            v=qp[:,g].copy();u=dq[:,1:]
            qp[:,g]=v+2*np.cross(u,np.cross(u,v)+dq[:,:1]*v)
            qq[:,g]=np_quat_mul(dq,qq[:,g])
            env._sole_delta_quat[env_ids,j]=dq
        env._sole_angles[env_ids]=angles
        if plan.randomization is None:plan.randomization=ResetRandomizationPayload()
        plan.randomization.geom_pos=qp;plan.randomization.geom_quat=qq
        plan.info_updates['sole_tilt_deg']=np.rad2deg(angles)
        return plan
