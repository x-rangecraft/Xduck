"""Official MicroDuck gait task with XDuck V1.1.0 and GF43X40-10 motors.

The reward formulas and command sampler come from the UniLab XL330 official
owner. Geometry is loaded directly from Model/Duck_V1.1.0; the motor, physical
lengths, action units and 1-kHz transport are explicitly adapted for XDuck.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

from unilab.actuators.gf43x40 import GF43X40Parameters, GF43X40RobotMotor
from unilab.base import registry
from unilab.base.backend import create_backend, env_backend_kwargs
from unilab.base.scene import SceneCfg
from unilab.envs.locomotion.common.base import (
    BaseNoiseConfig,
    LocomotionBaseEnv,
    PdControlConfig,
)
from unilab.envs.locomotion.microduck_dm4310.velocity import (
    NUM_ACTIONS,
    SCALE,
    Commands,
    MicroDuckDm4310VelocityEnv,
    MicroDuckDomainRandConfig,
    MicroDuckDRProvider,
    MicroDuckLatencyConfig,
    command_direction_progress,
)
from unilab.envs.locomotion.microduck_xl330_official.velocity import (
    MicroDuckXl330OfficialVelocityCfg,
    MicroDuckXl330OfficialVelocityEnv,
    OfficialCurriculumConfig,
    OfficialRewardConfig,
)

from .scaling import normalized_target_rate_l2, xml_model_fingerprint

_WORKSPACE = Path(__file__).resolve().parents[6]
_SOURCE_SCENE = _WORKSPACE / "Model" / "Duck_V1.1.0" / "scene.xml"
_SENSORS = Path(__file__).with_name("sensors.xml")
_TIME_SCALE = math.sqrt(SCALE)
_MASS_SCALE = 10.352 / 0.73724318


def _xduck_commands() -> Commands:
    return Commands(
        velocity_low=[-0.4 * _TIME_SCALE, -0.3 * _TIME_SCALE, -1.0 / _TIME_SCALE],
        velocity_high=[0.4 * _TIME_SCALE, 0.3 * _TIME_SCALE, 1.0 / _TIME_SCALE],
        resampling_time_range=[3.0 * _TIME_SCALE, 8.0 * _TIME_SCALE],
        forward_min_speed=0.3 * _TIME_SCALE,
        head_resampling_time_range=[2.0 * _TIME_SCALE, 5.0 * _TIME_SCALE],
        body_resampling_time_range=[2.0 * _TIME_SCALE, 5.0 * _TIME_SCALE],
    )


def _xduck_noise() -> BaseNoiseConfig:
    return BaseNoiseConfig(
        level=1.0,
        scale_joint_angle=0.001,
        scale_joint_vel=0.25 / _TIME_SCALE,
        scale_gyro=0.03 / _TIME_SCALE,
        scale_gravity=0.01,
        scale_linvel=0.1 * _TIME_SCALE,
    )


def _xduck_reward_scales() -> dict[str, float]:
    scales = OfficialRewardConfig().scales.copy()
    # Gravity-similar velocity scales as sqrt(length), angular speed as its
    # inverse, and raw angular momentum as mass * length^1.5.
    scales["foot_slip"] /= SCALE
    scales["body_ang_vel"] *= SCALE
    scales["angular_momentum"] /= _MASS_SCALE**2 * SCALE**3
    scales["foot_clearance"] /= SCALE**1.5
    scales["command_progress"] = 0.0
    return scales


@dataclass
class XDuckRewardConfig(OfficialRewardConfig):
    scales: dict[str, float] = field(default_factory=_xduck_reward_scales)
    linear_velocity_std: float = math.sqrt(0.1) * _TIME_SCALE
    angular_velocity_std: float = math.sqrt(0.5) / _TIME_SCALE
    foot_target_height: float = 0.02 * SCALE
    air_time_threshold_min: float = 0.125 * _TIME_SCALE
    air_time_threshold_max: float = 0.300 * _TIME_SCALE
    progress_command_threshold: float = 0.05
    progress_upright_min: float = math.cos(math.radians(30.0))
    action_rate_units: str = "policy"
    action_rate_time_scale: float = 1.0
    action_rate_reference_dt: float = 0.02
    scale_model_fingerprint: str | None = None


@dataclass
class XDuckCurriculumConfig(OfficialCurriculumConfig):
    """Keep official stage boundaries, scaling only dimensional quantities."""

    def __post_init__(self) -> None:
        super().__post_init__()
        for stage in self.linear_velocity_std_stages:
            stage["value"] *= _TIME_SCALE
        for stage in self.angular_velocity_std_stages:
            stage["value"] /= _TIME_SCALE
        for name in ("com_range_stages", "head_com_range_stages"):
            for stage in getattr(self, name):
                stage["value"] *= SCALE
        for stage in self.push_stages:
            stage["value"] *= _TIME_SCALE


@dataclass
class XDuckGFControlConfig(PdControlConfig):
    """Optional 14-axis MIT gains in policy joint order; scalars remain default."""

    joint_kp: list[float] | None = None
    joint_kd: list[float] | None = None


def _gf_domain_rand() -> MicroDuckDomainRandConfig:
    config = MicroDuckDomainRandConfig(
        randomize_base_mass=False,
        random_com=False,
        randomize_ground_friction=False,
        randomize_dof_armature=True,
        dof_armature_multiplier_range=[0.9, 1.1],
        push_robots=False,
        push_body_name="trunk_base",
    )
    # The GF model already owns friction; XML/DR friction would apply it twice.
    config.randomize_joint_friction = False
    config.motor.enabled = False
    return config


@dataclass
class GFCommunicationConfig:
    # Measured sparse late arrivals; uniform mode remains available for sweeps.
    jitter_mode: str = "measured_20260918"
    command_jitter_ms: list[int] = field(default_factory=lambda: [0, 0])
    feedback_jitter_ms: list[int] = field(default_factory=lambda: [0, 0])
    feedback_delay_ms: float = 0.0
    jitter_seed: int = 0


@registry.envcfg("XDuckGF43X40VelocityFlat")
@dataclass
class XDuckGF43X40VelocityCfg(MicroDuckXl330OfficialVelocityCfg):
    scene: SceneCfg = field(
        default_factory=lambda: SceneCfg(
            model_file=str(_SOURCE_SCENE),
            fragment_files=[str(_SENSORS)],
            visual_model_file=str(_SOURCE_SCENE),
        )
    )
    commands: Commands = field(default_factory=_xduck_commands)
    curriculum: XDuckCurriculumConfig = field(default_factory=XDuckCurriculumConfig)
    reward_config: XDuckRewardConfig = field(default_factory=XDuckRewardConfig)
    noise_config: BaseNoiseConfig = field(default_factory=_xduck_noise)
    control_config: XDuckGFControlConfig = field(
        default_factory=lambda: XDuckGFControlConfig(
            action_scale=1.0,
            simulate_action_latency=False,
            Kp=60.0,
            Kd=2.0,
        )
    )
    domain_rand: MicroDuckDomainRandConfig = field(default_factory=_gf_domain_rand)
    latency: MicroDuckLatencyConfig = field(
        default_factory=lambda: MicroDuckLatencyConfig(actuator_delay_ms=[0.0, 0.0])
    )
    sim_dt: float = 0.001
    communication: GFCommunicationConfig = field(default_factory=GFCommunicationConfig)
    # The official policy still explores with unit-std Gaussian actions.  Map
    # that dimensionless action to a feasible initial GF position error.
    policy_action_scale_rad: float = 0.12


class XDuckDRProvider(MicroDuckDRProvider):
    def _finalize_reset_pose(self, env, plan):
        # The official reset does not lift a sampled root pose after drawing it.
        return plan

    def _compute_reset_obs(
        self, env, env_ids, info_updates, linvel, gyro, gravity, dof_pos, dof_vel
    ):
        env._refresh_foot_height()
        return super()._compute_reset_obs(
            env, env_ids, info_updates, linvel, gyro, gravity, dof_pos, dof_vel
        )


@registry.env("XDuckGF43X40VelocityFlat", sim_backend="mujoco")
class XDuckGF43X40VelocityEnv(MicroDuckXl330OfficialVelocityEnv):
    _cfg: XDuckGF43X40VelocityCfg
    _keyframe_name = "STAND"

    def _make_dr_provider(self):
        return XDuckDRProvider()

    def _refresh_foot_height(self) -> None:
        self._foot_height[:] = self._backend.sample_site_clearance(
            self._foot_site_ids, radius=0.04 * SCALE, max_distance=1.0
        )

    def _create_backend(self, cfg, num_envs: int, backend_type: str):
        if backend_type != "mujoco":
            raise ValueError("The GF43X40 whole-robot adapter currently requires MuJoCo")
        parameters = GF43X40Parameters.from_bundle()
        mechanical_limit = float(
            parameters.physics.get("mechanical_torque_limit", parameters.registers["tmax"])
        )
        control_limit = (
            mechanical_limit + float(parameters.registers["pmax"])
            if "mechanical_torque_limit" in parameters.physics
            else 40.0
        )
        armature = np.r_[
            np.zeros(6),
            np.full(NUM_ACTIONS, parameters.physics["armature"]),
        ]
        return create_backend(
            backend_type,
            cfg.scene,
            num_envs,
            cfg.sim_dt,
            base_name=cfg.asset.base_name,
            push_body_name=cfg.domain_rand.push_body_name,
            add_body_sensors=True,
            position_actuator_gains={"kp": 1.0, "kd": 0.0},
            actuator_ctrl_range=(-control_limit, control_limit),
            actuator_force_range=(-mechanical_limit, mechanical_limit),
            dof_armature=armature,
            dof_damping=0.0,
            dof_frictionloss=0.0,
            **env_backend_kwargs(cfg),
        )

    def _build_motor(self, cfg, num_envs: int):
        gains = cfg.control_config.position_gains()
        kp = cfg.control_config.joint_kp
        kd = cfg.control_config.joint_kd
        if (kp is not None and cfg.domain_rand.randomize_kp) or (
            kd is not None and cfg.domain_rand.randomize_kd
        ):
            raise ValueError("per-joint GF gains cannot use scalar gain randomization")
        delay_lo_ms, delay_hi_ms = cfg.latency.actuator_delay_ms
        if delay_lo_ms != delay_hi_ms:
            raise ValueError("GF transport currently requires a fixed actuator delay")
        return GF43X40RobotMotor(
            num_envs,
            NUM_ACTIONS,
            kp=kp if kp is not None else float(gains["kp"]),
            kd=kd if kd is not None else float(gains["kd"]),
            command_delay_s=float(delay_lo_ms) / 1000.0,
            feedback_delay_s=cfg.communication.feedback_delay_ms / 1000.0,
            command_jitter_ms=cfg.communication.command_jitter_ms,
            feedback_jitter_ms=cfg.communication.feedback_jitter_ms,
            jitter_seed=cfg.communication.jitter_seed,
            jitter_mode=cfg.communication.jitter_mode,
        )

    def _build_official_motor(self, num_envs: int):
        del num_envs
        return self._motor

    def __init__(self, cfg, num_envs=1, backend_type="mujoco"):
        fingerprint = cfg.reward_config.scale_model_fingerprint
        if fingerprint is not None and xml_model_fingerprint(cfg.scene.model_file) != fingerprint:
            raise ValueError("XDuck model changed; regenerate the scale-adapted profile")
        if cfg.reward_config.action_rate_units not in ("policy", "physical_target_rate"):
            raise ValueError("action_rate_units must be policy or physical_target_rate")
        for value in (
            cfg.reward_config.action_rate_time_scale,
            cfg.reward_config.action_rate_reference_dt,
        ):
            if not math.isfinite(value) or value <= 0:
                raise ValueError("action-rate time scales must be positive and finite")
        self._current_action_target = np.zeros((num_envs, NUM_ACTIONS), dtype=np.float64)
        self._previous_action_target = np.zeros_like(self._current_action_target)
        super().__init__(cfg, num_envs=num_envs, backend_type=backend_type)
        self._current_action_target[:] = self.default_angles
        self._previous_action_target[:] = self.default_angles
        # The GF owner has no XL330/DM encoder-bias randomization.
        self._encoder_bias.fill(0.0)

    def _reset_episode_history(self, env_ids):
        super()._reset_episode_history(env_ids)
        self._current_action_target[env_ids] = self.default_angles
        self._previous_action_target[env_ids] = self.default_angles

    def _action_rate_cost(self, state):
        cfg = self._cfg.reward_config
        if cfg.action_rate_units == "policy":
            return super()._action_rate_cost(state)
        return normalized_target_rate_l2(
            self._current_action_target,
            self._previous_action_target,
            ctrl_dt=self._cfg.ctrl_dt,
            reference_dt=cfg.action_rate_reference_dt,
            time_scale=cfg.action_rate_time_scale,
        )

    def apply_action(self, actions, state):
        scale = float(self._cfg.policy_action_scale_rad)
        if not 0.0 < scale <= 1.0:
            raise ValueError("policy_action_scale_rad must be in (0, 1]")
        # Keep the learner's raw action in history, as on the XL330 owner.
        # Only the motor position target uses the robot-specific radian scale.
        raw_target = LocomotionBaseEnv.apply_action(self, actions, state)
        target = self.default_angles + (raw_target - self.default_angles) * scale
        if self._cfg.clip_action_targets:
            target = np.clip(target, self._target_low, self._target_high)
        self._previous_action_target[:] = self._current_action_target
        self._current_action_target[:] = target
        return target

    def _compute_reward(self, state, linvel, gyro, upvector, dof_pos):
        reward = super()._compute_reward(state, linvel, gyro, upvector, dof_pos)
        cfg = self._cfg.reward_config
        weight = float(cfg.scales["command_progress"])
        if weight:
            commands = state.info["commands"]
            moving = (
                np.linalg.norm(commands[:, :2], axis=1) + np.abs(commands[:, 2])
                > cfg.progress_command_threshold
            )
            upright = upvector[:, 2] >= cfg.progress_upright_min
            progress = command_direction_progress(linvel, gyro, commands)
            weighted = weight * np.where(moving & upright, progress, 0.0)
            reward += (weighted * self._cfg.ctrl_dt).astype(reward.dtype, copy=False)
            self._episode_reward_sums["command_progress"] += weighted * self._cfg.ctrl_dt
        state.info.setdefault("log", {}).pop("Episode_Reward/command_progress", None)
        return reward

    def _physics_step_action_delay(self, backend, ctrl: np.ndarray) -> np.ndarray:
        motor = self._motor
        if not isinstance(motor, GF43X40RobotMotor):
            return MicroDuckDm4310VelocityEnv._physics_step_action_delay(self, backend, ctrl)
        pos = self.get_dof_pos()
        vel = self.get_dof_vel()
        motor.finish_substep(pos, vel)
        self._sample_substep_foot_state(reset_events=self._delay_substep == 0)
        torque = motor.begin_substep(ctrl, pos, vel)
        self._delay_substep = (self._delay_substep + 1) % self._cfg.sim_substeps
        # The source model's position actuators are made unit-gain/zero-damping
        # on the cold path: target q + tau applies exactly the GF torque.
        return pos + torque

    def update_state(self, state):
        if isinstance(self._motor, GF43X40RobotMotor):
            self._motor.finish_substep(self.get_dof_pos(), self.get_dof_vel())
        result = super().update_state(state)
        log = result.info.setdefault("log", {})
        log["audit/gf_peak_abs_torque_nm"] = float(np.max(np.abs(self._motor.torque)))
        log["audit/gf_mean_abs_torque_nm"] = float(np.mean(np.abs(self._motor.torque)))
        return result
