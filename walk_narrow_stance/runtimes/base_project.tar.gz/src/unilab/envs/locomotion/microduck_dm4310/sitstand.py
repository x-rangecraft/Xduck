"""Commanded sit/stand task ported from mjlab_microduck."""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from unilab.assets import ASSETS_ROOT_PATH
from unilab.base import registry
from unilab.base.np_env import NpEnvState
from unilab.base.scene import SceneCfg
from unilab.dtype_config import get_global_dtype

from .velocity import (
    NUM_ACTIONS,
    Commands,
    CurriculumConfig,
    MicroDuckDm4310VelocityCfg,
    MicroDuckDm4310VelocityEnv,
    MicroDuckDRProvider,
    MicroDuckLatencyConfig,
    RewardConfig,
    _stage,
    pseudo_huber,
    pseudo_huber_norm,
)

SIT_Z = 0.131  # measured nominal DM4340 hold; see docs/microduck_alignment_audit.md
STAND_Z = 0.243
LEG_IDS = np.asarray([0, 1, 2, 3, 4, 9, 10, 11, 12, 13])
SIT_OVERRIDES = {1: 0.0, 2: -0.4079, 3: 1.25, 4: 0.0, 10: 0.0, 11: 0.4079, 12: -1.25, 13: 0.0}
POSTURE_SELF_CONTACTS = tuple(f"self_pair_{index:03d}" for index in range(45))
HEAD_GROUND_FOUND = tuple(f"head_ground_found_{index}" for index in (3, 5))


def posture_self_collision_cost(env) -> np.ndarray:
    found = np.concatenate(
        [env._backend.get_sensor_data(name) for name in POSTURE_SELF_CONTACTS], axis=1
    )
    return np.sum(found > 0.0, axis=1)


def gaussian_head_tracking(error: np.ndarray, std: float) -> np.ndarray:
    """MJLab's per-joint Gaussian head-command tracking score."""
    if std <= 0.0:
        raise ValueError(f"std must be positive, got {std}")
    return np.mean(np.exp(-np.square(error / std)), axis=1)


def normalized_torque_rate_l2(
    torque: np.ndarray,
    previous_torque: np.ndarray,
    rated_torque: np.ndarray,
) -> np.ndarray:
    """Dimensionless torque slew, comparable across XL330 and DM4340 scales."""
    normalized_delta = np.divide(
        torque - previous_torque,
        rated_torque,
        out=np.zeros_like(torque),
        where=rated_torque > 0.0,
    )
    return np.sum(np.square(normalized_delta), axis=1)


def smoothstep01(value: np.ndarray) -> np.ndarray:
    clipped = np.clip(value, 0.0, 1.0)
    return clipped * clipped * (3.0 - 2.0 * clipped)


@dataclass
class SitStandCommands(Commands):
    resampling_time_range: list[float] = field(default_factory=lambda: [5.1, 9.4])
    sit_prob: float = 0.5
    reset_sit_prob: float = 0.5
    ramp_s: float = 3.0
    max_descent_speed: float = 0.080
    max_rise_speed: float = 0.120


@dataclass
class SitStandCurriculum(CurriculumConfig):
    # V1.1.0's heavier head chain remains 16 mm forward. Start from a narrow
    # standing tilt distribution, then recover the original +/-8 degree
    # robustness only after both transitions have consolidated.
    standing_tilt_stages: list[dict[str, float]] = field(
        default_factory=lambda: [
            {"step": 0, "value": 2.0},
            {"step": 144000, "value": 3.0},
            {"step": 288000, "value": 4.0},
            {"step": 480000, "value": 6.0},
            {"step": 720000, "value": 8.0},
        ]
    )
    sitting_tilt_deg: float = 8.0
    # Widen head commands only after the basic bidirectional transition has
    # consolidated; the current all-DM4340 actuator response is 20 ms.
    head_range_stages: list[dict[str, object]] = field(
        default_factory=lambda: [
            {"step": 0, "ranges": [[-0.05, 0.05], [-0.05, 0.05], [-0.07, 0.07], [-0.015, 0.015]]},
            {"step": 144000, "ranges": [[-0.1, 0.1], [-0.1, 0.1], [-0.15, 0.15], [-0.025, 0.025]]},
            {"step": 288000, "ranges": [[-0.2, 0.2], [-0.2, 0.2], [-0.35, 0.35], [-0.05, 0.05]]},
            {"step": 480000, "ranges": [[-0.3, 0.3], [-0.35, 0.35], [-0.65, 0.65], [-0.1, 0.1]]},
            {"step": 720000, "ranges": [[-0.4, 0.4], [-0.5, 0.5], [-1.0, 1.0], [-0.15, 0.15]]},
        ]
    )
    # Avoid taxing discovery.  The final value remains the proven MJLab
    # smoothness weight, but it arrives only after the enlarged robot has
    # experienced both directions at low regularization.
    action_rate_stages: list[dict[str, float]] = field(
        default_factory=lambda: [
            {"step": 0, "value": -0.10},
            {"step": 48000, "value": -0.20},
            {"step": 96000, "value": -0.40},
            {"step": 144000, "value": -0.60},
            {"step": 192000, "value": -0.80},
            {"step": 240000, "value": -1.00},
        ]
    )
    head_bias_stages: list[dict[str, float]] = field(
        default_factory=lambda: [
            {"step": 0, "value": 0.0},
            {"step": 288000, "value": 1.0},
            {"step": 480000, "value": 2.0},
            {"step": 720000, "value": 3.0},
        ]
    )
    posture_composite_stages: list[dict[str, float]] = field(
        default_factory=lambda: [
            {"step": 0, "value": 3.0},
            {"step": 720000, "value": 4.0},
            {"step": 960000, "value": 5.0},
            {"step": 1152000, "value": 6.0},
        ]
    )
    descent_speed_stages: list[dict[str, float]] = field(
        default_factory=lambda: [
            {"step": 0, "value": 10.0},
            {"step": 144000, "value": 20.0},
        ]
    )
    rise_speed_stages: list[dict[str, float]] = field(
        default_factory=lambda: [
            {"step": 0, "value": 0.0},
            {"step": 480000, "value": 5.0},
            {"step": 720000, "value": 10.0},
        ]
    )
    torque_rate_stages: list[dict[str, float]] = field(
        default_factory=lambda: [
            {"step": 0, "value": 0.0},
            {"step": 336000, "value": -5e-06},
            {"step": 480000, "value": -1.25e-05},
            {"step": 672000, "value": -2.5e-05},
        ]
    )
    push_stages: list[dict[str, float]] = field(
        default_factory=lambda: [
            {"step": 0, "value": 0.0},
            {"step": 288000, "value": 0.02},
            {"step": 432000, "value": 0.04},
            {"step": 576000, "value": 0.06},
            {"step": 768000, "value": 0.08},
        ]
    )


@dataclass
class SitStandRewardConfig(RewardConfig):
    scales: dict[str, float] = field(
        default_factory=lambda: {
            "body_ang_vel": -0.05,
            "angular_momentum": -5.0e-7,
            "dof_pos_limits": -1.0,
            "joint_limit_proximity": -1.0,
            "rated_torque_excess": -2.0,
            "joint_speed_excess": -2.0,
            "mechanical_power": -0.02,
            "i2t_usage": -0.25,
            "linear_velocity_error": -0.50,
            "yaw_velocity_error": -0.50,
            "action_rate_l2": -0.10,
            "posture_pose_legs": 4.0,
            "head_pose_tracking": 0.75,
            "head_pose_bias": 0.0,
            "posture_pose_l1": 1.0,
            "posture_height": 1.0,
            "posture_height_sharp": 1.0,
            "posture_height_l1": 6.0,
            "rise_bootstrap": 0.75,
            "descent_speed": 10.0,
            "rise_speed": 0.0,
            "gentle_motion": 0.05,
            "upright_linear": 2.5,
            "upright_while_tall": 1.5,
            "posture_stillness": 2.0,
            "posture_composite": 3.0,
            "joint_torque_rate_l2": 0.0,
            "self_collisions": -1.0,
        }
    )


@registry.envcfg("MicroDuckDm4310SitStandFlat")
@dataclass
class MicroDuckDm4310SitStandCfg(MicroDuckDm4310VelocityCfg):
    # These recipes retain their existing bounded policy distribution.
    clip_action_targets: bool = False
    scene: SceneCfg = field(
        default_factory=lambda: SceneCfg(
            model_file=str(ASSETS_ROOT_PATH / "robots" / "microduck_dm4310" / "scene_posture.xml")
        )
    )
    commands: SitStandCommands = field(default_factory=SitStandCommands)
    latency: MicroDuckLatencyConfig = field(
        default_factory=lambda: MicroDuckLatencyConfig(
            actuator_delay_ms=[10.0, 20.0],
            imu_delay_ms=[0.0, 20.0],
            joint_velocity_delay_ms=20.0,
            imu_delay_update_period_steps=64,
        )
    )
    curriculum: SitStandCurriculum = field(default_factory=SitStandCurriculum)
    reward_config: SitStandRewardConfig = field(default_factory=SitStandRewardConfig)


class SitStandDRProvider(MicroDuckDRProvider):
    def build_reset_plan(self, env, env_ids):
        plan = super().build_reset_plan(env, env_ids)
        n = len(env_ids)
        sitting = np.random.uniform(size=n) < env._cfg.commands.reset_sit_prob
        plan.qpos[:, 2] = np.where(
            sitting,
            np.random.uniform(SIT_Z, SIT_Z + 0.015, size=n),
            np.random.uniform(STAND_Z, STAND_Z + 0.010, size=n),
        )
        yaw = np.random.uniform(-np.pi, np.pi, size=n)
        standing_tilt_deg = float(
            _stage(
                env._cfg.curriculum.standing_tilt_stages,
                env._curriculum_step(),
            )
        )
        tilt_deg = np.where(
            sitting,
            env._cfg.curriculum.sitting_tilt_deg,
            standing_tilt_deg,
        )
        pitch = np.random.uniform(-1.0, 1.0, size=n) * np.deg2rad(tilt_deg)
        roll = np.random.uniform(-1.0, 1.0, size=n) * np.deg2rad(tilt_deg)
        cy, sy = np.cos(yaw * 0.5), np.sin(yaw * 0.5)
        cp, sp = np.cos(pitch * 0.5), np.sin(pitch * 0.5)
        cr, sr = np.cos(roll * 0.5), np.sin(roll * 0.5)
        plan.qpos[:, 3:7] = np.stack(
            (
                cr * cp * cy + sr * sp * sy,
                sr * cp * cy - cr * sp * sy,
                cr * sp * cy + sr * cp * sy,
                cr * cp * sy - sr * sp * cy,
            ),
            axis=1,
        )
        joint = plan.qpos[:, -NUM_ACTIONS:]
        for index, value in SIT_OVERRIDES.items():
            joint[sitting, index] = value
        joint[sitting] += np.random.uniform(
            -env._cfg.posture_reset_joint_jitter_rad,
            env._cfg.posture_reset_joint_jitter_rad,
            size=(np.count_nonzero(sitting), NUM_ACTIONS),
        )
        self._finalize_reset_pose(env, plan)
        # Initialize the hidden ramp from the post-reset spawn height before
        # the first policy/physics step, matching MJLab's first command compute.
        env._posture_alpha[env_ids] = np.clip(
            (STAND_Z - plan.qpos[:, 2]) / max(STAND_Z - SIT_Z, 1e-6), 0.0, 1.0
        )
        return plan


@registry.env("MicroDuckDm4310SitStandFlat", sim_backend="mujoco")
class MicroDuckDm4310SitStandEnv(MicroDuckDm4310VelocityEnv):
    _cfg: MicroDuckDm4310SitStandCfg
    _critic_has_foot_height = False

    def _make_dr_provider(self):
        return SitStandDRProvider()

    def __init__(self, cfg: MicroDuckDm4310SitStandCfg, num_envs=1, backend_type="mujoco"):
        super().__init__(cfg, num_envs, backend_type)
        self._posture_alpha = np.zeros(num_envs, dtype=get_global_dtype())
        self._prev_vz = np.zeros(num_envs, dtype=get_global_dtype())
        self._prev_torque = np.zeros((num_envs, NUM_ACTIONS), dtype=get_global_dtype())
        self._torque_history_fresh = np.ones(num_envs, dtype=bool)

    def _sample_velocity_commands(self, count: int) -> np.ndarray:
        command = np.zeros((count, 3), dtype=get_global_dtype())
        command[:, 0] = np.random.uniform(size=count) < self._cfg.commands.sit_prob
        return command

    def _sample_body_commands(self, count: int) -> np.ndarray:
        return np.zeros((count, 6), dtype=get_global_dtype())

    def _update_curriculum(self) -> None:
        super()._update_curriculum()
        cur = self._cfg.curriculum
        scales = self._cfg.reward_config.scales
        scales["descent_speed"] = float(_stage(cur.descent_speed_stages, self._curriculum_step()))
        scales["rise_speed"] = float(_stage(cur.rise_speed_stages, self._curriculum_step()))
        scales["joint_torque_rate_l2"] = float(
            _stage(cur.torque_rate_stages, self._curriculum_step())
        )
        scales["posture_composite"] = float(
            _stage(cur.posture_composite_stages, self._curriculum_step())
        )
        push = float(_stage(cur.push_stages, self._curriculum_step()))
        self._cfg.domain_rand.velocity_push_xy = [-push, push]

    def _update_posture_alpha(self, state: NpEnvState, z: np.ndarray) -> None:
        del z
        flag = state.info["commands"][:, 0]
        step = self._cfg.ctrl_dt / self._cfg.commands.ramp_s
        self._posture_alpha += np.clip(flag - self._posture_alpha, -step, step)

    def _target(self):
        target = np.broadcast_to(self.default_angles, (self.num_envs, NUM_ACTIONS)).copy()
        sit = target.copy()
        for index, value in SIT_OVERRIDES.items():
            sit[:, index] = value
        target += self._posture_alpha[:, None] * (sit - target)
        target_z = STAND_Z + self._posture_alpha * (SIT_Z - STAND_Z)
        return target, target_z

    def _compute_reward(self, state, linvel, gyro, upvector, dof_pos):
        del linvel
        scales = self._cfg.reward_config.scales
        command = state.info["commands"]
        current = state.info.get("current_actions", np.zeros((self.num_envs, NUM_ACTIONS)))
        last = state.info.get("last_actions", np.zeros_like(current))
        z = self._backend.get_base_pos()[:, 2]
        vel_w = self._backend.get_base_lin_vel()
        vz = vel_w[:, 2]
        speed = np.linalg.norm(vel_w, axis=1)
        quat = self._backend.get_base_quat()
        upright = 1.0 - 2.0 * (np.square(quat[:, 1]) + np.square(quat[:, 2]))
        target, target_z = self._target()
        pose_error = dof_pos[:, LEG_IDS] - target[:, LEG_IDS]
        height_error = z - target_z
        head_error = (dof_pos[:, 5:9] - self.default_angles[5:9]) - command[:, 3:7]
        ema_alpha = min(1.0, self._cfg.ctrl_dt / 1.0)
        self._head_bias_ema = (1.0 - ema_alpha) * self._head_bias_ema + ema_alpha * head_error
        head_found = np.concatenate(
            [self._backend.get_sensor_data(name) for name in HEAD_GROUND_FOUND],
            axis=1,
        )
        head_contact = np.any(head_found > 0.0, axis=1)
        head_error_rms = np.sqrt(np.mean(np.square(head_error), axis=1))
        head_rest_gate = smoothstep01((0.30 - head_error_rms) / 0.20)

        below = np.maximum(self._soft_joint_limits[:, 0] - dof_pos, 0.0)
        above = np.maximum(dof_pos - self._soft_joint_limits[:, 1], 0.0)
        angmom = self._backend.get_sensor_data(self._cfg.sensor.angular_momentum)
        accel_z = (vz - self._prev_vz) / self._cfg.ctrl_dt
        fresh = state.info.get("steps", np.zeros(self.num_envs)) <= 1
        accel_z[fresh] = 0.0
        self._prev_vz[:] = vz
        true_torque = np.concatenate(
            [self._backend.get_sensor_data(name) for name in self._cfg.sensor.actuator_torque],
            axis=1,
        )
        torque = self._motor.quantize_torque_feedback(true_torque)
        self._prev_torque[self._torque_history_fresh] = torque[self._torque_history_fresh]
        torque_rate = normalized_torque_rate_l2(
            torque,
            self._prev_torque,
            self._motor._rated_torque,
        )
        self._prev_torque[:] = torque
        self._torque_history_fresh[:] = False

        terms: dict[str, np.ndarray] = {
            "body_ang_vel": np.sum(np.square(gyro[:, :2]), axis=1),
            "linear_velocity_error": pseudo_huber_norm(
                vel_w[:, :2], self._cfg.reward_config.linear_velocity_error_delta
            ),
            "yaw_velocity_error": pseudo_huber(
                gyro[:, 2], self._cfg.reward_config.yaw_velocity_error_delta
            ),
            "angular_momentum": np.sum(
                np.square(angmom / self._cfg.reward_config.angular_momentum_reference), axis=1
            ),
            "dof_pos_limits": np.sum(below + above, axis=1),
            "action_rate_l2": np.sum(np.square(current - last), axis=1),
            "posture_pose_legs": np.mean(np.exp(-np.square(pose_error / 0.5)), axis=1),
            "head_pose_tracking": gaussian_head_tracking(head_error, std=0.5),
            "head_pose_bias": -np.mean(np.abs(self._head_bias_ema), axis=1),
            "posture_pose_l1": -np.mean(np.abs(pose_error), axis=1),
            "posture_height": np.exp(-np.square(height_error / self._cfg.reward_config.height_std)),
            "posture_height_sharp": np.exp(
                -np.square(height_error / self._cfg.reward_config.height_sharp_std)
            ),
            "posture_height_l1": -np.abs(height_error),
            "rise_bootstrap": np.clip(vz, 0.0, self._cfg.commands.max_rise_speed)
            * (z < (STAND_Z + 0.020))
            * (1.0 - command[:, 0]),
            "descent_speed": -np.maximum(-vz - self._cfg.commands.max_descent_speed, 0.0),
            "rise_speed": -np.maximum(vz - self._cfg.commands.max_rise_speed, 0.0),
            "gentle_motion": -np.abs(accel_z),
            "upright_linear": upright,
            "joint_torque_rate_l2": torque_rate,
            "self_collisions": posture_self_collision_cost(self),
        }
        terms.update(self._physical_cost_terms(dof_pos, self.get_dof_vel(), true_torque))
        tall_t = np.clip((z - 0.160) / (0.210 - 0.160), 0.0, 1.0)
        terms["upright_while_tall"] = upright * tall_t * tall_t * (3.0 - 2.0 * tall_t)

        pose_score = np.exp(-np.mean(np.square(pose_error), axis=1) / 0.4**2)
        height_score = np.exp(
            -np.square(height_error / self._cfg.reward_config.posture_composite_height_std)
        )
        upright_score = np.exp(-(1.0 - upright) / 0.4**2)
        head_score = np.exp(-np.mean(np.square(head_error), axis=1) / 0.4**2)
        terms["posture_composite"] = pose_score * height_score * upright_score * head_score

        flag = command[:, 0]
        ramp_done = np.abs(flag - self._posture_alpha) < 0.02
        err = np.abs(height_error)
        t = np.clip((0.030 - err) / (0.030 - 0.012), 0.0, 1.0)
        z_gate = t * t * (3.0 - 2.0 * t)
        cos_full, cos_zero = np.cos(np.deg2rad(25.0)), np.cos(np.deg2rad(60.0))
        u = np.clip((upright - cos_zero) / (cos_full - cos_zero), 0.0, 1.0)
        tilt_gate = u * u * (3.0 - 2.0 * u)
        terms["posture_stillness"] = (
            np.exp(-np.square(speed / self._cfg.reward_config.stillness_velocity_std))
            * z_gate
            * tilt_gate
            * ramp_done
            * head_rest_gate
        )

        reward = np.zeros(self.num_envs, dtype=get_global_dtype())
        log = state.info.setdefault("log", {})
        for name, value in terms.items():
            weighted = scales[name] * value
            reward += weighted.astype(reward.dtype, copy=False)
            log[f"Episode_Reward/{name}"] = float(np.mean(weighted))
        self._log_physical_audit(log, self.get_dof_vel(), true_torque, current)
        log["audit/head_ground_contact_fraction"] = float(np.mean(head_contact))
        log["audit/head_error_rms"] = float(np.mean(head_error_rms))
        log["curriculum/reset_sit_prob"] = self._cfg.commands.reset_sit_prob
        return reward * self._cfg.ctrl_dt

    def _maybe_resample_commands(self, state: NpEnvState) -> None:
        super()._maybe_resample_commands(state)
        self._update_posture_alpha(state, self._backend.get_base_pos()[:, 2])

    def _terminated(self, upvector: np.ndarray) -> np.ndarray:
        del upvector
        return np.zeros(self.num_envs, dtype=bool)
