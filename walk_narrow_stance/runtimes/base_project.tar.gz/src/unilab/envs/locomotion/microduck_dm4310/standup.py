"""Multi-start stand-up task ported from mjlab_microduck."""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from unilab.assets import ASSETS_ROOT_PATH
from unilab.base import registry
from unilab.base.scene import SceneCfg
from unilab.dtype_config import get_global_dtype

from .sitstand import (
    LEG_IDS,
    SIT_OVERRIDES,
    SIT_Z,
    STAND_Z,
    normalized_torque_rate_l2,
    posture_self_collision_cost,
)
from .velocity import (
    NUM_ACTIONS,
    SCALE,
    Commands,
    CurriculumConfig,
    MicroDuckDm4310VelocityCfg,
    MicroDuckDm4310VelocityEnv,
    MicroDuckDRProvider,
    RewardConfig,
    _stage,
    pseudo_huber,
    pseudo_huber_norm,
)


@dataclass
class StandUpCommands(Commands):
    velocity_low: list[float] = field(default_factory=lambda: [-0.01, -0.01, -0.05])
    velocity_high: list[float] = field(default_factory=lambda: [0.01, 0.01, 0.05])
    resampling_time_range: list[float] = field(default_factory=lambda: [6.0, 12.0])
    rel_forward_envs: float = 0.2
    rel_turn_in_place_envs: float = 0.0
    body_zero_prob: float = 0.3


@dataclass
class StandUpCurriculum(CurriculumConfig):
    ground_mix_stages: list[dict] = field(
        default_factory=lambda: [
            {"step": 0, "value": [0.2, 0.0, 0.4, 0.4]},
            {"step": 57600, "value": [0.35, 0.1, 0.3, 0.25]},
            {"step": 144000, "value": [0.3, 0.25, 0.25, 0.2]},
            {"step": 240000, "value": [0.3, 0.35, 0.2, 0.15]},
        ]
    )
    arrival_damping_stages: list[dict[str, float]] = field(
        default_factory=lambda: [
            {"step": 0, "value": 0.0},
            {"step": 288000, "value": -0.025},
            {"step": 384000, "value": -0.05},
        ]
    )
    # Sufficient to beat fixed-HOME rewards at the audited body-pose witnesses.
    body_pose_weight_stages: list[dict[str, float]] = field(
        default_factory=lambda: [
            {"step": 0, "value": 0.0},
            {"step": 240000, "value": 6.0},
            {"step": 288000, "value": 6.0},
            {"step": 384000, "value": 7.0},
        ]
    )
    head_bias_stages: list[dict[str, float]] = field(
        default_factory=lambda: [
            {"step": 0, "value": 0.0},
            {"step": 288000, "value": 0.5},
            {"step": 384000, "value": 1.5},
        ]
    )
    torque_rate_stages: list[dict[str, float]] = field(
        default_factory=lambda: [
            {"step": 0, "value": 0.0},
            {"step": 336000, "value": -1e-05},
            {"step": 480000, "value": -2.5e-05},
            {"step": 672000, "value": -3.5e-05},
        ]
    )
    sharp_height_stages: list[dict[str, float]] = field(
        default_factory=lambda: [
            {"step": 0, "value": 1.0},
            {"step": 288000, "value": 0.5},
            {"step": 384000, "value": 0.2},
        ]
    )
    sharp_upright_stages: list[dict[str, float]] = field(
        default_factory=lambda: [
            {"step": 0, "value": 1.5},
            {"step": 288000, "value": 1.0},
            {"step": 384000, "value": 0.5},
        ]
    )
    composite_stages: list[dict[str, float]] = field(
        default_factory=lambda: [
            {"step": 0, "value": 3.75},
            {"step": 288000, "value": 2.5},
            {"step": 384000, "value": 1.5},
        ]
    )
    push_stages: list[dict[str, float]] = field(
        default_factory=lambda: [
            {"step": 0, "value": 0.0},
            {"step": 192000, "value": 0.05},
            {"step": 384000, "value": 0.15},
        ]
    )
    body_range_stages: list[dict] = field(
        default_factory=lambda: [
            {
                "step": 0,
                "value": [
                    [-0.005, 0.005],
                    [-0.005, 0.005],
                    [-0.005, 0.005],
                    [-0.05235987755982989, 0.05235987755982989],
                    [-0.05235987755982989, 0.05235987755982989],
                    [-0.05, 0.05],
                ],
            },
            {
                "step": 240000,
                "value": [
                    [-0.005, 0.005],
                    [-0.005, 0.005],
                    [-0.01, 0.005],
                    [-0.08726646259971647, 0.08726646259971647],
                    [-0.08726646259971647, 0.08726646259971647],
                    [-0.05, 0.05],
                ],
            },
            {
                "step": 288000,
                "value": [
                    [-0.005, 0.005],
                    [-0.005, 0.005],
                    [-0.015, 0.005],
                    [-0.13962634015954636, 0.13962634015954636],
                    [-0.13962634015954636, 0.13962634015954636],
                    [-0.05, 0.05],
                ],
            },
            {
                "step": 384000,
                "value": [
                    [-0.005, 0.005],
                    [-0.005, 0.005],
                    [-0.025, 0.01],
                    [-0.17453292519943295, 0.17453292519943295],
                    [-0.17453292519943295, 0.17453292519943295],
                    [-0.05, 0.05],
                ],
            },
        ]
    )


@dataclass
class StandUpRewardConfig(RewardConfig):
    scales: dict[str, float] = field(
        default_factory=lambda: {
            "body_ang_vel": -0.05,
            "angular_momentum": -5.0e-7,
            "dof_pos_limits": -1.0,
            "joint_limit_proximity": -1.0,
            "rated_torque_excess": -2.0,
            "joint_speed_excess": -2.0,
            "mechanical_power": -0.02,
            "i2t_usage": -0.25,
            "linear_velocity_error": -0.50,
            "yaw_velocity_error": -0.50,
            "action_rate_l2": -0.10,
            "pose_stand_legs": 2.0,
            "head_pose_tracking": 0.75,
            "head_pose_bias": 0.0,
            "pose_stand_l1": 1.25,
            "height_stand": 1.0,
            "height_stand_sharp": 1.0,
            "height_stand_l1": 7.5,
            "com_upward_velocity": 0.75,
            "gentle_rise": 0.005,
            "arrival_damping": 0.0,
            "upright_linear": 1.5,
            "upright_sharp": 1.5,
            "standing_composite": 3.75,
            "body_pose_tracking": 0.0,
            "joint_torque_rate_l2": 0.0,
            "self_collisions": -1.0,
        }
    )


@registry.envcfg("MicroDuckDm4310StandUpFlat")
@dataclass
class MicroDuckDm4310StandUpCfg(MicroDuckDm4310VelocityCfg):
    # These recipes retain their existing bounded policy distribution.
    clip_action_targets: bool = False
    scene: SceneCfg = field(
        default_factory=lambda: SceneCfg(
            model_file=str(ASSETS_ROOT_PATH / "robots" / "microduck_dm4310" / "scene_posture.xml")
        )
    )
    commands: StandUpCommands = field(default_factory=StandUpCommands)
    curriculum: StandUpCurriculum = field(default_factory=StandUpCurriculum)
    reward_config: StandUpRewardConfig = field(default_factory=StandUpRewardConfig)


class StandUpDRProvider(MicroDuckDRProvider):
    def build_reset_plan(self, env, env_ids):
        plan = super().build_reset_plan(env, env_ids)
        n = len(env_ids)
        mix = np.asarray(env._ground_mix, dtype=np.float64)
        kind = np.random.choice(4, size=n, p=mix / mix.sum())
        face_down, face_up, sitting, standing = (kind == i for i in range(4))
        prone = face_down | face_up
        yaw = np.random.uniform(-np.pi, np.pi, size=n)
        cy, sy = np.cos(yaw * 0.5), np.sin(yaw * 0.5)
        s = 2.0**-0.5
        q_face_down = np.stack((s * cy, -s * sy, s * cy, s * sy), axis=1)
        q_face_up = np.stack((s * cy, s * sy, -s * cy, s * sy), axis=1)
        theta = np.random.uniform(-np.pi / 2.0, np.pi / 2.0, size=n)
        ct, st = np.cos(theta * 0.5), np.sin(theta * 0.5)
        w, x, y, z = q_face_up.T
        q_face_up = np.stack(
            (w * ct - z * st, x * ct + y * st, y * ct - x * st, w * st + z * ct),
            axis=1,
        )
        pitch = np.random.uniform(-np.deg2rad(10.0), np.deg2rad(10.0), size=n)
        roll = np.random.uniform(-np.deg2rad(10.0), np.deg2rad(10.0), size=n)
        cp, sp = np.cos(pitch * 0.5), np.sin(pitch * 0.5)
        cr, sr = np.cos(roll * 0.5), np.sin(roll * 0.5)
        q_upright = np.stack(
            (
                cr * cp * cy + sr * sp * sy,
                sr * cp * cy - cr * sp * sy,
                cr * sp * cy + sr * cp * sy,
                cr * cp * sy - sr * sp * cy,
            ),
            axis=1,
        )
        plan.qpos[prone, 2] = np.random.uniform(0.05 * SCALE, 0.09 * SCALE, np.count_nonzero(prone))
        plan.qpos[face_down, 3:7] = q_face_down[face_down]
        plan.qpos[face_up, 3:7] = q_face_up[face_up]
        plan.qpos[sitting, 2] = np.random.uniform(
            0.05 * SCALE, 0.09 * SCALE, np.count_nonzero(sitting)
        )
        plan.qpos[standing, 2] = np.random.uniform(
            STAND_Z, STAND_Z + 0.010, np.count_nonzero(standing)
        )
        plan.qpos[sitting | standing, 3:7] = q_upright[sitting | standing]
        joint = plan.qpos[:, -NUM_ACTIONS:]
        for index, value in SIT_OVERRIDES.items():
            joint[sitting, index] = value
        joint[sitting] += np.random.uniform(
            -env._cfg.posture_reset_joint_jitter_rad,
            env._cfg.posture_reset_joint_jitter_rad,
            size=(np.count_nonzero(sitting), NUM_ACTIONS),
        )
        return self._finalize_reset_pose(env, plan)


@registry.env("MicroDuckDm4310StandUpFlat", sim_backend="mujoco")
class MicroDuckDm4310StandUpEnv(MicroDuckDm4310VelocityEnv):
    _cfg: MicroDuckDm4310StandUpCfg
    _critic_has_foot_height = False

    def _make_dr_provider(self):
        return StandUpDRProvider()

    def _terminated(self, upvector: np.ndarray) -> np.ndarray:
        del upvector
        return np.zeros(self.num_envs, dtype=bool)

    def __init__(self, cfg: MicroDuckDm4310StandUpCfg, num_envs=1, backend_type="mujoco"):
        self._ground_mix = [0.2, 0.0, 0.4, 0.4]
        self._body_ranges = cfg.curriculum.body_range_stages[0]["value"]
        super().__init__(cfg, num_envs, backend_type)
        self._prev_vz = np.zeros(num_envs, dtype=get_global_dtype())
        self._prev_torque = np.zeros((num_envs, NUM_ACTIONS), dtype=get_global_dtype())
        self._torque_history_fresh = np.ones(num_envs, dtype=bool)

    def _sample_body_commands(self, count: int) -> np.ndarray:
        ranges = np.asarray(self._body_ranges, dtype=get_global_dtype())
        command = np.asarray(
            np.random.uniform(ranges[:, 0], ranges[:, 1], size=(count, 6)),
            dtype=get_global_dtype(),
        )
        command[np.random.uniform(size=count) < self._cfg.commands.body_zero_prob] = 0.0
        return command

    def _update_curriculum(self) -> None:
        super()._update_curriculum()
        cur = self._cfg.curriculum
        scales = self._cfg.reward_config.scales
        self._ground_mix = _stage(cur.ground_mix_stages, self._curriculum_step())
        self._body_ranges = _stage(cur.body_range_stages, self._curriculum_step())
        scales["arrival_damping"] = float(
            _stage(cur.arrival_damping_stages, self._curriculum_step())
        )
        scales["body_pose_tracking"] = float(
            _stage(cur.body_pose_weight_stages, self._curriculum_step())
        )
        scales["head_pose_bias"] = float(_stage(cur.head_bias_stages, self._curriculum_step()))
        scales["joint_torque_rate_l2"] = float(
            _stage(cur.torque_rate_stages, self._curriculum_step())
        )
        scales["height_stand_sharp"] = float(
            _stage(cur.sharp_height_stages, self._curriculum_step())
        )
        scales["upright_sharp"] = float(_stage(cur.sharp_upright_stages, self._curriculum_step()))
        scales["standing_composite"] = float(_stage(cur.composite_stages, self._curriculum_step()))
        push = float(_stage(cur.push_stages, self._curriculum_step()))
        self._cfg.domain_rand.velocity_push_xy = [-push, push]

    @staticmethod
    def _smooth_gate(value, low, high):
        t = np.clip((value - low) / max(high - low, 1e-6), 0.0, 1.0)
        return t * t * (3.0 - 2.0 * t)

    def _compute_reward(self, state, linvel, gyro, upvector, dof_pos):
        del linvel
        scales = self._cfg.reward_config.scales
        command = state.info["commands"]
        current = state.info.get("current_actions", np.zeros((self.num_envs, NUM_ACTIONS)))
        last = state.info.get("last_actions", np.zeros_like(current))
        z = self._backend.get_base_pos()[:, 2]
        quat = self._backend.get_base_quat()
        upright = 1.0 - 2.0 * (np.square(quat[:, 1]) + np.square(quat[:, 2]))
        vel_w = self._backend.get_base_lin_vel()
        vz = vel_w[:, 2]
        pose_error = dof_pos[:, LEG_IDS] - self.default_angles[LEG_IDS]
        height_error = z - STAND_Z
        head_error = (dof_pos[:, 5:9] - self.default_angles[5:9]) - command[:, 3:7]
        below = np.maximum(self._soft_joint_limits[:, 0] - dof_pos, 0.0)
        above = np.maximum(dof_pos - self._soft_joint_limits[:, 1], 0.0)
        angmom = self._backend.get_sensor_data(self._cfg.sensor.angular_momentum)
        true_torque = np.concatenate(
            [self._backend.get_sensor_data(name) for name in self._cfg.sensor.actuator_torque],
            axis=1,
        )
        torque = self._motor.quantize_torque_feedback(true_torque)
        self._prev_torque[self._torque_history_fresh] = torque[self._torque_history_fresh]
        torque_rate = normalized_torque_rate_l2(
            torque, self._prev_torque, self._motor._rated_torque
        )
        self._prev_torque[:] = torque
        self._torque_history_fresh[:] = False
        accel_z = (vz - self._prev_vz) / self._cfg.ctrl_dt
        fresh = state.info.get("steps", np.zeros(self.num_envs)) <= 1
        accel_z[fresh] = 0.0
        self._prev_vz[:] = vz
        tilt_deg = np.rad2deg(np.arccos(np.clip(upright, -1.0, 1.0)))
        height_arrival = self._smooth_gate(z, 0.190, 0.230)
        tilt_arrival = 1.0 - self._smooth_gate(tilt_deg, 20.0, 45.0)
        arrival_gate = height_arrival * tilt_arrival

        terms: dict[str, np.ndarray] = {
            "body_ang_vel": np.sum(np.square(gyro[:, :2]), axis=1),
            "linear_velocity_error": pseudo_huber_norm(
                vel_w[:, :2], self._cfg.reward_config.linear_velocity_error_delta
            )
            * arrival_gate,
            "yaw_velocity_error": pseudo_huber(
                gyro[:, 2], self._cfg.reward_config.yaw_velocity_error_delta
            )
            * arrival_gate,
            "angular_momentum": np.sum(
                np.square(angmom / self._cfg.reward_config.angular_momentum_reference), axis=1
            ),
            "dof_pos_limits": np.sum(below + above, axis=1),
            "action_rate_l2": np.sum(np.square(current - last), axis=1),
            "pose_stand_legs": np.mean(np.exp(-np.square(pose_error / 0.5)), axis=1),
            "head_pose_tracking": np.mean(np.exp(-np.square(head_error / 0.5)), axis=1),
            "pose_stand_l1": -np.mean(np.abs(pose_error), axis=1),
            "height_stand": np.exp(-np.square(height_error / self._cfg.reward_config.height_std)),
            "height_stand_sharp": np.exp(
                -np.square(height_error / self._cfg.reward_config.height_sharp_std)
            ),
            "height_stand_l1": -np.abs(height_error),
            "com_upward_velocity": np.clip(vz, 0.0, 0.15) * (z < STAND_Z + 0.020),
            "gentle_rise": -np.abs(accel_z),
            "upright_linear": upright,
            "joint_torque_rate_l2": torque_rate,
            "self_collisions": posture_self_collision_cost(self),
        }
        terms.update(self._physical_cost_terms(dof_pos, self.get_dof_vel(), true_torque))
        height_gate = self._smooth_gate(z, SIT_Z, STAND_Z)
        terms["upright_sharp"] = np.exp(-(1.0 - upright) / 0.3**2) * height_gate
        pose_score = np.exp(-np.mean(np.square(pose_error), axis=1) / 0.4**2)
        height_score = np.exp(-np.square(height_error / self._cfg.reward_config.height_std))
        upright_score = np.exp(-(1.0 - upright) / 0.4**2)
        terms["standing_composite"] = pose_score * height_score * upright_score

        terms["arrival_damping"] = (
            np.sum(np.square(gyro[:, :2]), axis=1) * height_arrival * tilt_arrival
        )
        gated_head_error = head_error * (height_arrival * tilt_arrival)[:, None]
        alpha = min(1.0, self._cfg.ctrl_dt / 1.0)
        self._head_bias_ema = (1.0 - alpha) * self._head_bias_ema + alpha * gated_head_error
        terms["head_pose_bias"] = (
            -np.mean(np.abs(self._head_bias_ema), axis=1) * height_arrival * tilt_arrival
        )

        roll = np.arctan2(
            2 * (quat[:, 0] * quat[:, 1] + quat[:, 2] * quat[:, 3]),
            1 - 2 * (np.square(quat[:, 1]) + np.square(quat[:, 2])),
        )
        pitch = np.arcsin(
            np.clip(2 * (quat[:, 0] * quat[:, 2] - quat[:, 3] * quat[:, 1]), -1.0, 1.0)
        )
        body_error = np.stack(
            (z - (STAND_Z + command[:, 9]), roll - command[:, 10], pitch - command[:, 11]), axis=1
        )
        terms["body_pose_tracking"] = np.mean(
            np.exp(-np.square(body_error / np.asarray([0.010, np.deg2rad(5), np.deg2rad(5)]))),
            axis=1,
        )

        reward = np.zeros(self.num_envs, dtype=get_global_dtype())
        log = state.info.setdefault("log", {})
        for name, value in terms.items():
            weighted = scales[name] * value
            reward += weighted.astype(reward.dtype, copy=False)
            log[f"Episode_Reward/{name}"] = float(np.mean(weighted))
        self._log_physical_audit(log, self.get_dof_vel(), true_torque, current)
        return reward * self._cfg.ctrl_dt
