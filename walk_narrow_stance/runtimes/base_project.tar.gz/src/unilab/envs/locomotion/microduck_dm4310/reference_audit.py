"""Cold-path ONNX reference replay with the upstream BAM CPU controller.

No learning occurs. The large-model kinematic lift is an explicitly labeled
counterfactual used to compare inertia-sensitive costs, not a target trajectory.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import mujoco
import numpy as np
import onnxruntime as ort
from bam.model import load_model
from bam.mujoco import MujocoController

SIT = {1: 0.0, 2: -0.4079, 3: 1.35, 4: 0.0, 10: 0.0, 11: 0.4079, 12: -1.35, 13: 0.0}


def replay(workspace, task, case, seed, out):
    rng = np.random.default_rng(seed)
    robot = workspace / "mjlab/src/mjlab_microduck/robot/microduck"
    scene = "scene_walk.xml" if task == "walking" else "scene.xml"
    model = mujoco.MjModel.from_xml_path(str(robot / scene))
    model.opt.timestep = 0.005
    data = mujoco.MjData(model)
    floor_id = model.geom("floor").id
    foot_geom_ids = np.asarray(
        [model.geom("left_foot_collision").id, model.geom("right_foot_collision").id]
    )
    foot_site_ids = np.asarray([model.site("left_foot").id, model.site("right_foot").id])
    mujoco.mj_resetDataKeyframe(model, data, model.key("STAND").id)
    default = data.qpos[7:].copy()
    if case in ("sitting", "sit_first"):
        for i, value in SIT.items():
            data.qpos[7 + i] = value
        data.qpos[2] = 0.07
    if case in ("prone", "supine"):
        data.qpos[2] = 0.07
        sign = 1 if case == "prone" else -1
        data.qpos[3:7] = [2**-0.5, 0, sign * 2**-0.5, 0]
    if seed:
        data.qpos[7:] += rng.normal(0, 0.015, 14)
    bam = load_model(motor_name="xl330", model="m6")
    bam.actuator.kp = 200.0
    bam.actuator.vin = 7.35
    model.actuator_gainprm[:] = 0
    model.actuator_gainprm[:, 0] = 1
    model.actuator_biasprm[:] = 0
    model.actuator_ctrlrange[:] = [-100, 100]
    limit = 8.2 * bam.kt.value / bam.R.value
    model.actuator_forcerange[:] = [-limit, limit]
    model.dof_solref[6:] = [-5e4, -2e2]
    model.dof_solimp[6:] = [0.99, 0.9999, 0.001, 0.5, 2]
    controller = MujocoController(
        bam,
        [model.actuator(i).name for i in range(14)],
        model,
        data,
        vin_drop_gain=0.1,
        vin_min=6.0,
    )
    controller.reset(data.qpos)
    mujoco.mj_forward(model, data)
    onnx = workspace / f"mjlab/models_123/alpha_{task}.onnx"
    session = ort.InferenceSession(str(onnx), providers=["CPUExecutionProvider"])
    large = mujoco.MjModel.from_xml_path(
        str(workspace / "unilab/src/unilab/assets/robots/microduck_dm4310/scene_posture.xml")
    )
    ld = mujoco.MjData(large)
    large_foot_site_ids = np.asarray(
        [large.site("left_foot").id, large.site("right_foot").id]
    )
    command = np.zeros(13)
    action = np.zeros(14)
    targets = []
    rows = {
        key: []
        for key in (
            "time",
            "qpos",
            "qvel",
            "qacc",
            "action",
            "torque",
            "angular_momentum",
            "large_kinematic_angular_momentum",
            "upright",
            "command",
            "local_velocity",
            "gyro",
            "foot_contact",
            "stance_width",
            "large_kinematic_stance_width",
        )
    }
    for step in range(2400):
        if step % 4 == 0:
            if task == "walking":
                cmds = {
                    "idle": [0, 0, 0],
                    "forward": [0.2, 0, 0],
                    "fast": [0.4, 0, 0],
                    "lateral": [0, 0.2, 0],
                    "turn": [0, 0, 1.0],
                    "backward": [-0.2, 0, 0],
                    "lateral_right": [0, -0.2, 0],
                    "turn_right": [0, 0, -1.0],
                    "forward_gate": [0.1, 0, 0],
                    "backward_gate": [-0.1, 0, 0],
                    "lateral_left_gate": [0, 0.075, 0],
                    "lateral_right_gate": [0, -0.075, 0],
                    "turn_left_gate": [0, 0, 0.25],
                    "turn_right_gate": [0, 0, -0.25],
                }
                command[:3] = cmds[case]
            elif task == "sitstand":
                command[0] = (
                    (data.time < 3 or data.time >= 8)
                    if case == "sit_first"
                    else (3 <= data.time < 8)
                )
            R = data.xmat[1].reshape(3, 3)
            obs = np.r_[
                data.sensor("imu_ang_vel").data,
                R.T @ [0, 0, -1],
                data.qpos[7:] - default,
                data.qvel[6:],
                action,
                command,
            ].astype(np.float32)[None]
            action = session.run(None, {"obs": obs})[0][0]
            targets.append(default + action)
        # Fixed 20 ms nominal transport lag, within the source's 15--30 ms range.
        controller.q_target = targets[max(0, len(targets) - 2)]
        controller.update()
        mujoco.mj_step(model, data)
        if step % 4:
            continue
        # Matched joint kinematics, geometry-scaled base translation ONLY for this
        # diagnostic. Evaluate the actual new inertias and changed COM offsets.
        ld.qpos[:] = data.qpos
        ld.qpos[:3] *= 2.09
        ld.qvel[:] = data.qvel
        ld.qvel[:3] *= 2.09
        mujoco.mj_forward(large, ld)
        rows["time"].append(data.time)
        rows["qpos"].append(data.qpos.copy())
        rows["qvel"].append(data.qvel.copy())
        rows["qacc"].append(data.qacc.copy())
        rows["action"].append(action.copy())
        rows["torque"].append(data.ctrl.copy())
        rows["angular_momentum"].append(data.sensor("root_angmom").data.copy())
        rows["large_kinematic_angular_momentum"].append(ld.sensor("root_angmom").data.copy())
        rows["upright"].append(data.xmat[1, 8])
        rows["command"].append(command.copy())
        root_rotation = data.xmat[1].reshape(3, 3)
        rows["local_velocity"].append(root_rotation.T @ data.qvel[:3])
        rows["gyro"].append(data.sensor("imu_ang_vel").data.copy())
        contact_pairs = {
            (int(contact.geom1), int(contact.geom2)) for contact in data.contact[: data.ncon]
        }
        rows["foot_contact"].append(
            [
                (floor_id, int(foot_id)) in contact_pairs
                or (int(foot_id), floor_id) in contact_pairs
                for foot_id in foot_geom_ids
            ]
        )
        foot_y = data.site_xpos[foot_site_ids, 1]
        rows["stance_width"].append(abs(float(foot_y[0] - foot_y[1])))
        large_foot_y = ld.site_xpos[large_foot_site_ids, 1]
        rows["large_kinematic_stance_width"].append(
            abs(float(large_foot_y[0] - large_foot_y[1]))
        )
    rows = {key: np.asarray(value) for key, value in rows.items()}
    path = out / f"{task}_{case}_{seed}.npz"
    np.savez_compressed(path, **rows)
    velocity = np.abs(rows["qvel"][:, 6:])
    action_delta = np.diff(rows["action"], axis=0)
    warm = rows["time"] >= (0.1 if task == "stand" else 2.0)
    old_L2 = np.sum(rows["angular_momentum"][warm] ** 2, axis=1)
    new_L2 = np.sum(rows["large_kinematic_angular_momentum"][warm] ** 2, axis=1)
    contact_count = np.sum(rows["foot_contact"][warm], axis=1)
    contact_change = np.any(np.diff(rows["foot_contact"][warm], axis=0), axis=1)
    warm_duration = max(float(np.sum(warm)) * 0.02, 0.02)
    last = rows["time"] >= 11
    upright = rows["upright"]
    final_z = rows["qpos"][last, 2]
    return {
        "task": task,
        "case": case,
        "seed": seed,
        "npz": path.name,
        "onnx_sha256": hashlib.sha256(onnx.read_bytes()).hexdigest(),
        "final_upright_min": float(np.min(upright[last])),
        "final_z_mean": float(np.mean(final_z)),
        "upright_fraction_after_2s": float(np.mean(upright[warm] > 0.9)),
        "actual_vx_vy_yaw_mean": np.mean(
            np.column_stack(
                (
                    rows["local_velocity"][warm, :2],
                    rows["gyro"][warm, 2],
                )
            ),
            axis=0,
        ).tolist(),
        "both_feet_contact_fraction": float(np.mean(contact_count == 2)),
        "single_foot_contact_fraction": float(np.mean(contact_count == 1)),
        "airborne_fraction": float(np.mean(contact_count == 0)),
        "contact_changes_per_second": float(np.sum(contact_change) / warm_duration),
        "stance_width_mean_m": float(np.mean(rows["stance_width"][warm])),
        "stance_width_min_m": float(np.min(rows["stance_width"][warm])),
        "stance_width_max_m": float(np.max(rows["stance_width"][warm])),
        "large_kinematic_stance_width_mean_m": float(
            np.mean(rows["large_kinematic_stance_width"][warm])
        ),
        "large_kinematic_stance_width_min_m": float(
            np.min(rows["large_kinematic_stance_width"][warm])
        ),
        "large_kinematic_stance_width_max_m": float(
            np.max(rows["large_kinematic_stance_width"][warm])
        ),
        "joint_speed_p95": np.percentile(velocity[warm], 95, axis=0).tolist(),
        "joint_speed_max": np.max(velocity[warm], axis=0).tolist(),
        "new_no_load_speed_exceed_fraction": float(np.mean(velocity[warm] > 5.80952381)),
        "powered_overspeed_fraction": float(
            np.mean(
                (velocity[warm] > 5.80952381) & (rows["torque"][warm] * rows["qvel"][warm, 6:] > 0)
            )
        ),
        "torque_abs_p95": np.percentile(np.abs(rows["torque"][warm]), 95, axis=0).tolist(),
        "action_delta_l2_mean": float(np.mean(np.sum(action_delta**2, axis=1))),
        "torque_delta_l2_mean": float(
            np.mean(np.sum(np.diff(rows["torque"], axis=0) ** 2, axis=1))
        ),
        "old_L2_mean": float(np.mean(old_L2)),
        "new_kinematic_L2_mean": float(np.mean(new_L2)),
        "previous_normalized_momentum_cost_amplification": float(
            np.mean(new_L2) / 0.25**2 / max(np.mean(old_L2), 1e-16)
        ),
        "empirical_matched_momentum_weight": float(
            -0.02 * 0.25**2 * np.mean(old_L2) / max(np.mean(new_L2), 1e-16)
        ),
    }


def actuator_linearization():
    bam = load_model(motor_name="xl330", model="m6")
    act = bam.actuator
    act.kp = 200.0
    act.vin = 7.35
    epsilon = 0.0001
    position_control = act.compute_control(epsilon, 0.0, 0.0, 0.005)
    velocity_control = act.compute_control(0.0, 0.0, epsilon, 0.005)
    return {
        "kp_nm_per_rad_at_7_35v": float(
            act.compute_torque(position_control, True, 0.0, 0.0) / epsilon
        ),
        "electrical_kd_nm_s_per_rad": float(
            -act.compute_torque(velocity_control, True, 0.0, epsilon) / epsilon
        ),
        "stall_nm_at_7_35v": float(act.vin * bam.kt.value / bam.R.value),
        "firmware_max_current_a": act.max_current,
        "current_limited_stall_nm": float(
            act.compute_torque(act.compute_control(100.0, 0.0, 0.0, 0.005), True, 0.0, 0.0)
        ),
        "derivative_probe_rad": epsilon,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    workspace = Path(__file__).resolve().parents[6]
    results = []
    for task, cases in [
        (
            "walking",
            [
                "idle",
                "forward",
                "fast",
                "lateral",
                "turn",
                "backward",
                "lateral_right",
                "turn_right",
                "forward_gate",
                "backward_gate",
                "lateral_left_gate",
                "lateral_right_gate",
                "turn_left_gate",
                "turn_right_gate",
            ],
        ),
        ("stand", ["standing", "sitting", "prone", "supine"]),
        ("sitstand", ["sit_first", "stand_first"]),
    ]:
        for case in cases:
            for seed in range(3):
                result = replay(workspace, task, case, seed, args.output)
                results.append(result)
                print(task, case, seed, round(result["final_upright_min"], 3), flush=True)
    (args.output / "summary.json").write_text(
        json.dumps(
            {
                "scope": "Nominal CPU BAM M6 replay: kp_fw=200, vin=7.35, sag=.1, delay=20ms; no full DR.",
                "runs": results,
                "actuator_linearization": actuator_linearization(),
            },
            indent=2,
        )
        + "\n"
    )


if __name__ == "__main__":
    main()
