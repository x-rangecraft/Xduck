"""Offline, cold-path pretraining calculations; never imported by env step/reset.

Uses scipy and BAM from the reference MJLab environment. This analysis is not
an alternative simulation backend or a policy controller. LPs describe necessary
static feasibility at sampled poses, not a proof of closed-loop robustness.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import itertools
import json
from pathlib import Path

import mujoco
import numpy as np
from scipy.optimize import least_squares, linprog
from scipy.spatial import ConvexHull

JOINTS = [
    "left_hip_yaw",
    "left_hip_roll",
    "left_hip_pitch",
    "left_knee",
    "left_ankle",
    "neck_pitch",
    "head_pitch",
    "head_yaw",
    "head_roll",
    "right_hip_yaw",
    "right_hip_roll",
    "right_hip_pitch",
    "right_knee",
    "right_ankle",
]
HEAD_COM_NAMES = ["neck", "neck_pitch", "yaw_roll_motion", "jaw_soft", "bearing_roll"]
LEGS = [0, 1, 2, 3, 4, 9, 10, 11, 12, 13]
SIT = {1: 0.0, 2: -0.4079, 3: 1.35, 4: 0.0, 10: 0.0, 11: 0.4079, 12: -1.35, 13: 0.0}


def home(model):
    for name in ("home", "STAND"):
        if mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_KEY, name) >= 0:
            return model.key(name).qpos.copy()
    raise ValueError("No standing keyframe")


def mesh_points(model, data, geom):
    mid = model.geom_dataid[geom]
    if model.geom_type[geom] != mujoco.mjtGeom.mjGEOM_MESH:
        raise ValueError("Audit expects the released mesh foot collision")
    start, n = model.mesh_vertadr[mid], model.mesh_vertnum[mid]
    vertices = model.mesh_vert[start : start + n]
    return vertices @ data.geom_xmat[geom].reshape(3, 3).T + data.geom_xpos[geom]


def inertia_about_com(model, data):
    center = data.subtree_com[1]
    inertia = np.zeros((3, 3))
    for body in range(1, model.nbody):
        r = data.xipos[body] - center
        R = data.ximat[body].reshape(3, 3)
        inertia += R @ np.diag(model.body_inertia[body]) @ R.T
        inertia += model.body_mass[body] * (r @ r * np.eye(3) - np.outer(r, r))
    return inertia


def foot_support(model, data):
    points, bodies = [], []
    for name in ["left_foot_collision", "right_foot_collision"]:
        gid = model.geom(name).id
        verts = mesh_points(model, data, gid)
        # Actual bottom vertices, not the entire projected robot mesh.
        bottom = verts[verts[:, 2] <= verts[:, 2].min() + 0.001]
        hull = ConvexHull(bottom[:, :2])
        bottom = bottom[hull.vertices]
        points.extend(bottom)
        bodies.extend([model.geom_bodyid[gid]] * len(bottom))
    return np.asarray(points), np.asarray(bodies)


def support_margin(points, xy):
    hull = ConvexHull(points[:, :2])
    equations = hull.equations
    return float(
        np.min(
            -(equations[:, :2] @ xy + equations[:, 2]) / np.linalg.norm(equations[:, :2], axis=1)
        )
    )


def static_lp(model, data, points, bodies, motor_torque=8.9, mu=0.7):
    """Minimum max motor utilization: Jc.T f + S.T tau = gravity.

    Four-sided friction pyramid is INSCRIBED in the Coulomb cone. Failed LP
    means this conservative contact representation cannot certify the pose.
    Successful LP is only static wrench feasibility, not local stability.
    """
    n = len(points)
    jac = np.zeros((3, model.nv))
    columns = []
    for point, body in zip(points, bodies, strict=True):
        mujoco.mj_jac(model, data, jac, None, point, int(body))
        columns.append(jac.T.copy())
    J = np.concatenate(columns, axis=1)
    selection = np.zeros((model.nv, 14))
    selection[6:, :] = np.eye(14)
    Aeq = np.c_[J, selection, np.zeros(model.nv)]
    Aub, bub = [], []
    for i in range(n):
        for axis in (0, 1):
            for sign in (-1, 1):
                row = np.zeros(3 * n + 15)
                row[3 * i + axis] = sign
                row[3 * i + 2] = -mu / np.sqrt(2)
                Aub.append(row)
                bub.append(0.0)
    for j in range(14):
        for sign in (-1, 1):
            row = np.zeros(3 * n + 15)
            row[3 * n + j] = sign
            row[-1] = -motor_torque
            Aub.append(row)
            bub.append(0.0)
    bounds = [(None, None), (None, None), (0, None)] * n + [(None, None)] * 14 + [(0, None)]
    objective = np.zeros(3 * n + 15)
    objective[-1] = 1
    result = linprog(
        objective,
        A_ub=Aub,
        b_ub=bub,
        A_eq=Aeq,
        b_eq=data.qfrc_bias.copy(),
        bounds=bounds,
        method="highs",
    )
    if not result.success:
        return {"feasible": False, "status": result.message}
    return {
        "feasible": True,
        "rated_utilization": float(result.x[-1]),
        "torque_nm": result.x[3 * n : 3 * n + 14].tolist(),
        "equality_residual": float(np.max(np.abs(Aeq @ result.x - data.qfrc_bias))),
    }


def body_metrics(model):
    data = mujoco.MjData(model)
    data.qpos[:] = home(model)
    mujoco.mj_forward(model, data)
    I = inertia_about_com(model, data)
    mass = float(model.body_mass.sum())
    rows = []
    for i in range(1, model.nbody):
        principal = model.body_inertia[i]
        rows.append(
            {
                "body": model.body(i).name,
                "mass_kg": float(model.body_mass[i]),
                "mass_fraction": float(model.body_mass[i] / mass),
                "local_com_m": model.body_ipos[i].tolist(),
                "local_body_pos_m": model.body_pos[i].tolist(),
                "local_body_quat": model.body_quat[i].tolist(),
                "inertial_quat": model.body_iquat[i].tolist(),
                "world_com_m": data.xipos[i].tolist(),
                "inertia_principal": principal.tolist(),
                "valid_inertia": bool(
                    np.all(principal > 0) and 2 * np.max(principal) <= np.sum(principal) + 1e-10
                ),
            }
        )
    full = np.empty((model.nv, model.nv))
    mujoco.mj_fullM(model, data, full)
    effective = 1 / np.diag(np.linalg.inv(full))[6:]
    return {
        "mass_kg": mass,
        "com_world_m": data.subtree_com[1].tolist(),
        "locked_inertia_com_kg_m2": I.tolist(),
        "principal_inertia_kg_m2": np.linalg.eigvalsh(I).tolist(),
        "joint_effective_inertia_kg_m2": effective.tolist(),
        "bodies": rows,
    }


def stage_value(stages, step):
    eligible = [entry for entry in stages if entry["step"] <= step]
    entry = eligible[-1]
    return entry["ranges"] if "ranges" in entry else entry["value"]


def head_corners(model, ranges, trunk_com, head_com):
    data = mujoco.MjData(model)
    default = home(model)
    joint_range = np.asarray([model.joint(name).range for name in JOINTS])
    failures, maximum_utilization, min_margin, worst_q = 0, 0.0, float("inf"), None
    head_mass = sum(model.body(name).mass[0] for name in HEAD_COM_NAMES)
    # Any rotation of a body-frame cube can shift an XY projection by <=sqrt(3)*range.
    mass = model.body_mass.sum()
    trunk_mass = model.body("trunk_base").mass[0]
    mass_delta = 0.05 * trunk_mass
    com_bound = (
        np.sqrt(3) * (1.05 * trunk_mass * trunk_com + head_mass * head_com) / (mass - mass_delta)
    )
    maximum_com_bound = 0.0
    bad_limits = []
    for command in itertools.product(*[[lo, (lo + hi) / 2, hi] for lo, hi in ranges]):
        data.qpos[:] = default
        data.qpos[12:16] += command
        mujoco.mj_forward(model, data)
        bad = (data.qpos[7:] < joint_range[:, 0]) | (data.qpos[7:] > joint_range[:, 1])
        if np.any(bad):
            bad_limits.append({JOINTS[j]: float(data.qpos[7 + j]) for j in np.flatnonzero(bad)})
        points, bodies = foot_support(model, data)
        mass_shift = (
            mass_delta
            / (mass - mass_delta)
            * np.linalg.norm(data.xipos[model.body("trunk_base").id] - data.subtree_com[1])
        )
        full_bound = com_bound + mass_shift
        maximum_com_bound = max(maximum_com_bound, full_bound)
        margin = support_margin(points, data.subtree_com[1, :2]) - full_bound
        min_margin = min(min_margin, margin)
        check = static_lp(model, data, points, bodies)
        if not check["feasible"]:
            failures += 1
        elif check["rated_utilization"] > maximum_utilization:
            maximum_utilization = check["rated_utilization"]
            worst_q = list(command)
    return {
        "sample_count": 81,
        "hard_limit_failures": len(bad_limits),
        "limit_examples": bad_limits[:1],
        "fixed_home_leg_static_lp_failures": failures,
        "max_feasible_rated_utilization": maximum_utilization,
        "worst_command": worst_q,
        "minimum_com_margin_after_dr_m": min_margin,
        "com_uncertainty_bound_m": float(maximum_com_bound),
    }


def sitting_head_support(model, ranges):
    data = mujoco.MjData(model)
    q = home(model)
    for j, value in SIT.items():
        q[7 + j] = value
    floor = model.geom("floor").id
    head_bodies = {model.body(name).id for name in HEAD_COM_NAMES}
    failures = 0
    min_margin = float("inf")
    max_util = 0.0
    max_self_contacts = 0
    min_height = float("inf")
    for command in itertools.product(*[[lo, (lo + hi) / 2, hi] for lo, hi in ranges]):
        data.qpos[:] = q
        data.qpos[12:16] += command
        mujoco.mj_forward(model, data)
        zmins = []
        for gid in range(model.ngeom):
            if model.geom_type[gid] == mujoco.mjtGeom.mjGEOM_MESH and model.geom_contype[gid]:
                zmins.append(mesh_points(model, data, gid)[:, 2].min())
        data.qpos[2] -= min(zmins) + 0.0001
        mujoco.mj_forward(model, data)
        min_height = min(min_height, float(data.qpos[2]))
        points = []
        bodies = []
        self_contacts = 0
        for contact in data.contact:
            g1, g2 = int(contact.geom1), int(contact.geom2)
            if floor in (g1, g2):
                body = int(model.geom_bodyid[g2 if g1 == floor else g1])
                if body not in head_bodies:
                    points.append(contact.pos.copy())
                    bodies.append(body)
            elif contact.dist < -0.0005:
                self_contacts += 1
        max_self_contacts = max(max_self_contacts, self_contacts)
        if len(points) < 3:
            failures += 1
            continue
        points = np.asarray(points)
        lp = static_lp(model, data, points, bodies)
        min_margin = min(min_margin, support_margin(points, data.subtree_com[1, :2]))
        if not lp["feasible"]:
            failures += 1
        else:
            max_util = max(max_util, lp["rated_utilization"])
    return {
        "sample_count": 81,
        "support_excludes_head": True,
        "static_lp_failures": failures,
        "minimum_com_margin_m": None if not np.isfinite(min_margin) else min_margin,
        "max_feasible_rated_utilization": max_util,
        "max_self_contacts_below_minus_0_5mm": max_self_contacts,
        "minimum_contact_aligned_height_m": min_height,
    }


def inspect_curricula(model, snapshot):
    result = {}
    cache = {}
    for task in ["velocity", "standup", "sitstand"]:
        cfg = snapshot[task]
        cur = cfg["curriculum"]
        rollout_steps = int(cfg["algo"]["num_steps_per_env"])
        rows = []
        steps = sorted(
            {
                entry["step"]
                for values in cur.values()
                if isinstance(values, list)
                for entry in values
            }
        )
        previous = None
        for step in steps:
            values = {
                name: stage_value(stages, step)
                for name, stages in cur.items()
                if isinstance(stages, list)
            }
            key = json.dumps(
                [
                    values["head_range_stages"],
                    values["com_range_stages"],
                    values["head_com_range_stages"],
                ]
            )
            if key not in cache:
                cache[key] = head_corners(
                    model,
                    values["head_range_stages"],
                    values["com_range_stages"],
                    values["head_com_range_stages"],
                )
            push = values.get(
                "push_stages", max(abs(x) for x in cfg["domain_rand"]["velocity_push_xy"])
            )
            data = mujoco.MjData(model)
            data.qpos[:] = home(model)
            mujoco.mj_forward(model, data)
            height = float(data.subtree_com[1, 2])
            # Both independently sampled horizontal components can be at their endpoint.
            capture_shift = np.sqrt(2) * push / np.sqrt(9.81 / height)
            delta = {}
            if previous is not None:
                for name, value in values.items():
                    old = previous["parameters"][name]
                    arr, old_arr = np.asarray(value), np.asarray(old)
                    if not np.array_equal(arr, old_arr):
                        delta[name] = {
                            "before": old,
                            "after": value,
                            "max_abs_increment": float(np.max(np.abs(arr - old_arr))),
                        }
            row = {
                "env_step": step,
                "automatic_promotion_enabled": cur.get("step_cap") is None
                or step <= cur["step_cap"],
                "iteration": step / rollout_steps,
                "control_seconds_per_env": step * 0.02,
                "transitions_per_rank": step * cfg["algo"]["num_envs"],
                "parameters": values,
                "increments": delta,
                "head_corner_audit": cache[key],
                "push_max_vector_m_s": float(np.sqrt(2) * push),
                "capture_point_shift_m": float(capture_shift),
                "requires_stepping_under_worst_push": bool(
                    capture_shift > cache[key]["minimum_com_margin_after_dr_m"]
                ),
            }
            rows.append(row)
            previous = row
        result[task] = rows
        if task == "sitstand":
            sitting_cache = {}
            for row in rows:
                h = row["parameters"]["head_range_stages"]
                k = json.dumps(h)
                if k not in sitting_cache:
                    sitting_cache[k] = sitting_head_support(model, h)
                row["sitting_support_audit"] = sitting_cache[k]
    return result


def body_command_corners(model, ranges, head_ranges, allow_foot_reposition=False):
    """Multi-start IK at body z/roll/pitch corners; foot pose and static loads.

    Feet retain the HOME support poses. A failed fixed-foot IK is reported,
    never silently turned into a feasible target. Contact repositioning is not
    assumed available in this standing body-control task.
    """
    from scipy.spatial.transform import Rotation

    data = mujoco.MjData(model)
    q = home(model)
    q[2] = 0.243
    data.qpos[:] = q
    mujoco.mj_forward(model, data)
    feet = [model.body("ankle_left").id, model.body("ankle_right").id]
    target_pos = data.xpos[feet].copy()
    target_R = data.xmat[feet].reshape(2, 3, 3).copy()
    legs = np.asarray(LEGS)
    x0 = np.r_[0.0, 0.0, q[7 + legs]]
    limits = np.asarray([model.joint(JOINTS[j]).range for j in legs])
    lo = np.r_[-0.15, -0.10, limits[:, 0] + 0.01]
    hi = np.r_[0.15, 0.10, limits[:, 1] - 0.01]
    rows = []
    for dz, roll, pitch in itertools.product(*[[x[0], 0.0, x[1]] for x in ranges[2:5]]):
        quat = Rotation.from_euler("xyz", [roll, pitch, 0]).as_quat()[[3, 0, 1, 2]]

        def residual(x):
            data.qpos[:] = q
            data.qpos[:2] = x[:2]
            data.qpos[2] = 0.243 + dz
            data.qpos[3:7] = quat
            data.qpos[7 + legs] = x[2:]
            mujoco.mj_forward(model, data)
            pos = (
                (data.xpos[feet] - target_pos)
                * np.array(
                    [3.0, 3.0, 1000.0] if allow_foot_reposition else [1000.0, 1000.0, 1000.0]
                )
            ).ravel()
            rot = (
                np.asarray(
                    [
                        Rotation.from_matrix(data.xmat[f].reshape(3, 3) @ target_R[k].T).as_rotvec()
                        for k, f in enumerate(feet)
                    ]
                ).ravel()
                * 100
            )
            center = (
                data.xpos[feet, :2].mean(axis=0)
                if allow_foot_reposition
                else target_pos[:, :2].mean(axis=0)
            )
            return np.r_[pos, rot, 10 * (data.subtree_com[1, :2] - center), 0.02 * (x - x0)]

        solutions = []
        for bend in [0.0, 0.5, -0.5, 1.0, -1.0]:
            initial = x0.copy()
            initial[5] = bend
            initial[10] = -bend
            fit = least_squares(residual, np.clip(initial, lo, hi), bounds=(lo, hi), max_nfev=100)
            solutions.append(fit)
        fit = min(solutions, key=lambda x: np.linalg.norm(x.fun))
        residual(fit.x)
        pose = data.qpos.copy()
        position_error = float(
            np.max(np.abs(fit.fun[[2, 5]] if allow_foot_reposition else fit.fun[:6])) / 1000
        )
        relocation = float(np.max(np.linalg.norm(data.xpos[feet, :2] - target_pos[:, :2], axis=1)))
        orientation_error = float(np.max(np.abs(fit.fun[6:12])) / 100)
        ik_pass = bool(position_error <= 0.001 and orientation_error <= np.deg2rad(1.0))
        minimum_margin = float("inf")
        utilization = 0.0
        static_failures = 0
        for head in itertools.product(*head_ranges):
            data.qpos[:] = pose
            data.qpos[12:16] += head
            mujoco.mj_forward(model, data)
            points, bodies = foot_support(model, data)
            minimum_margin = min(minimum_margin, support_margin(points, data.subtree_com[1, :2]))
            lp = static_lp(model, data, points, bodies)
            if not lp["feasible"]:
                static_failures += 1
            else:
                utilization = max(utilization, lp["rated_utilization"])
        rows.append(
            {
                "allow_foot_reposition": allow_foot_reposition,
                "witness_qpos": pose.tolist(),
                "foot_xy_relocation_m": relocation,
                "z_offset_m": dz,
                "roll_rad": roll,
                "pitch_rad": pitch,
                "ik_pass": ik_pass,
                "foot_position_error_m": position_error,
                "foot_orientation_error_rad": orientation_error,
                "nominal_com_margin_m": minimum_margin,
                "static_lp_failed_head_corners": static_failures,
                "max_feasible_rated_utilization": utilization,
            }
        )
    return rows


def body_reward_preference(model, corners, snapshot, parameters):
    """Static task-score comparison; motion terms vanish, common head terms cancel.

    The threshold is sufficient for these IK witnesses, not a global optimum
    over all policies or all possible equilibrium poses.
    """
    from scipy.spatial.transform import Rotation

    reward = snapshot["standup"]["reward"]
    w = reward["scales"].copy()
    for key, name in [
        ("sharp_height_stages", "height_stand_sharp"),
        ("sharp_upright_stages", "upright_sharp"),
        ("composite_stages", "standing_composite"),
    ]:
        w[name] = parameters[key]
    weight = parameters["body_pose_weight_stages"]
    stand_z = snapshot.get("targets", {}).get("stand_z", 0.243)
    sit_z = snapshot.get("targets", {}).get("sit_z", 0.129)
    default = home(model)
    default[2] = stand_z

    def scores(q, command):
        e = q[7 + np.asarray(LEGS)] - default[7 + np.asarray(LEGS)]
        h = q[2] - stand_z
        up = 1 - 2 * (q[4] ** 2 + q[5] ** 2)
        roll, pitch, _ = Rotation.from_quat(q[3:7][[1, 2, 3, 0]]).as_euler("xyz")
        t = np.clip((q[2] - sit_z) / (stand_z - sit_z), 0, 1)
        terms = {
            "pose_stand_legs": np.mean(np.exp(-((e / 0.5) ** 2))),
            "pose_stand_l1": -np.mean(abs(e)),
            "height_stand": np.exp(-((h / reward["height_std"]) ** 2)),
            "height_stand_sharp": np.exp(-((h / reward["height_sharp_std"]) ** 2)),
            "height_stand_l1": -abs(h),
            "upright_linear": up,
            "upright_sharp": np.exp(-(1 - up) / 0.3**2) * t * t * (3 - 2 * t),
            "standing_composite": np.exp(-np.mean(e * e) / 0.4**2)
            * np.exp(-((h / reward["height_std"]) ** 2))
            * np.exp(-(1 - up) / 0.4**2),
        }
        body = np.mean(
            np.exp(
                -np.square(
                    (np.array([h, roll, pitch]) - command) / [0.01, np.deg2rad(5), np.deg2rad(5)]
                )
            )
        )
        return sum(w[k] * v for k, v in terms.items()), body

    required = []
    gains = []
    for row in corners:
        command = np.array([row["z_offset_m"], row["roll_rad"], row["pitch_rad"]])
        if not np.any(command):
            continue
        idle, ignore = scores(default, command)
        goal, track = scores(np.asarray(row["witness_qpos"]), command)
        required.append(max(0.0, (idle - goal) / max(track - ignore, 1e-12)))
        gains.append(goal + weight * track - idle - weight * ignore)
    return {
        "active_weight": weight,
        "maximum_sufficient_weight_for_witnesses": float(max(required)),
        "minimum_reward_gain_over_ignoring_command": float(min(gains)),
        "witness_count": len(gains),
        "motion_and_common_head_terms_excluded": True,
    }


def loaded_support_certificates(model, path):
    data = mujoco.MjData(model)
    floor = model.geom("floor").id
    head_ids = {
        model.body(name).id for name in ["neck", "neck_pitch", "yaw_roll_motion", "jaw_soft"]
    }
    output = []
    for hold in json.loads(path.read_text()):
        data.qpos[:] = hold["final_qpos"]
        data.qvel[:] = 0.0
        mujoco.mj_forward(model, data)
        points = []
        bodies = []
        for contact in data.contact:
            g1, g2 = int(contact.geom1), int(contact.geom2)
            if floor not in (g1, g2):
                continue
            body = int(model.geom_bodyid[g2 if g1 == floor else g1])
            if body in head_ids:
                continue
            points.append(contact.pos.copy())
            bodies.append(body)
        check = (
            static_lp(model, data, np.asarray(points), bodies)
            if len(points) >= 3
            else {"feasible": False, "status": "fewer than 3 non-head support points"}
        )
        output.append(
            {
                "head_stage_index": hold["head_stage_index"],
                "start": hold["start"],
                "head_command": hold["head_command"],
                "hold_upright": hold["final_min_upright"] >= 0.95,
                "hold_self_contact_free": hold["final_self_pairs"] == 0,
                "static_certificate": check,
            }
        )
    return output


def compare_assets(source, imported):
    sm, im = body_metrics(source), body_metrics(imported)
    rows = []
    for sb, ib in zip(sm["bodies"], im["bodies"], strict=True):
        rows.append(
            {
                "body": sb["body"],
                "matches": sb["body"] == ib["body"]
                and np.allclose(sb["mass_kg"], ib["mass_kg"], atol=1e-9)
                and np.allclose(sb["local_com_m"], ib["local_com_m"], atol=1e-9)
                and np.allclose(sb["inertia_principal"], ib["inertia_principal"], atol=1e-9)
                and all(
                    np.allclose(sb[key], ib[key], atol=1e-9)
                    for key in ["local_body_pos_m", "local_body_quat", "inertial_quat"]
                ),
            }
        )
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--snapshot", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--loaded-holds", type=Path)
    args = parser.parse_args()
    # The script is located in unilab/src/unilab/envs/locomotion/microduck_dm4310.
    unilab = Path(__file__).resolve().parents[5]
    workspace = unilab.parent
    new_path = unilab / "src/unilab/assets/robots/microduck_dm4310/scene_posture.xml"
    old_path = workspace / "mjlab/src/mjlab_microduck/robot/microduck/scene.xml"
    release_path = workspace / "Model/Duck_V1.1.0/scene.xml"
    new = mujoco.MjModel.from_xml_path(str(new_path))
    old = mujoco.MjModel.from_xml_path(str(old_path))
    release = mujoco.MjModel.from_xml_path(str(release_path))
    snapshot = json.loads(args.snapshot.read_text())
    global SIT, HEAD_COM_NAMES
    SIT = {int(k): v for k, v in snapshot.get("targets", {}).get("sit_overrides", SIT).items()}
    HEAD_COM_NAMES = snapshot["velocity"].get("head_com_body_names", HEAD_COM_NAMES)
    result = {
        "scope": "Necessary nominal static feasibility and all scheduled parameter increments; not RL success.",
        "snapshot_sha256": hashlib.sha256(args.snapshot.read_bytes()).hexdigest(),
        "old_model": body_metrics(old),
        "new_model": body_metrics(new),
        "release_import_inertial_parity": compare_assets(release, new),
        "curricula": inspect_curricula(new, snapshot),
    }
    result["body_command_corners"] = []
    body_cache = {}
    for stage in result["curricula"]["standup"]:
        step = stage["env_step"]
        ranges = stage["parameters"]["body_range_stages"]
        head_ranges = stage["parameters"]["head_range_stages"]
        key = json.dumps([ranges, head_ranges])
        if key not in body_cache:
            body_cache[key] = {
                "corners": body_command_corners(new, ranges, head_ranges),
                "repositioned_corners": body_command_corners(new, ranges, head_ranges, True),
            }
        result["body_command_corners"].append(
            {
                "step": step,
                "active_reward_weight": stage["parameters"]["body_pose_weight_stages"],
                "automatic_promotion_enabled": stage["automatic_promotion_enabled"],
                "com_uncertainty_bound_m": stage["head_corner_audit"]["com_uncertainty_bound_m"],
                "body_reward_preference": body_reward_preference(
                    new, body_cache[key]["repositioned_corners"], snapshot, stage["parameters"]
                ),
                **body_cache[key],
            }
        )
    if args.loaded_holds:
        result["loaded_hold_sha256"] = hashlib.sha256(args.loaded_holds.read_bytes()).hexdigest()
        result["loaded_support_certificates"] = loaded_support_certificates(new, args.loaded_holds)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(args.output)


if __name__ == "__main__":
    main()
