"""Locomotion env registry bootstrap contract."""

__unilab_registry_modules__ = (
    "unilab.envs.locomotion.go1",
    "unilab.envs.locomotion.go2",
    "unilab.envs.locomotion.go2w",
    "unilab.envs.locomotion.g1",
    "unilab.envs.locomotion.go2_arm",
    "unilab.envs.locomotion.a2",
    "unilab.envs.locomotion.microduck_dm4310",
    "unilab.envs.locomotion.microduck_xl330_official",
    "unilab.envs.locomotion.xduck_gf43x40",
)
