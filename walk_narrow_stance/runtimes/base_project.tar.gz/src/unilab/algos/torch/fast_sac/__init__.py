# FastSAC algorithm
