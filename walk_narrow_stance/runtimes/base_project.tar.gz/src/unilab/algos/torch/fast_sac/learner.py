"""FastSAC Learner — replicated from holosoma's FastSAC implementation.

Network architecture:
- Actor: MLP with SiLU + LayerNorm, tanh-squashed Gaussian
- Critic: Distributional Q-Networks (C51 variant, num_atoms=101)
- Automatic entropy coefficient (alpha) learning

Hyperparameters aligned with holosoma FastSACConfig defaults.
"""

from __future__ import annotations

import math
from collections.abc import Callable, Iterable, Iterator
from contextlib import contextmanager
from typing import Any, Dict, Tuple, cast

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim

from unilab.algos.torch.common.compile import get_torch_compile_for_cuda
from unilab.algos.torch.common.normalization import EmpiricalNormalization
from unilab.base.augmentation import SymmetryAugmentation


@contextmanager
def _cuda_nvtx_range(name: str, enabled: bool) -> Iterator[None]:
    if not enabled:
        yield
        return

    torch.cuda.nvtx.range_push(name)
    try:
        yield
    finally:
        torch.cuda.nvtx.range_pop()


# ---------------------------------------------------------------------------
# Actor Network (holosoma-style: SiLU + LayerNorm + Tanh squashing)
# ---------------------------------------------------------------------------


class SACActor(nn.Module):
    """Stochastic actor for SAC with tanh-squashed Gaussian policy.

    Architecture: Linear→LN→SiLU → Linear→LN→SiLU → Linear→LN→SiLU → fc_mu + fc_logstd
    Hidden dims: [hidden_dim, hidden_dim//2, hidden_dim//4]
    """

    action_scale: torch.Tensor
    action_bias: torch.Tensor

    def __init__(
        self,
        obs_dim: int,
        action_dim: int,
        hidden_dim: int = 512,
        log_std_max: float = 0.0,
        log_std_min: float = -5.0,
        use_tanh: bool = True,
        use_layer_norm: bool = True,
        device: str | torch.device = "cpu",
        action_scale: torch.Tensor | None = None,
        action_bias: torch.Tensor | None = None,
    ):
        super().__init__()
        self.obs_dim = obs_dim
        self.action_dim = action_dim
        self.log_std_max = log_std_max
        self.log_std_min = log_std_min
        self.use_tanh = use_tanh
        self.device_ = device  # avoid name collision with nn.Module.device

        self.net = nn.Sequential(
            nn.Linear(obs_dim, hidden_dim, device=device),
            nn.LayerNorm(hidden_dim, device=device) if use_layer_norm else nn.Identity(),
            nn.SiLU(),
            nn.Linear(hidden_dim, hidden_dim // 2, device=device),
            nn.LayerNorm(hidden_dim // 2, device=device) if use_layer_norm else nn.Identity(),
            nn.SiLU(),
            nn.Linear(hidden_dim // 2, hidden_dim // 4, device=device),
            nn.LayerNorm(hidden_dim // 4, device=device) if use_layer_norm else nn.Identity(),
            nn.SiLU(),
        )
        self.fc_mu = nn.Linear(hidden_dim // 4, action_dim, device=device)
        self.fc_logstd = nn.Linear(hidden_dim // 4, action_dim, device=device)

        # Zero-init output heads (holosoma style)
        nn.init.constant_(self.fc_mu.weight, 0.0)
        nn.init.constant_(self.fc_mu.bias, 0.0)
        nn.init.constant_(self.fc_logstd.weight, 0.0)
        nn.init.constant_(self.fc_logstd.bias, 0.0)

        # Action scaling
        if action_scale is not None:
            self.register_buffer("action_scale", action_scale.to(device))
        else:
            self.register_buffer("action_scale", torch.ones(action_dim, device=device))
        if action_bias is not None:
            self.register_buffer("action_bias", action_bias.to(device))
        else:
            self.register_buffer("action_bias", torch.zeros(action_dim, device=device))

    def forward(self, obs: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Returns (action, mean, log_std)."""
        x = self.net(obs)
        mean = self.fc_mu(x)
        log_std = self.fc_logstd(x)

        # Squash log_std to [log_std_min, log_std_max] (SpinUp / Denis Yarats style)
        log_std = torch.tanh(log_std)
        log_std = self.log_std_min + 0.5 * (self.log_std_max - self.log_std_min) * (log_std + 1)

        # NaN protection: clamp mean to prevent exploding values
        mean = torch.clamp(mean, -10.0, 10.0)
        mean = torch.nan_to_num(mean, nan=0.0)
        log_std = torch.nan_to_num(log_std, nan=self.log_std_min)

        if self.use_tanh:
            tanh_mean = torch.tanh(mean)
            action = tanh_mean * self.action_scale + self.action_bias
        else:
            action = mean

        return action, mean, log_std

    def as_export_module(self) -> "nn.Module":
        """Return a single-input/single-output wrapper suitable for torch.onnx.export."""
        actor = self

        class _Wrapper(nn.Module):
            def __init__(self) -> None:
                super().__init__()
                self.base = actor

            def forward(self, obs: torch.Tensor) -> torch.Tensor:
                action, _, _ = self.base(obs)
                return cast(torch.Tensor, action)

        return _Wrapper()

    def get_actions_and_log_probs(
        self,
        obs: torch.Tensor,
        eps: torch.Tensor | None = None,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Sample actions and compute log probabilities. Returns (action, log_prob, log_std)."""
        _, mean, log_std = self(obs)
        action, log_prob = self._sample_action_and_log_prob(mean, log_std, eps=eps)
        return action, log_prob, log_std

    def _sample_action_and_log_prob(
        self,
        mean: torch.Tensor,
        log_std: torch.Tensor,
        eps: torch.Tensor | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        std = log_std.exp()
        if eps is None:
            eps = torch.randn_like(mean)
        raw_action = mean + std * eps
        log_prob = -0.5 * (
            ((raw_action - mean) / std).pow(2) + 2.0 * log_std + math.log(2.0 * math.pi)
        )

        if self.use_tanh:
            tanh_action = torch.tanh(raw_action)
            action = tanh_action * self.action_scale + self.action_bias
            log_prob -= torch.log(1 - tanh_action.pow(2) + 1e-6)
            log_prob -= torch.log(self.action_scale + 1e-6)
        else:
            action = raw_action

        return action, log_prob.sum(1)

    @torch.no_grad()
    def explore(
        self,
        obs: torch.Tensor,
        dones: torch.Tensor | None = None,
        deterministic: bool = False,
    ) -> torch.Tensor:
        """Get exploration actions.

        Args:
            obs: Batched observations.
            dones: Unused for SAC; kept for API alignment with TD3 actor.
            deterministic: Whether to return deterministic policy actions.
        """
        # Backward compatibility: previous signature was explore(obs, deterministic=False).
        if isinstance(dones, bool):
            deterministic = dones
            dones = None
        _ = dones

        _, mean, log_std = self.forward(obs)
        if deterministic:
            if self.use_tanh:
                return torch.tanh(mean) * self.action_scale + self.action_bias
            return mean

        raw_action = mean + log_std.exp() * torch.randn_like(mean)

        if self.use_tanh:
            return torch.tanh(raw_action) * self.action_scale + self.action_bias
        return raw_action


# ---------------------------------------------------------------------------
# Distributional Q-Network (C51 variant, from holosoma)
# ---------------------------------------------------------------------------


class DistributionalQNetwork(nn.Module):
    """Single distributional Q-network (C51).

    Architecture: Linear→LN→SiLU → Linear→LN→SiLU → Linear→LN→SiLU → Linear(num_atoms)
    Input: concat(obs, action)
    """

    def __init__(
        self,
        obs_dim: int,
        action_dim: int,
        num_atoms: int = 101,
        v_min: float = -20.0,
        v_max: float = 20.0,
        hidden_dim: int = 768,
        use_layer_norm: bool = True,
        device: str | torch.device = "cpu",
    ):
        super().__init__()
        self.num_atoms = num_atoms
        self.v_min = v_min
        self.v_max = v_max

        input_dim = obs_dim + action_dim
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim, device=device),
            nn.LayerNorm(hidden_dim, device=device) if use_layer_norm else nn.Identity(),
            nn.SiLU(),
            nn.Linear(hidden_dim, hidden_dim // 2, device=device),
            nn.LayerNorm(hidden_dim // 2, device=device) if use_layer_norm else nn.Identity(),
            nn.SiLU(),
            nn.Linear(hidden_dim // 2, hidden_dim // 4, device=device),
            nn.LayerNorm(hidden_dim // 4, device=device) if use_layer_norm else nn.Identity(),
            nn.SiLU(),
            nn.Linear(hidden_dim // 4, num_atoms, device=device),
        )

    def forward(self, obs: torch.Tensor, actions: torch.Tensor) -> torch.Tensor:
        x = torch.cat([obs, actions], dim=-1)
        return self.net(x)  # type: ignore[no-any-return]

    def projection(
        self,
        obs: torch.Tensor,
        actions: torch.Tensor,
        rewards: torch.Tensor,
        bootstrap: torch.Tensor,
        discount: torch.Tensor,
        q_support: torch.Tensor,
        device: torch.device,
    ) -> torch.Tensor:
        """Categorical projection for distributional RL."""
        delta_z = (self.v_max - self.v_min) / (self.num_atoms - 1)
        batch_size = rewards.shape[0]

        target_z = rewards.unsqueeze(1) + bootstrap.unsqueeze(1) * discount.unsqueeze(1) * q_support
        target_z = target_z.clamp(self.v_min, self.v_max)
        b = (target_z - self.v_min) / delta_z
        lower = torch.floor(b).long()
        upper = torch.ceil(b).long()

        is_integer = upper == lower
        lower_mask = torch.logical_and((lower > 0), is_integer)
        upper_mask = torch.logical_and((lower == 0), is_integer)

        lower = torch.where(lower_mask, lower - 1, lower)
        upper = torch.where(upper_mask, upper + 1, upper)

        next_dist = F.softmax(self(obs, actions), dim=1)
        proj_dist = torch.zeros_like(next_dist)
        offset = (
            torch.linspace(0, (batch_size - 1) * self.num_atoms, batch_size, device=device)
            .unsqueeze(1)
            .expand(batch_size, self.num_atoms)
            .long()
        )

        lower_indices = (lower + offset).view(-1)
        upper_indices = (upper + offset).view(-1)
        max_index = proj_dist.numel() - 1
        lower_indices = torch.clamp(lower_indices, 0, max_index)
        upper_indices = torch.clamp(upper_indices, 0, max_index)

        proj_dist.view(-1).index_add_(0, lower_indices, (next_dist * (upper.float() - b)).view(-1))
        proj_dist.view(-1).index_add_(0, upper_indices, (next_dist * (b - lower.float())).view(-1))
        return proj_dist


class SACCritic(nn.Module):
    """Ensemble of distributional Q-networks for SAC.

    Uses ``num_q_networks`` independent DistributionalQNetwork instances.
    """

    q_support: torch.Tensor

    def __init__(
        self,
        obs_dim: int,
        action_dim: int,
        num_atoms: int = 101,
        v_min: float = -20.0,
        v_max: float = 20.0,
        hidden_dim: int = 768,
        use_layer_norm: bool = True,
        num_q_networks: int = 2,
        device: str | torch.device = "cpu",
    ):
        super().__init__()
        self.obs_dim = obs_dim
        self.action_dim = action_dim
        self.num_atoms = num_atoms
        self.v_min = v_min
        self.v_max = v_max
        self.num_q_networks = num_q_networks

        self.qnets = nn.ModuleList(
            [
                DistributionalQNetwork(
                    obs_dim=obs_dim,
                    action_dim=action_dim,
                    num_atoms=num_atoms,
                    v_min=v_min,
                    v_max=v_max,
                    hidden_dim=hidden_dim,
                    use_layer_norm=use_layer_norm,
                    device=device,
                )
                for _ in range(num_q_networks)
            ]
        )

        self.register_buffer("q_support", torch.linspace(v_min, v_max, num_atoms, device=device))

    def forward(self, obs: torch.Tensor, actions: torch.Tensor) -> torch.Tensor:
        """Returns stacked logits: (num_q_nets, batch, num_atoms)."""
        outputs = [qnet(obs, actions) for qnet in self.qnets]
        return torch.stack(outputs, dim=0)

    def projection(
        self,
        obs: torch.Tensor,
        actions: torch.Tensor,
        rewards: torch.Tensor,
        bootstrap: torch.Tensor,
        discount: torch.Tensor,
    ) -> torch.Tensor:
        """Project for all Q-networks: (num_q_nets, batch, num_atoms)."""
        projections = [
            qnet.projection(  # type: ignore[operator]
                obs, actions, rewards, bootstrap, discount, self.q_support, self.q_support.device
            )
            for qnet in self.qnets
        ]
        return torch.stack(projections, dim=0)

    def get_value(self, probs: torch.Tensor) -> torch.Tensor:
        """Calculate value from probabilities using support."""
        return torch.sum(probs * self.q_support, dim=-1)


# ---------------------------------------------------------------------------
# FastSACLearner — the training algorithm
# ---------------------------------------------------------------------------


class FastSACLearner:
    """FastSAC learner with holosoma-aligned hyperparameters.

    Key hyperparameters (aligned with holosoma FastSACConfig):
    - gamma=0.97, tau=0.125
    - batch_size=8192, num_updates=8, policy_frequency=4
    - alpha_init=0.001, target_entropy_ratio=0.0
    - AdamW with betas=(0.9, 0.95), weight_decay=0.001
    - Distributional critic (C51, num_atoms=101)
    """

    def __init__(
        self,
        obs_dim: int,
        action_dim: int,
        critic_obs_dim: int,
        device: str = "cpu",
        # Hyperparameters aligned with holosoma
        gamma: float = 0.97,
        tau: float = 0.125,
        actor_lr: float = 3e-4,
        critic_lr: float = 3e-4,
        alpha_lr: float = 3e-4,
        alpha_init: float = 0.001,
        target_entropy_ratio: float = 0.0,
        actor_hidden_dim: int = 512,
        critic_hidden_dim: int = 768,
        num_atoms: int = 101,
        v_min: float = -20.0,
        v_max: float = 20.0,
        num_q_networks: int = 2,
        use_layer_norm: bool = True,
        use_tanh: bool = True,
        log_std_max: float = 0.0,
        log_std_min: float = -5.0,
        weight_decay: float = 0.001,
        max_grad_norm: float = 0.0,
        use_autotune: bool = True,
        use_symmetry: bool = False,
        use_amp: bool = False,
        amp_dtype: str = "auto",
        use_compile: bool = False,
        obs_normalization: bool = False,
        use_cuda_graph_critic: bool = False,
        use_cuda_graph_actor: bool = False,
        use_cuda_graph_critic_packed_staging: bool = False,
        use_cuda_graph_actor_packed_staging: bool = False,
        nvtx_profile_ranges: bool = False,
        symmetry_augmentation: SymmetryAugmentation | None = None,
    ):
        self.device = device
        self._device_type = torch.device(device).type
        self.gamma = gamma
        self.tau = tau
        self.max_grad_norm = max_grad_norm
        self.use_autotune = use_autotune
        self.use_amp = bool(use_amp) and self._device_type in ("cuda", "xpu")
        self.use_compile = (
            bool(use_compile) and get_torch_compile_for_cuda(self.device, warn=True) is not None
        )
        self.use_cuda_graph_critic = bool(use_cuda_graph_critic) and self._device_type == "cuda"
        requested_cuda_graph_critic_packed_staging = bool(use_cuda_graph_critic_packed_staging)
        requested_cuda_graph_actor_packed_staging = bool(use_cuda_graph_actor_packed_staging)
        self.use_cuda_graph_actor = bool(use_cuda_graph_actor) and self._device_type == "cuda"
        self._gradient_sync: Callable[[Iterable[torch.Tensor]], None] | None = None
        self._gradient_sync_graph_replay_recorder: Callable[[int], None] | None = None
        self.dp_cuda_graph_gradient_sync = False
        self._active_cuda_graph_gradient_sync_calls: list[int] | None = None
        self.nvtx_profile_ranges = bool(nvtx_profile_ranges) and self._device_type == "cuda"
        self.amp_dtype = amp_dtype
        self._amp_dtype = self._resolve_amp_dtype(amp_dtype, self._device_type)
        self.critic_obs_dim = critic_obs_dim

        # Build actor (uses obs only)
        self.actor = SACActor(
            obs_dim=obs_dim,
            action_dim=action_dim,
            hidden_dim=actor_hidden_dim,
            log_std_max=log_std_max,
            log_std_min=log_std_min,
            use_tanh=use_tanh,
            use_layer_norm=use_layer_norm,
            device=device,
        )

        self.qnet = SACCritic(
            obs_dim=critic_obs_dim,
            action_dim=action_dim,
            num_atoms=num_atoms,
            v_min=v_min,
            v_max=v_max,
            hidden_dim=critic_hidden_dim,
            use_layer_norm=use_layer_norm,
            num_q_networks=num_q_networks,
            device=device,
        )

        # Target critic
        self.qnet_target = SACCritic(
            obs_dim=critic_obs_dim,
            action_dim=action_dim,
            num_atoms=num_atoms,
            v_min=v_min,
            v_max=v_max,
            hidden_dim=critic_hidden_dim,
            use_layer_norm=use_layer_norm,
            num_q_networks=num_q_networks,
            device=device,
        )
        self.qnet_target.load_state_dict(self.qnet.state_dict())

        # Entropy coefficient
        self.log_alpha = torch.tensor([math.log(alpha_init)], requires_grad=True, device=device)
        self.target_entropy = -action_dim * target_entropy_ratio
        self._zero_metric = torch.zeros((), device=device)

        self.obs_normalizer: EmpiricalNormalization | nn.Identity
        if obs_normalization:
            self.obs_normalizer = EmpiricalNormalization(shape=obs_dim, device=device)
        else:
            self.obs_normalizer = nn.Identity()

        # fused AdamW requires CUDA; MPS and CPU do not support it
        _fused = isinstance(device, str) and device.startswith("cuda")
        _optimizer_cuda_kwargs = {"capturable": True} if _fused else {}

        # Optimizers (AdamW with holosoma betas)
        self.q_optimizer = optim.AdamW(
            self.qnet.parameters(),
            lr=critic_lr,
            weight_decay=weight_decay,
            fused=_fused,
            betas=(0.9, 0.95),
            **_optimizer_cuda_kwargs,
        )
        self.actor_optimizer = optim.AdamW(
            self.actor.parameters(),
            lr=actor_lr,
            weight_decay=weight_decay,
            fused=_fused,
            betas=(0.9, 0.95),
            **_optimizer_cuda_kwargs,
        )
        self.alpha_optimizer = optim.AdamW(
            [self.log_alpha],
            lr=alpha_lr,
            fused=_fused,
            betas=(0.9, 0.95),
            weight_decay=0.0,
            **_optimizer_cuda_kwargs,
        )

        # Step counter
        self.update_count = 0

        # AMP scaler for mixed precision (fp16 only; bf16 has fp32 range and skips scaler)
        self.scaler = (
            torch.amp.GradScaler("cuda")  # pyright: ignore[reportPrivateImportUsage]
            if self._should_use_grad_scaler(self.use_amp, self._device_type, self._amp_dtype)
            else None
        )
        self.use_cuda_graph_critic_packed_staging = (
            requested_cuda_graph_critic_packed_staging
            and self.use_cuda_graph_critic
            and self.scaler is None
        )
        self.use_cuda_graph_actor_packed_staging = (
            requested_cuda_graph_actor_packed_staging
            and self.use_cuda_graph_actor
            and self.scaler is None
            and not use_symmetry
        )

        self.symmetry = symmetry_augmentation
        if use_symmetry and symmetry_augmentation is None:
            raise ValueError(
                "FastSACLearner use_symmetry=True requires a symmetry_augmentation contract"
            )
        self.use_symmetry = use_symmetry
        self._cuda_graph_critic: torch.cuda.CUDAGraph | None = None
        self._cuda_graph_critic_static_inputs: dict[str, torch.Tensor] | None = None
        self._cuda_graph_critic_static_packed_input: torch.Tensor | None = None
        self._cuda_graph_sac_static_packed_input: torch.Tensor | None = None
        self._cuda_graph_sac_static_source_ptr: int | None = None
        self._cuda_graph_critic_action_noise: torch.Tensor | None = None
        self._cuda_graph_critic_outputs: (
            tuple[
                torch.Tensor,
                torch.Tensor,
                torch.Tensor,
                torch.Tensor,
                torch.Tensor,
                torch.Tensor,
            ]
            | None
        ) = None
        self._cuda_graph_critic_shapes: dict[str, torch.Size] | None = None
        self._cuda_graph_critic_gradient_sync_calls = 0
        self._cuda_graph_actor: torch.cuda.CUDAGraph | None = None
        self._cuda_graph_actor_static_inputs: dict[str, torch.Tensor] | None = None
        self._cuda_graph_actor_static_packed_input: torch.Tensor | None = None
        self._cuda_graph_actor_action_noise: torch.Tensor | None = None
        self._cuda_graph_actor_outputs: (
            tuple[
                torch.Tensor,
                torch.Tensor,
                torch.Tensor,
                torch.Tensor,
            ]
            | None
        ) = None
        self._cuda_graph_actor_shapes: dict[str, torch.Size] | None = None
        self._cuda_graph_actor_gradient_sync_calls = 0
        if self.use_compile:
            self._compile_training_methods()

    @staticmethod
    def _resolve_amp_dtype(amp_dtype: str, device_type: str) -> torch.dtype:
        normalized = amp_dtype.lower()
        if normalized == "auto":
            return torch.bfloat16
        if normalized == "fp16":
            return torch.float16
        if normalized == "bf16":
            return torch.bfloat16
        raise ValueError("FastSAC amp_dtype must be one of: auto, fp16, bf16")

    @staticmethod
    def _should_use_grad_scaler(
        use_amp: bool,
        device_type: str,
        amp_dtype: torch.dtype,
    ) -> bool:
        return bool(use_amp) and device_type == "cuda" and amp_dtype == torch.float16

    def _compile_training_methods(self) -> None:
        compile_fn = get_torch_compile_for_cuda(self.device, warn=True)
        if compile_fn is None:
            return

        compile_kwargs = {"options": {"triton.cudagraphs": False}}
        if not self.use_cuda_graph_critic:
            self._critic_loss_tensors = compile_fn(  # type: ignore[method-assign]
                self._critic_loss_tensors, **compile_kwargs
            )
        if not self.use_cuda_graph_actor:
            self._actor_loss_tensors = compile_fn(  # type: ignore[method-assign]
                self._actor_loss_tensors, **compile_kwargs
            )

    def _autocast(self):
        return torch.amp.autocast(  # pyright: ignore[reportPrivateImportUsage]
            self._device_type, dtype=self._amp_dtype, enabled=self.use_amp
        )

    @torch.no_grad()
    def _update_obs_normalizer(self, obs: torch.Tensor) -> None:
        if isinstance(self.obs_normalizer, nn.Identity):
            return
        normalizer = cast(EmpiricalNormalization, self.obs_normalizer)
        normalizer.update(obs)

    def normalize_obs(self, obs: torch.Tensor, update: bool = False) -> torch.Tensor:
        """Normalize actor observations using running statistics."""
        if isinstance(self.obs_normalizer, nn.Identity):
            return obs
        normalizer = cast(EmpiricalNormalization, self.obs_normalizer)
        if update:
            self._update_obs_normalizer(obs)
            return cast(torch.Tensor, normalizer(obs, update=False))
        return cast(torch.Tensor, normalizer(obs, update=False))

    def _get_actions_and_log_probs_for_critic(
        self,
        actor_obs: torch.Tensor,
        critic_obs: torch.Tensor,
        eps: torch.Tensor | None = None,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Sample actor actions for critic targets.

        Subclasses can use ``critic_obs`` to supply auxiliary policy context while
        preserving the standard SAC update path.
        """
        del critic_obs
        return self.actor.get_actions_and_log_probs(actor_obs, eps=eps)

    def _get_actions_and_log_probs_for_actor(
        self,
        actor_obs: torch.Tensor,
        critic_obs: torch.Tensor,
        eps: torch.Tensor | None = None,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Sample actor actions for the actor loss update."""
        del critic_obs
        return self.actor.get_actions_and_log_probs(actor_obs, eps=eps)

    def _critic_loss_tensors(
        self,
        critic_obs: torch.Tensor,
        actions: torch.Tensor,
        rewards: torch.Tensor,
        next_obs: torch.Tensor,
        critic_next_obs: torch.Tensor,
        dones: torch.Tensor,
        truncated: torch.Tensor,
        next_action_eps: torch.Tensor | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        bootstrap = torch.clamp(1.0 - dones.float() + truncated.float(), 0.0, 1.0)
        discount = torch.full_like(dones, self.gamma)

        with torch.no_grad():
            with self._autocast():
                next_actions, next_log_probs, _ = self._get_actions_and_log_probs_for_critic(
                    next_obs,
                    critic_next_obs,
                    eps=next_action_eps,
                )
            adjusted_rewards = (
                rewards - discount * bootstrap * self.log_alpha.exp() * next_log_probs
            )

            with self._autocast():
                target_distributions = self.qnet_target.projection(
                    critic_next_obs, next_actions, adjusted_rewards, bootstrap, discount
                )
                target_values = self.qnet_target.get_value(target_distributions)
                target_q_max = target_values.max()
                target_q_min = target_values.min()

        with self._autocast():
            q_outputs = self.qnet(critic_obs, actions)
            critic_log_probs = F.log_softmax(q_outputs, dim=-1).clamp(min=-30.0)
            critic_losses = -torch.sum(target_distributions * critic_log_probs, dim=-1)
            qf_loss = critic_losses.mean(dim=1).sum(dim=0)

        return qf_loss, target_q_max, target_q_min, next_log_probs.detach()

    def _alpha_loss_tensor(self, next_log_probs: torch.Tensor) -> torch.Tensor:
        entropy_error_mean = (next_log_probs + self.target_entropy).detach().mean()
        return -(self.log_alpha.exp() * entropy_error_mean)

    def _actor_loss_tensors(
        self,
        obs: torch.Tensor,
        critic_obs: torch.Tensor,
        action_eps: torch.Tensor | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        with self._autocast():
            actions, log_probs, log_std = self._get_actions_and_log_probs_for_actor(
                obs,
                critic_obs,
                eps=action_eps,
            )

        with torch.no_grad():
            action_std = log_std.exp().mean()
            policy_entropy = -log_probs.mean()

        with self._autocast():
            q_outputs = self.qnet(critic_obs, actions)
            q_probs = F.softmax(q_outputs, dim=-1)
            q_values = self.qnet.get_value(q_probs)
            qf_value = q_values.mean(dim=0)
            actor_loss = (self.log_alpha.exp().detach() * log_probs - qf_value).mean()

        return actor_loss, policy_entropy, action_std

    def _update_actor_capture_candidate(
        self,
        obs: torch.Tensor,
        critic_obs: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        actor_loss, policy_entropy, action_std = self._actor_loss_tensors(
            obs,
            critic_obs,
            action_eps=self._cuda_graph_actor_action_noise,
        )

        self.actor_optimizer.zero_grad(set_to_none=True)
        if self.scaler:
            self.scaler.scale(actor_loss).backward()
            self.scaler.unscale_(self.actor_optimizer)
            if self.max_grad_norm > 0:
                actor_grad_norm = torch.nn.utils.clip_grad_norm_(
                    self.actor.parameters(), max_norm=self.max_grad_norm
                )
            else:
                actor_grad_norm = self._zero_metric
            self.scaler.step(self.actor_optimizer)
            self.scaler.update()
        else:
            actor_loss.backward()
            self._sync_gradients(self.actor.parameters())
            if self.max_grad_norm > 0:
                actor_grad_norm = torch.nn.utils.clip_grad_norm_(
                    self.actor.parameters(), max_norm=self.max_grad_norm
                )
            else:
                actor_grad_norm = self._zero_metric
            self.actor_optimizer.step()

        return actor_loss, actor_grad_norm, policy_entropy, action_std

    def _update_critic_capture_candidate(
        self,
        critic_obs: torch.Tensor,
        actions: torch.Tensor,
        rewards: torch.Tensor,
        next_obs: torch.Tensor,
        critic_next_obs: torch.Tensor,
        dones: torch.Tensor,
        truncated: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        qf_loss, target_q_max, target_q_min, next_log_probs = self._critic_loss_tensors(
            critic_obs,
            actions,
            rewards,
            next_obs,
            critic_next_obs,
            dones,
            truncated,
            next_action_eps=self._cuda_graph_critic_action_noise,
        )

        self.q_optimizer.zero_grad(set_to_none=True)
        if self.scaler:
            self.scaler.scale(qf_loss).backward()
            self.scaler.unscale_(self.q_optimizer)
            if self.max_grad_norm > 0:
                critic_grad_norm = torch.nn.utils.clip_grad_norm_(
                    self.qnet.parameters(), max_norm=self.max_grad_norm
                )
            else:
                critic_grad_norm = self._zero_metric
            self.scaler.step(self.q_optimizer)
            self.scaler.update()
        else:
            qf_loss.backward()
            self._sync_gradients(self.qnet.parameters())
            if self.max_grad_norm > 0:
                critic_grad_norm = torch.nn.utils.clip_grad_norm_(
                    self.qnet.parameters(), max_norm=self.max_grad_norm
                )
            else:
                critic_grad_norm = self._zero_metric
            self.q_optimizer.step()

        alpha_loss = self._zero_metric
        if self.use_autotune:
            self.alpha_optimizer.zero_grad(set_to_none=True)
            alpha_loss = self._alpha_loss_tensor(next_log_probs)
            alpha_loss.backward()
            self._sync_gradients((self.log_alpha,))
            self.alpha_optimizer.step()

        return (
            qf_loss,
            critic_grad_norm,
            target_q_max,
            target_q_min,
            alpha_loss,
            self.log_alpha.exp(),
        )

    def _critic_graph_input_shapes(self, batch: Dict[str, torch.Tensor]) -> dict[str, torch.Size]:
        return {
            "critic": batch["critic"].shape,
            "actions": batch["actions"].shape,
            "rewards": batch["rewards"].shape,
            "next_obs": batch["next_obs"].shape,
            "next_critic": batch["next_critic"].shape,
            "dones": batch["dones"].shape,
            "truncated": batch["truncated"].shape,
        }

    @staticmethod
    def _critic_graph_input_keys() -> tuple[str, ...]:
        return (
            "critic",
            "actions",
            "rewards",
            "next_obs",
            "next_critic",
            "dones",
            "truncated",
        )

    @classmethod
    def _critic_graph_packed_width(cls, batch: Dict[str, torch.Tensor]) -> int:
        width = 0
        for key in cls._critic_graph_input_keys():
            tensor = batch[key]
            width += int(tensor.reshape(tensor.shape[0], -1).shape[1])
        return width

    @classmethod
    def _critic_graph_static_views_from_packed(
        cls,
        packed: torch.Tensor,
        shapes: dict[str, torch.Size],
    ) -> dict[str, torch.Tensor]:
        views: dict[str, torch.Tensor] = {}
        offset = 0
        for key in cls._critic_graph_input_keys():
            shape = shapes[key]
            width = 1
            for dim in shape[1:]:
                width *= int(dim)
            view = packed.narrow(1, offset, width).view(shape)
            views[key] = view
            offset += width
        return views

    @staticmethod
    def _sac_graph_offsets(
        actor_shapes: dict[str, torch.Size],
        critic_shapes: dict[str, torch.Size],
    ) -> dict[str, tuple[int, int]]:
        def width(shape: torch.Size) -> int:
            value = 1
            for dim in shape[1:]:
                value *= int(dim)
            return value

        widths = {
            "obs": width(actor_shapes["obs"]),
            "critic": width(critic_shapes["critic"]),
            "actions": width(critic_shapes["actions"]),
            "rewards": width(critic_shapes["rewards"]),
            "next_obs": width(critic_shapes["next_obs"]),
            "next_critic": width(critic_shapes["next_critic"]),
            "dones": width(critic_shapes["dones"]),
            "truncated": width(critic_shapes["truncated"]),
        }
        offsets: dict[str, tuple[int, int]] = {}
        offset = 0
        for key in (
            "obs",
            "critic",
            "actions",
            "rewards",
            "next_obs",
            "next_critic",
            "dones",
            "truncated",
        ):
            key_width = widths[key]
            offsets[key] = (offset, key_width)
            offset += key_width
        return offsets

    @classmethod
    def _critic_graph_static_views_from_sac_packed(
        cls,
        packed: torch.Tensor,
        critic_shapes: dict[str, torch.Size],
        actor_shapes: dict[str, torch.Size],
    ) -> dict[str, torch.Tensor]:
        offsets = cls._sac_graph_offsets(actor_shapes, critic_shapes)
        views: dict[str, torch.Tensor] = {}
        for key in cls._critic_graph_input_keys():
            offset, width = offsets[key]
            views[key] = packed.narrow(1, offset, width).view(critic_shapes[key])
        return views

    @classmethod
    def _actor_graph_static_views_from_sac_packed(
        cls,
        packed: torch.Tensor,
        actor_shapes: dict[str, torch.Size],
    ) -> dict[str, torch.Tensor]:
        batch_size = int(actor_shapes["obs"][0])
        critic_shapes = {
            "critic": actor_shapes["critic"],
            "actions": torch.Size((batch_size, 0)),
            "rewards": torch.Size((batch_size,)),
            "next_obs": actor_shapes["obs"],
            "next_critic": actor_shapes["critic"],
            "dones": torch.Size((batch_size,)),
            "truncated": torch.Size((batch_size,)),
        }
        offsets = cls._sac_graph_offsets(actor_shapes, critic_shapes)
        views: dict[str, torch.Tensor] = {}
        for key in ("obs", "critic"):
            offset, width = offsets[key]
            views[key] = packed.narrow(1, offset, width).view(actor_shapes[key])
        return views

    def _copy_critic_graph_inputs(self, batch: Dict[str, torch.Tensor]) -> None:
        assert self._cuda_graph_critic_static_inputs is not None
        packed_source = batch.get("sac_graph_packed_source")
        if packed_source is not None and self._cuda_graph_sac_static_packed_input is not None:
            self._cuda_graph_sac_static_packed_input.copy_(packed_source)
            self._cuda_graph_sac_static_source_ptr = int(packed_source.data_ptr())
        else:
            self._cuda_graph_sac_static_source_ptr = None
            packed_source = batch.get("critic_graph_packed_source")
            if (
                packed_source is not None
                and self._cuda_graph_critic_static_packed_input is not None
            ):
                self._cuda_graph_critic_static_packed_input.copy_(packed_source)
            else:
                for key, tensor in self._cuda_graph_critic_static_inputs.items():
                    tensor.copy_(batch[key])
        assert self._cuda_graph_critic_action_noise is not None
        self._cuda_graph_critic_action_noise.normal_()

    def _copy_actor_graph_inputs(self, batch: Dict[str, torch.Tensor]) -> None:
        assert self._cuda_graph_actor_static_inputs is not None
        packed_source = batch.get("sac_graph_packed_source")
        if packed_source is not None:
            static_packed = self._cuda_graph_actor_static_packed_input
            if static_packed is None:
                static_packed = self._cuda_graph_sac_static_packed_input
            if static_packed is not None:
                source_ptr = int(packed_source.data_ptr())
                if (
                    static_packed is not self._cuda_graph_sac_static_packed_input
                    or self._cuda_graph_sac_static_source_ptr != source_ptr
                ):
                    static_packed.copy_(packed_source)
                    if static_packed is self._cuda_graph_sac_static_packed_input:
                        self._cuda_graph_sac_static_source_ptr = source_ptr
            else:
                for key, tensor in self._cuda_graph_actor_static_inputs.items():
                    tensor.copy_(batch[key])
        else:
            for key, tensor in self._cuda_graph_actor_static_inputs.items():
                tensor.copy_(batch[key])
        assert self._cuda_graph_actor_action_noise is not None
        self._cuda_graph_actor_action_noise.normal_()

    def _actor_graph_input_shapes(self, batch: Dict[str, torch.Tensor]) -> dict[str, torch.Size]:
        return {
            "obs": batch["obs"].shape,
            "critic": batch["critic"].shape,
        }

    def _materialize_capturable_critic_optimizer_state(
        self,
        batch: Dict[str, torch.Tensor],
    ) -> None:
        optimizer_lrs = [group["lr"] for group in self.q_optimizer.param_groups]
        optimizer_weight_decays = [group["weight_decay"] for group in self.q_optimizer.param_groups]
        alpha_lrs = [group["lr"] for group in self.alpha_optimizer.param_groups]
        cpu_rng_state = torch.random.get_rng_state()
        cuda_rng_state = torch.cuda.get_rng_state() if self._device_type == "cuda" else None
        try:
            for group in self.q_optimizer.param_groups:
                group["lr"] = 0.0
                group["weight_decay"] = 0.0
            for group in self.alpha_optimizer.param_groups:
                group["lr"] = 0.0
            self._update_critic_capture_candidate(
                batch["critic"],
                batch["actions"],
                batch["rewards"],
                batch["next_obs"],
                batch["next_critic"],
                batch["dones"],
                batch["truncated"],
            )
        finally:
            torch.random.set_rng_state(cpu_rng_state)
            if cuda_rng_state is not None:
                torch.cuda.set_rng_state(cuda_rng_state)
            for group, lr, weight_decay in zip(
                self.q_optimizer.param_groups,
                optimizer_lrs,
                optimizer_weight_decays,
                strict=True,
            ):
                group["lr"] = lr
                group["weight_decay"] = weight_decay
            for group, lr in zip(self.alpha_optimizer.param_groups, alpha_lrs, strict=True):
                group["lr"] = lr

        for optimizer in (self.q_optimizer, self.alpha_optimizer):
            optimizer.zero_grad(set_to_none=True)
            for state in optimizer.state.values():
                step = state.get("step")
                if isinstance(step, torch.Tensor):
                    step.zero_()
                elif step is not None:
                    state["step"] = 0
                for name in ("exp_avg", "exp_avg_sq", "max_exp_avg_sq"):
                    tensor = state.get(name)
                    if isinstance(tensor, torch.Tensor):
                        tensor.zero_()

    def _reset_critic_cuda_graph(self) -> None:
        graph = self._cuda_graph_critic
        self._cuda_graph_critic = None
        if isinstance(graph, torch.cuda.CUDAGraph):
            graph.reset()
        self._cuda_graph_critic_static_inputs = None
        self._cuda_graph_critic_static_packed_input = None
        self._cuda_graph_sac_static_packed_input = None
        self._cuda_graph_sac_static_source_ptr = None
        self._cuda_graph_critic_action_noise = None
        self._cuda_graph_critic_outputs = None
        self._cuda_graph_critic_shapes = None
        self._cuda_graph_critic_gradient_sync_calls = 0

    def _materialize_capturable_actor_optimizer_state(
        self,
        batch: Dict[str, torch.Tensor],
    ) -> None:
        optimizer_lrs = [group["lr"] for group in self.actor_optimizer.param_groups]
        optimizer_weight_decays = [
            group["weight_decay"] for group in self.actor_optimizer.param_groups
        ]
        cpu_rng_state = torch.random.get_rng_state()
        cuda_rng_state = torch.cuda.get_rng_state() if self._device_type == "cuda" else None
        try:
            for group in self.actor_optimizer.param_groups:
                group["lr"] = 0.0
                group["weight_decay"] = 0.0
            self._update_actor_capture_candidate(
                batch["obs"],
                batch["critic"],
            )
        finally:
            torch.random.set_rng_state(cpu_rng_state)
            if cuda_rng_state is not None:
                torch.cuda.set_rng_state(cuda_rng_state)
            for group, lr, weight_decay in zip(
                self.actor_optimizer.param_groups,
                optimizer_lrs,
                optimizer_weight_decays,
                strict=True,
            ):
                group["lr"] = lr
                group["weight_decay"] = weight_decay

        self.actor_optimizer.zero_grad(set_to_none=True)
        for state in self.actor_optimizer.state.values():
            step = state.get("step")
            if isinstance(step, torch.Tensor):
                step.zero_()
            elif step is not None:
                state["step"] = 0
            for name in ("exp_avg", "exp_avg_sq", "max_exp_avg_sq"):
                tensor = state.get(name)
                if isinstance(tensor, torch.Tensor):
                    tensor.zero_()

    def _reset_actor_cuda_graph(self) -> None:
        graph = self._cuda_graph_actor
        self._cuda_graph_actor = None
        if isinstance(graph, torch.cuda.CUDAGraph):
            graph.reset()
        self._cuda_graph_actor_static_inputs = None
        self._cuda_graph_actor_static_packed_input = None
        self._cuda_graph_actor_action_noise = None
        self._cuda_graph_actor_outputs = None
        self._cuda_graph_actor_shapes = None
        self._cuda_graph_actor_gradient_sync_calls = 0

    def _capture_actor_cuda_graph(self, batch: Dict[str, torch.Tensor]) -> None:
        if not self.use_cuda_graph_actor:
            return
        self._cuda_graph_actor_shapes = self._actor_graph_input_shapes(batch)
        if self.use_cuda_graph_actor_packed_staging and "sac_graph_packed_source" in batch:
            packed_source = batch["sac_graph_packed_source"]
            if (
                self._cuda_graph_sac_static_packed_input is not None
                and self._cuda_graph_sac_static_packed_input.shape == packed_source.shape
            ):
                self._cuda_graph_actor_static_packed_input = (
                    self._cuda_graph_sac_static_packed_input
                )
            else:
                self._cuda_graph_sac_static_packed_input = packed_source.detach().clone()
                self._cuda_graph_sac_static_source_ptr = None
                self._cuda_graph_actor_static_packed_input = (
                    self._cuda_graph_sac_static_packed_input
                )
            self._cuda_graph_actor_static_inputs = self._actor_graph_static_views_from_sac_packed(
                self._cuda_graph_actor_static_packed_input,
                self._cuda_graph_actor_shapes,
            )
        else:
            self._cuda_graph_actor_static_packed_input = None
            self._cuda_graph_actor_static_inputs = {
                "obs": batch["obs"].detach().clone(),
                "critic": batch["critic"].detach().clone(),
            }
        self._cuda_graph_actor_action_noise = torch.empty(
            batch["obs"].shape[:-1] + (self.actor.action_dim,),
            device=batch["obs"].device,
            dtype=batch["obs"].dtype,
        )
        self._copy_actor_graph_inputs(batch)

        graph = torch.cuda.CUDAGraph()
        capture_stream = cast(torch.cuda.Stream, torch.cuda.Stream())
        capture_stream.wait_stream(torch.cuda.current_stream())
        sync_calls = [0]
        self._active_cuda_graph_gradient_sync_calls = sync_calls
        try:
            with torch.cuda.stream(capture_stream), torch.cuda.graph(graph):
                self._cuda_graph_actor_outputs = self._update_actor_capture_candidate(
                    self._cuda_graph_actor_static_inputs["obs"],
                    self._cuda_graph_actor_static_inputs["critic"],
                )
        finally:
            self._active_cuda_graph_gradient_sync_calls = None
        torch.cuda.current_stream().wait_stream(capture_stream)
        torch.cuda.synchronize()
        self._cuda_graph_actor = graph
        self._cuda_graph_actor_gradient_sync_calls = sync_calls[0]

    def _actor_graph_output_metrics(self, *, read_items: bool = True) -> Dict[str, float]:
        if not read_items:
            return {}
        assert self._cuda_graph_actor_outputs is not None
        actor_loss, actor_grad_norm, policy_entropy, action_std = self._cuda_graph_actor_outputs
        return {
            "actor_loss": actor_loss.item(),
            "actor_grad_norm": actor_grad_norm.item(),
            "policy_entropy": policy_entropy.item(),
            "action_std": action_std.item(),
        }

    def _capture_critic_cuda_graph(self, batch: Dict[str, torch.Tensor]) -> None:
        if not self.use_cuda_graph_critic:
            return
        self._cuda_graph_critic_shapes = self._critic_graph_input_shapes(batch)
        if self.use_cuda_graph_critic_packed_staging and "sac_graph_packed_source" in batch:
            packed_source = batch["sac_graph_packed_source"]
            self._cuda_graph_sac_static_packed_input = packed_source.detach().clone()
            self._cuda_graph_critic_static_packed_input = None
            actor_shapes = self._actor_graph_input_shapes(batch)
            self._cuda_graph_critic_static_inputs = self._critic_graph_static_views_from_sac_packed(
                self._cuda_graph_sac_static_packed_input,
                self._cuda_graph_critic_shapes,
                actor_shapes,
            )
        elif self.use_cuda_graph_critic_packed_staging and "critic_graph_packed_source" in batch:
            packed_source = batch["critic_graph_packed_source"]
            self._cuda_graph_sac_static_packed_input = None
            self._cuda_graph_critic_static_packed_input = packed_source.detach().clone()
            self._cuda_graph_critic_static_inputs = self._critic_graph_static_views_from_packed(
                self._cuda_graph_critic_static_packed_input,
                self._cuda_graph_critic_shapes,
            )
        else:
            self._cuda_graph_sac_static_packed_input = None
            self._cuda_graph_critic_static_packed_input = None
            self._cuda_graph_critic_static_inputs = {
                "critic": batch["critic"].detach().clone(),
                "actions": batch["actions"].detach().clone(),
                "rewards": batch["rewards"].detach().clone(),
                "next_obs": batch["next_obs"].detach().clone(),
                "next_critic": batch["next_critic"].detach().clone(),
                "dones": batch["dones"].detach().clone(),
                "truncated": batch["truncated"].detach().clone(),
            }
        self._cuda_graph_critic_action_noise = torch.empty(
            batch["next_obs"].shape[:-1] + (batch["actions"].shape[-1],),
            device=batch["next_obs"].device,
            dtype=batch["next_obs"].dtype,
        )
        self._copy_critic_graph_inputs(batch)

        graph = torch.cuda.CUDAGraph()
        capture_stream = cast(torch.cuda.Stream, torch.cuda.Stream())
        capture_stream.wait_stream(torch.cuda.current_stream())
        sync_calls = [0]
        self._active_cuda_graph_gradient_sync_calls = sync_calls
        try:
            with torch.cuda.stream(capture_stream), torch.cuda.graph(graph):
                self._cuda_graph_critic_outputs = self._update_critic_capture_candidate(
                    self._cuda_graph_critic_static_inputs["critic"],
                    self._cuda_graph_critic_static_inputs["actions"],
                    self._cuda_graph_critic_static_inputs["rewards"],
                    self._cuda_graph_critic_static_inputs["next_obs"],
                    self._cuda_graph_critic_static_inputs["next_critic"],
                    self._cuda_graph_critic_static_inputs["dones"],
                    self._cuda_graph_critic_static_inputs["truncated"],
                )
        finally:
            self._active_cuda_graph_gradient_sync_calls = None
        torch.cuda.current_stream().wait_stream(capture_stream)
        torch.cuda.synchronize()
        self._cuda_graph_critic = graph
        self._cuda_graph_critic_gradient_sync_calls = sync_calls[0]

    def _critic_graph_output_metrics(self, *, read_items: bool = True) -> Dict[str, float]:
        if not read_items:
            return {}
        assert self._cuda_graph_critic_outputs is not None
        qf_loss, critic_grad_norm, target_q_max, target_q_min, alpha_loss, alpha = (
            self._cuda_graph_critic_outputs
        )
        return {
            "qf_loss": qf_loss.item(),
            "critic_grad_norm": critic_grad_norm.item(),
            "target_q_max": target_q_max.item(),
            "target_q_min": target_q_min.item(),
            "alpha_loss": alpha_loss.item(),
            "alpha": alpha.item(),
        }

    def update_critic_cuda_graph(
        self,
        batch: Dict[str, torch.Tensor],
        *,
        read_metrics: bool = True,
    ) -> Dict[str, float]:
        if not self.use_cuda_graph_critic:
            return self.update_critic(batch)
        if self._device_type != "cuda":
            return self.update_critic(batch)
        if self.scaler is not None:
            return self.update_critic(batch)
        if self._cuda_graph_critic_shapes != self._critic_graph_input_shapes(batch):
            self._reset_critic_cuda_graph()
            self._materialize_capturable_critic_optimizer_state(batch)
            self._capture_critic_cuda_graph(batch)
            with _cuda_nvtx_range(
                "critic_graph/output_metrics_item",
                self.nvtx_profile_ranges,
            ):
                return self._critic_graph_output_metrics(read_items=read_metrics)
        assert self._cuda_graph_critic is not None
        with _cuda_nvtx_range("critic_graph/copy_inputs", self.nvtx_profile_ranges):
            self._copy_critic_graph_inputs(batch)
        with _cuda_nvtx_range("critic_graph/replay", self.nvtx_profile_ranges):
            self._cuda_graph_critic.replay()
        self._record_cuda_graph_gradient_replay(self._cuda_graph_critic_gradient_sync_calls)
        with _cuda_nvtx_range("critic_graph/output_metrics_item", self.nvtx_profile_ranges):
            return self._critic_graph_output_metrics(read_items=read_metrics)

    def update_actor_cuda_graph(
        self,
        batch: Dict[str, torch.Tensor],
        *,
        read_metrics: bool = True,
    ) -> Dict[str, float]:
        if not self.use_cuda_graph_actor:
            return self.update_actor(batch)
        if self._device_type != "cuda":
            return self.update_actor(batch)
        if self.scaler is not None or self.use_symmetry:
            return self.update_actor(batch)
        if self._cuda_graph_actor_shapes != self._actor_graph_input_shapes(batch):
            self._reset_actor_cuda_graph()
            self._materialize_capturable_actor_optimizer_state(batch)
            self._capture_actor_cuda_graph(batch)
            with _cuda_nvtx_range(
                "actor_graph/output_metrics_item",
                self.nvtx_profile_ranges,
            ):
                return self._actor_graph_output_metrics(read_items=read_metrics)
        assert self._cuda_graph_actor is not None
        with _cuda_nvtx_range("actor_graph/copy_inputs", self.nvtx_profile_ranges):
            self._copy_actor_graph_inputs(batch)
        with _cuda_nvtx_range("actor_graph/replay", self.nvtx_profile_ranges):
            self._cuda_graph_actor.replay()
        self._record_cuda_graph_gradient_replay(self._cuda_graph_actor_gradient_sync_calls)
        with _cuda_nvtx_range("actor_graph/output_metrics_item", self.nvtx_profile_ranges):
            return self._actor_graph_output_metrics(read_items=read_metrics)

    def update_critic(self, batch: Dict[str, torch.Tensor]) -> Dict[str, float]:
        """One critic update step."""
        obs = batch["obs"]
        critic_obs = batch["critic"]
        actions = batch["actions"]
        rewards = batch["rewards"]
        next_obs = batch["next_obs"]
        critic_next_obs = batch["next_critic"]
        dones = batch["dones"]
        truncated = batch["truncated"]

        # Apply symmetry augmentation
        if self.use_symmetry:
            with _cuda_nvtx_range("critic/symmetry_augment", self.nvtx_profile_ranges):
                assert self.symmetry is not None
                with _cuda_nvtx_range("critic/symmetry_obs_actions", self.nvtx_profile_ranges):
                    obs, actions = self.symmetry.augment_obs_and_actions(
                        obs,
                        actions,
                        obs_group="obs",
                    )
                with _cuda_nvtx_range("critic/symmetry_next_obs", self.nvtx_profile_ranges):
                    next_obs = self.symmetry.augment_obs(
                        next_obs,
                        obs_group="obs",
                    )

                with _cuda_nvtx_range("critic/symmetry_critic_obs", self.nvtx_profile_ranges):
                    critic_obs = self.symmetry.augment_obs(
                        critic_obs,
                        obs_group="critic",
                    )
                with _cuda_nvtx_range("critic/symmetry_critic_next_obs", self.nvtx_profile_ranges):
                    critic_next_obs = self.symmetry.augment_obs(
                        critic_next_obs,
                        obs_group="critic",
                    )

                # Double the batch size for other tensors
                with _cuda_nvtx_range("critic/symmetry_aux_repeat", self.nvtx_profile_ranges):
                    rewards = rewards.repeat(2)
                    dones = dones.repeat(2)
                    truncated = truncated.repeat(2)

        self.normalize_obs(obs, update=True)
        next_obs = self.normalize_obs(next_obs, update=False)

        with _cuda_nvtx_range("critic/loss_compiled", self.nvtx_profile_ranges):
            qf_loss, target_q_max, target_q_min, next_log_probs = self._critic_loss_tensors(
                critic_obs,
                actions,
                rewards,
                next_obs,
                critic_next_obs,
                dones,
                truncated,
            )

        # Skip if NaN
        if torch.isfinite(qf_loss):
            self.q_optimizer.zero_grad(set_to_none=True)
            if self.scaler:
                with _cuda_nvtx_range("critic/backward", self.nvtx_profile_ranges):
                    self.scaler.scale(qf_loss).backward()
                self._sync_gradients(self.qnet.parameters())
                self.scaler.unscale_(self.q_optimizer)
                if self.max_grad_norm > 0:
                    with _cuda_nvtx_range("critic/grad_clip", self.nvtx_profile_ranges):
                        critic_grad_norm = torch.nn.utils.clip_grad_norm_(
                            self.qnet.parameters(), max_norm=self.max_grad_norm
                        )
                else:
                    critic_grad_norm = self._zero_metric
                with _cuda_nvtx_range("critic/q_optimizer_step", self.nvtx_profile_ranges):
                    self.scaler.step(self.q_optimizer)
                self.scaler.update()
            else:
                with _cuda_nvtx_range("critic/backward", self.nvtx_profile_ranges):
                    qf_loss.backward()
                self._sync_gradients(self.qnet.parameters())
                if self.max_grad_norm > 0:
                    with _cuda_nvtx_range("critic/grad_clip", self.nvtx_profile_ranges):
                        critic_grad_norm = torch.nn.utils.clip_grad_norm_(
                            self.qnet.parameters(), max_norm=self.max_grad_norm
                        )
                else:
                    critic_grad_norm = self._zero_metric
                with _cuda_nvtx_range("critic/q_optimizer_step", self.nvtx_profile_ranges):
                    self.q_optimizer.step()
        else:
            critic_grad_norm = self._zero_metric

        # Alpha loss (temperature update) - matching holosoma
        alpha_loss = self._zero_metric
        if self.use_autotune:
            with _cuda_nvtx_range("critic/alpha_update", self.nvtx_profile_ranges):
                self.alpha_optimizer.zero_grad(set_to_none=True)
                with _cuda_nvtx_range("critic/alpha_loss", self.nvtx_profile_ranges):
                    alpha_loss = self._alpha_loss_tensor(next_log_probs)
                if torch.isfinite(alpha_loss):
                    with _cuda_nvtx_range("critic/alpha_backward", self.nvtx_profile_ranges):
                        alpha_loss.backward()
                    self._sync_gradients((self.log_alpha,))
                    with _cuda_nvtx_range("critic/alpha_optimizer_step", self.nvtx_profile_ranges):
                        self.alpha_optimizer.step()

        return {
            "qf_loss": qf_loss.item(),
            "critic_grad_norm": critic_grad_norm.item(),
            "target_q_max": target_q_max.item(),
            "target_q_min": target_q_min.item(),
            "alpha_loss": alpha_loss.item(),
            "alpha": self.log_alpha.exp().item(),
        }

    def update_actor(self, batch: Dict[str, torch.Tensor]) -> Dict[str, float]:
        """One actor update step."""
        obs = batch["obs"]
        critic_obs = batch["critic"]

        # Apply symmetry augmentation
        if self.use_symmetry:
            with _cuda_nvtx_range("actor/symmetry_augment", self.nvtx_profile_ranges):
                assert self.symmetry is not None
                with _cuda_nvtx_range("actor/symmetry_obs", self.nvtx_profile_ranges):
                    obs = self.symmetry.augment_obs(obs, obs_group="obs")
                with _cuda_nvtx_range("actor/symmetry_critic_obs", self.nvtx_profile_ranges):
                    critic_obs = self.symmetry.augment_obs(critic_obs, obs_group="critic")

        obs = self.normalize_obs(obs, update=False)
        with _cuda_nvtx_range("actor/loss_compiled", self.nvtx_profile_ranges):
            actor_loss, policy_entropy, action_std = self._actor_loss_tensors(obs, critic_obs)

        # Skip if NaN
        if torch.isfinite(actor_loss):
            self.actor_optimizer.zero_grad(set_to_none=True)
            if self.scaler:
                with _cuda_nvtx_range("actor/backward", self.nvtx_profile_ranges):
                    self.scaler.scale(actor_loss).backward()
                self._sync_gradients(self.actor.parameters())
                self.scaler.unscale_(self.actor_optimizer)
                if self.max_grad_norm > 0:
                    with _cuda_nvtx_range("actor/grad_clip", self.nvtx_profile_ranges):
                        actor_grad_norm = torch.nn.utils.clip_grad_norm_(
                            self.actor.parameters(), max_norm=self.max_grad_norm
                        )
                else:
                    actor_grad_norm = self._zero_metric
                with _cuda_nvtx_range("actor/optimizer_step", self.nvtx_profile_ranges):
                    self.scaler.step(self.actor_optimizer)
                self.scaler.update()
            else:
                with _cuda_nvtx_range("actor/backward", self.nvtx_profile_ranges):
                    actor_loss.backward()
                self._sync_gradients(self.actor.parameters())
                if self.max_grad_norm > 0:
                    with _cuda_nvtx_range("actor/grad_clip", self.nvtx_profile_ranges):
                        actor_grad_norm = torch.nn.utils.clip_grad_norm_(
                            self.actor.parameters(), max_norm=self.max_grad_norm
                        )
                else:
                    actor_grad_norm = self._zero_metric
                with _cuda_nvtx_range("actor/optimizer_step", self.nvtx_profile_ranges):
                    self.actor_optimizer.step()
        else:
            actor_grad_norm = self._zero_metric

        return {
            "actor_loss": actor_loss.item(),
            "actor_grad_norm": actor_grad_norm.item(),
            "policy_entropy": policy_entropy.item(),
            "action_std": action_std.item(),
        }

    def soft_update_target(self) -> None:
        """Polyak-average update of the target Q-network."""
        with torch.no_grad():
            with _cuda_nvtx_range("target/soft_update_loop", self.nvtx_profile_ranges):
                target_params = cast(list[torch.Tensor], list(self.qnet_target.parameters()))
                source_params = cast(list[torch.Tensor], list(self.qnet.parameters()))
                try:
                    torch._foreach_mul_(target_params, 1.0 - self.tau)
                    torch._foreach_add_(target_params, source_params, alpha=self.tau)
                except RuntimeError:
                    for tgt, src in zip(target_params, source_params):
                        tgt.mul_(1.0 - self.tau).add_(src, alpha=self.tau)

    def set_gradient_sync(
        self,
        sync: Callable[[Iterable[torch.Tensor]], None] | None,
        *,
        graph_replay_recorder: Callable[[int], None] | None = None,
    ) -> None:
        """Attach the per-optimizer gradient collective used by multi-GPU DP."""
        if sync is None and graph_replay_recorder is not None:
            raise ValueError("graph_replay_recorder requires a gradient sync callback")
        if sync != self._gradient_sync:
            self._reset_critic_cuda_graph()
            self._reset_actor_cuda_graph()
        self._gradient_sync = sync
        self._gradient_sync_graph_replay_recorder = graph_replay_recorder
        self.dp_cuda_graph_gradient_sync = bool(
            sync is not None
            and (
                (self.use_cuda_graph_critic and self.scaler is None)
                or (self.use_cuda_graph_actor and self.scaler is None and not self.use_symmetry)
            )
        )

    def _sync_gradients(self, parameters: Iterable[torch.Tensor]) -> None:
        if self._gradient_sync is not None:
            self._gradient_sync(parameters)
            if self._active_cuda_graph_gradient_sync_calls is not None:
                self._active_cuda_graph_gradient_sync_calls[0] += 1

    def _record_cuda_graph_gradient_replay(self, collective_calls: int) -> None:
        if self._gradient_sync_graph_replay_recorder is not None and collective_calls > 0:
            self._gradient_sync_graph_replay_recorder(collective_calls)

    def release_cuda_graphs(self) -> None:
        """Release captured NCCL nodes before the process group is destroyed."""
        self._reset_critic_cuda_graph()
        self._reset_actor_cuda_graph()

    def dp_initial_sync_tensors(self) -> Dict[str, torch.Tensor]:
        """Model state broadcast once from rank 0 before collection starts.

        The values alias the parameter/buffer storage of ``actor``, ``qnet``
        and ``qnet_target`` (plus the ``log_alpha`` leaf) rather than copies,
        so startup broadcast updates the model in place. Optimizer state starts
        empty and remains aligned because every actual optimizer update uses
        the same cross-rank mean gradient.
        """
        tensors: Dict[str, torch.Tensor] = {}
        for prefix, module in (
            ("actor", self.actor),
            ("qnet", self.qnet),
            ("qnet_target", self.qnet_target),
        ):
            for key, value in module.state_dict().items():
                tensors[f"{prefix}.{key}"] = value
        tensors["log_alpha"] = self.log_alpha
        return tensors

    def get_state_dict(self) -> Dict[str, Any]:
        """Save all components."""
        return {
            "actor": self.actor.state_dict(),
            "qnet": self.qnet.state_dict(),
            "qnet_target": self.qnet_target.state_dict(),
            "log_alpha": self.log_alpha.detach().cpu(),
            "actor_optimizer": self.actor_optimizer.state_dict(),
            "q_optimizer": self.q_optimizer.state_dict(),
            "alpha_optimizer": self.alpha_optimizer.state_dict(),
            "obs_normalizer": (
                self.obs_normalizer.state_dict()
                if hasattr(self.obs_normalizer, "state_dict")
                else None
            ),
            "update_count": self.update_count,
        }

    def load_state_dict(self, state_dict: Dict) -> None:
        """Load all components."""
        self.actor.load_state_dict(state_dict["actor"])
        self.qnet.load_state_dict(state_dict["qnet"])
        self.qnet_target.load_state_dict(state_dict["qnet_target"])
        self.log_alpha.data.copy_(state_dict["log_alpha"].to(self.device))
        self.actor_optimizer.load_state_dict(state_dict["actor_optimizer"])
        self.q_optimizer.load_state_dict(state_dict["q_optimizer"])
        self.alpha_optimizer.load_state_dict(state_dict["alpha_optimizer"])
        if state_dict.get("obs_normalizer") and hasattr(self.obs_normalizer, "load_state_dict"):
            self.obs_normalizer.load_state_dict(state_dict["obs_normalizer"])
        self.update_count = state_dict.get("update_count", 0)
        self._reset_critic_cuda_graph()
        self._reset_actor_cuda_graph()


# ---------------------------------------------------------------------------
