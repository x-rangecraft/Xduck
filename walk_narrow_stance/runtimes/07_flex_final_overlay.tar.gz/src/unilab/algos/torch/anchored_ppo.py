"""Single-GPU PPO with a frozen actor normalizer and successful-state teacher anchoring."""
import numpy as np,torch
from .rsl_rl_ppo import FinalObservationAwarePPO

class AnchoredPPO(FinalObservationAwarePPO):
    def __init__(self,*args,anchor_dataset=None,anchor_weight=0.,anchor_batch_size=512,fixed_learning_rate=5e-6,**kwargs):
        super().__init__(*args,**kwargs)
        if self.is_multi_gpu or self.enable_compile:raise ValueError('This experiment is validated for single GPU/eager PPO only')
        self.anchor_weight=float(anchor_weight);self.anchor_batch_size=int(anchor_batch_size);self.fixed_learning_rate=float(fixed_learning_rate)
        self.anchor_sum=0.;self.anchor_count=0
        self.anchor_generator=torch.Generator(device=self.device);self.anchor_generator.manual_seed(1009280)
        if self.anchor_weight:
            with np.load(anchor_dataset) as z:
                self.anchor_obs=torch.tensor(z['obs'],device=self.device,dtype=torch.float32)
                self.anchor_mean=torch.tensor(z['mean'],device=self.device,dtype=torch.float32)
                self.anchor_std=torch.tensor(z['std'],device=self.device,dtype=torch.float32)
            assert self.anchor_obs.shape[1]==61 and self.anchor_mean.shape[1]==14 and len(self.anchor_obs)>100
        self.optimizer.register_step_pre_hook(self._anchor_before_step)
    def train_mode(self):
        super().train_mode();self.actor.obs_normalizer.eval()
    def load(self,loaded_dict,load_cfg=None,strict=True):
        result=super().load(loaded_dict,load_cfg,strict)
        self.learning_rate=self.fixed_learning_rate
        for group in self.optimizer.param_groups:group['lr']=self.fixed_learning_rate
        self.actor.obs_normalizer.eval()
        return result
    @torch.enable_grad()
    def _anchor_before_step(self,optimizer,args,kwargs):
        if not self.anchor_weight:return
        idx=torch.randint(len(self.anchor_obs),(self.anchor_batch_size,),generator=self.anchor_generator,device=self.device)
        # Direct normalization/MLP evaluation avoids touching the PPO action distribution cache.
        mu=self.actor.mlp(self.actor.obs_normalizer(self.anchor_obs[idx]))
        sigma=self.actor.distribution.std_param.clamp_min(1e-5).expand_as(mu)
        teacher_mean=self.anchor_mean[idx];teacher_std=self.anchor_std.expand_as(mu)
        kl=(torch.log(sigma/teacher_std)+(teacher_std.square()+(teacher_mean-mu).square())/(2*sigma.square())-.5).mean()
        (self.anchor_weight*kl).backward()
        # PPO has already clipped its gradients; clip again after adding the anchor gradient.
        torch.nn.utils.clip_grad_norm_(self.actor.parameters(),self.max_grad_norm)
        self.anchor_sum+=float(kl.detach());self.anchor_count+=1
    def update(self):
        self.actor.obs_normalizer.eval();self.learning_rate=self.fixed_learning_rate
        for group in self.optimizer.param_groups:group['lr']=self.fixed_learning_rate
        self.anchor_sum=0.;self.anchor_count=0
        result=super().update();result['teacher_anchor_kl']=self.anchor_sum/max(1,self.anchor_count)
        return result
