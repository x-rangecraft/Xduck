"""Natural-width gait owner; preserve the user's accepted older gait."""
from dataclasses import dataclass
import numpy as np
from unilab.base import registry
from .new_stand_smooth import NewStandSmoothCfg,NewStandSmoothEnv
from .startup_flex import rotate
@registry.envcfg('XDuckNaturalGait')
@dataclass
class NaturalGaitCfg(NewStandSmoothCfg):
    smooth_width_target_m: float=.212
    smooth_width_weight: float=3.
    smooth_height_weight: float=0.
    smooth_vertical_weight: float=1.
    smooth_acceleration_weight: float=1.
    natural_peak_m: float=.03
    natural_cycle_seconds: float=.56
    natural_forward_swing_m: float=.15
    natural_progress_weight: float=6.
    natural_swing_progress_weight: float=2.
    natural_stall_after_seconds: float=2.5
@registry.env('XDuckNaturalGait',sim_backend='mjwarp')
class NaturalGaitEnv(NewStandSmoothEnv):
    def __init__(self,cfg,num_envs=1,backend_type='mjwarp'):
        self._natural_last_landing=np.full((num_envs,2),-1.,float)
        self._natural_mean_v=np.zeros(num_envs)
        self._natural_last_position=np.zeros((num_envs,2,3))
        self._natural_last_axis=np.zeros((num_envs,2,3))
        self._natural_last_full=np.full(num_envs,-1.)
        self._natural_stall_at=np.full(num_envs,2.5)
        super().__init__(cfg,num_envs=num_envs,backend_type=backend_type)
    def _reset_episode_history(self,ids):
        super()._reset_episode_history(ids)
        self._natural_last_landing[ids]=-1
        self._natural_mean_v[ids]=0
        self._natural_last_full[ids]=-1.
        self._natural_stall_at[ids]=self._newstand_rng.uniform(2.,3.,len(ids))
    def _compute_reward(self,state,linvel,gyro,upvector,dof_pos):
        air=self._smooth_air.copy();peak=self._smooth_peak.copy()
        age=self._smooth_age*self.cfg.ctrl_dt
        reward=super()._compute_reward(state,linvel,gyro,upvector,dof_pos)
        h=self._foot_height;landing=air&(h<.0007)
        peak=np.maximum(peak,h)
        pos,quat=self._backend.get_body_pose_w(self._smooth_body_ids)
        world=pos+rotate(quat,np.broadcast_to(self._smooth_site_local,pos.shape))
        advance=np.sum((world-self._smooth_liftoff)*self._smooth_axis,axis=2)
        forward_axis=rotate(self._backend.get_base_quat(),np.broadcast_to([1.,0,0],(self.num_envs,3)))
        full_stride=np.sum((world-self._natural_last_position)*self._natural_last_axis,axis=2)
        known=self._natural_last_landing>=0
        proper=landing&(peak>=.022)&((~known)|(full_stride>=.06))
        amplitude=np.exp(-((peak-self.cfg.natural_peak_m)/.008)**2)
        stride=np.exp(-((full_stride-self.cfg.natural_forward_swing_m)/.05)**2)*known
        interval=age[:,None]-self._natural_last_landing
        known=self._natural_last_landing>=0
        timing=np.exp(-((interval-self.cfg.natural_cycle_seconds)/.10)**2)
        # Cancel the early completion bonus inherited from the previous owner;
        # a small fast shuffle should not earn a full-step completion reward.
        old_proper=landing&(peak>=.012)&(advance>=.015)
        shallow=landing&(peak<.009)
        previous_bonus=(.8*old_proper.sum(1)-.6*shallow.sum(1))*(age<self.cfg.smooth_start_seconds)
        style=(proper*(2*amplitude+stride+timing*known-2*(1-timing)*known)).sum(1)
        short_cost=(landing*((peak<.022)|(known&(full_stride<.06)))).sum(1)*.8
        forward=np.clip(linvel[:,0],-.15,.35)-np.abs(linvel[:,1])
        swing=np.minimum(h.max(1)/self.cfg.natural_peak_m,1.)*((h>.003).sum(1)==1)
        density=self.cfg.natural_progress_weight*forward+self.cfg.natural_swing_progress_weight*swing
        self._natural_mean_v=.95*self._natural_mean_v+.05*linvel[:,0]
        reward=reward+(style-short_cost-previous_bonus+density*self.cfg.ctrl_dt).astype(reward.dtype)
        self._natural_last_full[proper.any(1)]=age[proper.any(1)]
        self._natural_last_landing[landing]=np.broadcast_to(age[:,None],landing.shape)[landing]
        self._natural_last_position[landing]=world[landing]
        self._natural_last_axis[landing]=np.broadcast_to(forward_axis[:,None,:],world.shape)[landing]
        state.info.setdefault('log',{}).update({'natural/proper_fraction':float(proper.any(1).mean()),'natural/style_reward':float(style.mean())})
        return reward

    def update_state(self,state):
        result=super().update_state(state)
        age=self._smooth_age*self.cfg.ctrl_dt
        latest=self._natural_last_full
        stalled=(age>self._natural_stall_at)&((self._natural_mean_v<.06)|(latest<0)|((age-latest)>1.2))
        newly=stalled&(~result.terminated)
        return result.replace(terminated=result.terminated|stalled,reward=result.reward-(5.*newly).astype(result.reward.dtype))
