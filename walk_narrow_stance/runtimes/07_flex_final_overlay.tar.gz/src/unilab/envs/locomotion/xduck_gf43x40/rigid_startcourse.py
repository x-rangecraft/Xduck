"""Isolated rigid experiment: command-start curriculum and reward ablations."""
from dataclasses import dataclass
import numpy as np
from unilab.base import registry
from .startup_flex import StartupFlexCfg,StartupFlexEnv
from .rigid_gpu import StagedSoleTiltReset

def reward_delta(gyro,command,rate_cost,angular_weight,angular_std,old_rate_weight,yaw_only,moving_rate_weight):
 moving=(np.linalg.norm(command[:,:2],axis=1)+abs(command[:,2]))>.01
 yaw_error=gyro[:,2]-command[:,2]
 angular=np.zeros(len(command))
 if yaw_only:
  old=np.exp(-(np.sum(gyro[:,:2]**2,axis=1)+yaw_error**2)/angular_std**2)
  new=np.exp(-yaw_error**2/angular_std**2)
  angular=angular_weight*(new-old)
 rate=np.zeros(len(command)) if moving_rate_weight is None else (moving_rate_weight-old_rate_weight)*rate_cost*moving
 return angular,rate

@registry.envcfg('XDuckRigidStartCourse')
@dataclass
class RigidStartCourseCfg(StartupFlexCfg):
 start_course_enabled: bool=True
 start_course_fraction: float=.4
 start_course_seed: int=10091280
 yaw_only_tracking: bool=False
 moving_action_rate_weight: float|None=None

@registry.env('XDuckRigidStartCourse',sim_backend='mjwarp')
class RigidStartCourseEnv(StartupFlexEnv):
 def __init__(self,cfg,num_envs=1,backend_type='mjwarp'):
  self._course_rng=np.random.default_rng(cfg.start_course_seed)
  self._course_held=np.zeros(num_envs,bool);self._course_release=np.zeros(num_envs,int)
  self._course_goal=np.zeros((num_envs,13));self._course_ramp=np.zeros(num_envs,bool)
  super().__init__(cfg,num_envs=num_envs,backend_type=backend_type)
  assert len(self._passive_qpos_indices)==0 and not cfg.flexible_dr_enabled and cfg.physics_microsteps==1
 def _make_dr_provider(self):
  return StartCourseReset() if self._cfg.start_course_enabled else StagedSoleTiltReset()
 def _maybe_resample_commands(self,state):
  super()._maybe_resample_commands(state)
  if not self._cfg.start_course_enabled:return
  age=self.step_counter-self._course_release
  held=self._course_held&(age<300)
  factor=np.where(age<0,0.,np.where(self._course_ramp,1-.8**(np.maximum(age,0)+1),1.))
  state.info['commands'][held]=self._course_goal[held]*factor[held,None]
  self._course_held[self._course_held&(~held)]=False
 def _compute_reward(self,state,linvel,gyro,upvector,dof_pos):
  reward=super()._compute_reward(state,linvel,gyro,upvector,dof_pos)
  cfg=self._cfg;rc=cfg.reward_config
  angular,rate=reward_delta(gyro,state.info['commands'],self._action_rate_cost(state),rc.scales['track_angular_velocity'],rc.angular_velocity_std,rc.scales['action_rate_l2'],cfg.yaw_only_tracking,cfg.moving_action_rate_weight)
  dt=cfg.ctrl_dt
  self._episode_reward_sums['track_angular_velocity']+=angular*dt
  self._episode_reward_sums['action_rate_l2']+=rate*dt
  state.info.setdefault('log',{}).update({'startcourse/angular_delta':float(angular.mean()),'startcourse/action_rate_delta':float(rate.mean()),'startcourse/wait_fraction':float((self._course_held&(self.step_counter<self._course_release)).mean())})
  return reward+((angular+rate)*dt).astype(reward.dtype)

class StartCourseReset(StagedSoleTiltReset):
 def build_reset_plan(self,env,env_ids):
  plan=super().build_reset_plan(env,env_ids);ids=np.asarray(env_ids,dtype=int);n=len(ids);rng=env._course_rng
  held=rng.random(n)<env._cfg.start_course_fraction
  goal=plan.info_updates['commands'].copy()
  forward=held&(rng.random(n)<.75);v=rng.uniform(.15,.35,n);v[rng.random(n)<.5]=.3
  goal[forward,:3]=np.c_[v[forward],np.zeros((forward.sum(),2))]
  goal[held,3:]=0.
  env._course_held[ids]=held;env._course_goal[ids]=goal
  env._course_release[ids]=env.step_counter+rng.integers(50,151,n)
  env._course_ramp[ids]=rng.random(n)<.5
  plan.info_updates['commands'][held]=0.
  return plan
