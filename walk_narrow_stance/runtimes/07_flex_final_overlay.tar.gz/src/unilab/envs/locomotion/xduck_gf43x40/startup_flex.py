"""Experiment owner: startup reset curriculum, stall objective and foot heading."""
from dataclasses import dataclass
import mujoco,numpy as np
from unilab.base import registry
from unilab.utils.rotation import np_quat_mul
from .rigid_gpu import HistoricalRigidCfg,HistoricalRigidEnv,StagedSoleTiltReset
from .startup_tracker import StartupTracker

def rotate(q,v):
    return v+2*np.cross(q[...,1:],np.cross(q[...,1:],v)+q[...,:1]*v)

@registry.envcfg('XDuckStartupFlex')
@dataclass
class StartupFlexCfg(HistoricalRigidCfg):
    startup_training: bool=False
    startup_reward: bool=False
    toe_heading_reward: bool=False
    startup_bank_path: str|None=None
    startup_start_update: int=1280
    startup_ramp_updates: int=10
    startup_seed: int=9301280
    startup_initial_step: int=30720
    toe_heading_weight: float=.4
    toe_heading_deadband_deg: float=3.
    toe_heading_std_deg: float=8.

@registry.env('XDuckStartupFlex',sim_backend='mjwarp')
class StartupFlexEnv(HistoricalRigidEnv):
    def __init__(self,cfg,num_envs=1,backend_type='mjwarp'):
        self._startup_rng=np.random.default_rng(cfg.startup_seed)
        self._startup_tracker=StartupTracker(num_envs,cfg.ctrl_dt)
        self._startup_kind=np.zeros(num_envs,int);self._startup_release=np.zeros(num_envs,int)
        self._startup_goal=np.zeros((num_envs,13));self._startup_smooth=np.zeros(num_envs,bool)
        self._startup_failed=np.zeros(num_envs,bool);self._startup_push=np.full(num_envs,-1,int)
        self._foot_heading=np.zeros((num_envs,2))
        m=mujoco.MjModel.from_xml_path(cfg.scene.model_file);d=mujoco.MjData(m)
        mujoco.mj_resetDataKeyframe(m,d,m.key('STAND').id);mujoco.mj_forward(m,d)
        self._heading_axes=np.array([d.xmat[m.geom(side+'_foot_collision').bodyid[0]].reshape(3,3).T@d.xmat[1].reshape(3,3)[:,0] for side in ['left','right']])
        super().__init__(cfg,num_envs=num_envs,backend_type=backend_type)
        self._startup_original_imu=self._imu_rotation.copy();self._startup_original_bias=self._encoder_bias.copy()
        self._startup_bank=None
        if cfg.startup_training:
            if cfg.startup_bank_path is None:raise ValueError('Startup reset bank required')
            with np.load(cfg.startup_bank_path) as z:self._startup_bank={k:z[k].copy() for k in z.files}
        self.step_counter=cfg.startup_initial_step
        self._next_push_step+=cfg.startup_initial_step
        self._apply_stage_schedule()
    def _make_dr_provider(self):
        return StartupReset() if self._cfg.startup_training else StagedSoleTiltReset()
    def _reset_episode_history(self,ids):
        super()._reset_episode_history(ids)
        self._startup_tracker.reset(ids);self._startup_failed[ids]=False;self._startup_push[ids]=-1
    def _refresh_foot_height(self):
        super()._refresh_foot_height()
        _,q=self._backend.get_body_pose_w(self._sole_body_ids)
        vectors=rotate(q,np.broadcast_to(self._heading_axes,q.shape[:-1]+(3,)))
        w,x,y,z=self._backend.get_base_quat().T;yaw=np.arctan2(2*(w*z+x*y),1-2*(y*y+z*z))
        angle=np.arctan2(vectors[:,:,1],vectors[:,:,0])-yaw[:,None]
        self._foot_heading[:]=np.arctan2(np.sin(angle),np.cos(angle))
    def _maybe_resample_commands(self,state):
        super()._maybe_resample_commands(state)
        if not self._cfg.startup_training:return
        held=(self._startup_kind>0)&(self.step_counter<self._startup_release+300)
        age=self.step_counter-self._startup_release
        factor=np.where(age<0,0.,np.where(self._startup_smooth,1-.8**(np.maximum(age,0)+1),1.))
        state.info['commands'][held]=self._startup_goal[held]*factor[held,None]
        self._startup_kind[(self._startup_kind>0)&(~held)]=0
    def _compute_reward(self,state,linvel,gyro,upvector,dof_pos):
        reward=super()._compute_reward(state,linvel,gyro,upvector,dof_pos)
        cfg=self._cfg
        if not (cfg.startup_reward or cfg.toe_heading_reward):return reward
        alpha=np.clip((self.step_counter/cfg.rollout_steps-cfg.startup_start_update)/cfg.startup_ramp_updates,0,1)
        command=state.info['commands'];delta=np.zeros(self.num_envs);log=state.info.setdefault('log',{})
        if cfg.startup_reward:
            pushed=(self._startup_push>=0)&(self._startup_push!=self._next_push_step);self._startup_push[:]=self._next_push_step
            progress,success,bad,failed=self._startup_tracker.update(command,linvel,self._contact,self._landed_air_time,pushed)
            self._startup_failed[:]=failed&(alpha>=.5)
            fall=upvector[:,2]<np.cos(np.deg2rad(70.))
            delta+=(progress-.3*bad)*cfg.ctrl_dt+.25*success-(self._startup_failed|fall).astype(float)
            log['startup/stall_fraction']=float(bad.mean());log['startup/success_event_fraction']=float(success.mean());log['startup/failure_fraction']=float(self._startup_failed.mean())
        if cfg.toe_heading_reward:
            straight=(command[:,0]>.05)&(abs(command[:,1])<.05)&(abs(command[:,2])<.1)
            error=np.maximum(np.abs(self._foot_heading)-np.deg2rad(cfg.toe_heading_deadband_deg),0.)
            cost=np.minimum(np.mean((error/np.deg2rad(cfg.toe_heading_std_deg))**2,axis=1),4.)*straight
            delta-=cfg.toe_heading_weight*cost*cfg.ctrl_dt
            log['startup/toe_heading_abs_deg']=float(np.degrees(np.abs(self._foot_heading[straight])).mean()) if straight.any() else 0.
        log['startup/reward_alpha']=float(alpha)
        return reward+(alpha*delta).astype(reward.dtype)
    def update_state(self,state):
        result=super().update_state(state)
        if self._cfg.startup_reward:result=result.replace(terminated=result.terminated|self._startup_failed)
        return result

class StartupReset(StagedSoleTiltReset):
    def build_reset_plan(self,env,env_ids):
        ids=np.asarray(env_ids,dtype=int);rng=env._startup_rng;bank=env._startup_bank
        env._imu_rotation[ids]=env._startup_original_imu[ids];env._encoder_bias[ids]=env._startup_original_bias[ids]
        plan=super().build_reset_plan(env,ids)
        kind=rng.choice(4,len(ids),p=[.4,.2,.2,.2]);env._startup_kind[ids]=kind
        goal=plan.info_updates['commands'].copy();goal[kind>0,3:]=0
        focus=(kind>0)&(rng.random(len(ids))<.75)
        v=rng.uniform(.15,.35,len(ids));v[rng.random(len(ids))<.5]=.3
        goal[focus,:3]=np.c_[v[focus],np.zeros((focus.sum(),2))]
        env._startup_goal[ids]=goal
        delay=np.where(kind==1,rng.integers(150,251,len(ids)),0)
        env._startup_release[ids]=env.step_counter+delay;env._startup_smooth[ids]=rng.random(len(ids))<.5
        bankrows=np.flatnonzero(kind>=2)
        if len(bankrows):
            chosen=np.array([rng.choice(np.flatnonzero(bank['kind']==(0 if kind[j]==2 else 1))) for j in bankrows])
            selected=ids[bankrows]
            plan.qpos[bankrows]=bank['qpos'][chosen];plan.qvel[bankrows]=bank['qvel'][chosen]
            # Half retain the measured bank state; half perturb its neighbourhood.
            perturb=rng.random(len(bankrows))<.5
            q=plan.qpos[bankrows].copy();q[:,env._policy_qpos_indices]+=rng.normal(0,.008,(len(bankrows),14))*perturb[:,None]
            q[:,env._policy_qpos_indices]=np.clip(q[:,env._policy_qpos_indices],env._target_low,env._target_high)
            q[:,2]+=.003*perturb;plan.qpos[bankrows]=q
            for key in ['body_ipos','body_mass','body_inertia','geom_friction','geom_pos','geom_quat','dof_armature','jnt_stiffness','dof_damping']:
                target=getattr(plan.randomization,key)
                if target is None:raise RuntimeError(f'Missing reset field {key}')
                target[bankrows]=bank[key][chosen]
            for key,columns,nominal in [('jnt_stiffness',env._flex_joint_ids,env._nominal_flex_stiffness),('dof_damping',env._flex_dof_ids,env._nominal_flex_damping)]:
                target=getattr(plan.randomization,key);values=target[bankrows[:,None],columns[None,:]]
                values*=1+rng.uniform(-.02,.02,values.shape)*perturb[:,None]
                target[bankrows[:,None],columns[None,:]]=np.clip(values,.9*nominal[columns],1.1*nominal[columns])
            env._encoder_bias[selected]=bank['encoder_bias'][chosen];env._imu_rotation[selected]=bank['imu_rotation'][chosen]
            # A small rotation about the existing calibration axis stays in the original 0–6 degree range.
            axis=bank['imu_axis'][chosen];angle=np.clip(bank['imu_angle'][chosen]+rng.uniform(-np.deg2rad(.5),np.deg2rad(.5),len(chosen))*perturb,0,np.deg2rad(6))
            K=np.zeros((len(chosen),3,3));K[:,0,1]=-axis[:,2];K[:,0,2]=axis[:,1];K[:,1,0]=axis[:,2];K[:,1,2]=-axis[:,0];K[:,2,0]=-axis[:,1];K[:,2,1]=axis[:,0]
            env._imu_rotation[selected]=np.eye(3)+np.sin(angle)[:,None,None]*K+(1-np.cos(angle))[:,None,None]*(K@K)
            angles=bank['sole_angles'][chosen]+rng.uniform(-np.deg2rad(.3),np.deg2rad(.3),(len(chosen),2))*perturb[:,None]
            angles=np.clip(angles,-np.deg2rad(3),np.deg2rad(3));env._sole_angles[selected]=angles
            for j,g in enumerate(env._sole_geom_ids):
                dq=np.c_[np.cos(angles[:,j]/2),np.sin(angles[:,j]/2)[:,None]*env._sole_axes[j]]
                env._sole_delta_quat[selected,j]=dq
                plan.randomization.geom_pos[bankrows,g]=rotate(dq,np.broadcast_to(env._nominal_geom_pos[g],(len(chosen),3)))
                plan.randomization.geom_quat[bankrows,g]=np_quat_mul(dq,np.broadcast_to(env._nominal_geom_quat[g],dq.shape))
            raw=bank['last_raw_walk_units'][chosen]
            plan.info_updates['last_actions'][bankrows]=raw;plan.info_updates['current_actions'][bankrows]=raw
            target=np.clip(env.default_angles+raw*env._physical_scales,env._target_low,env._target_high)
            env._current_action_target[selected]=target;env._previous_action_target[selected]=target
        factor=np.where(delay>0,0.,np.where(env._startup_smooth[ids],.2,1.))
        special=kind>0;plan.info_updates['commands'][special]=goal[special]*factor[special,None]
        env._spawn.record_episode_start(ids,plan.qpos[:,:3])
        plan.info_updates['startup_kind']=kind.copy()
        return plan
