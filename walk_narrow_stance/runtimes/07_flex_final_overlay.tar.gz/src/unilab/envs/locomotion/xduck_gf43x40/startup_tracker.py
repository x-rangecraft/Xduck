"""Reward-only startup tracking, with no policy observation or action changes."""
import numpy as np

class StartupTracker:
    def __init__(self,n,dt=.02):
        self.dt=dt;self.n=n
        self.age=np.zeros(n);self.progress=np.zeros(n);self.speed=np.zeros(n)
        self.stall=np.zeros(n);self.active=np.zeros(n,bool);self.succeeded=np.zeros(n,bool)
        self.ref=np.zeros((n,2));self.previous_contact=np.zeros((n,2),bool)
        self.last_side=np.full(n,-1,int);self.alternations=np.zeros(n,int)
        self.since_alt=np.full(n,1e6);self.since_push=np.full(n,1e6)
    def reset(self,ids):
        for x in [self.age,self.progress,self.speed,self.stall,self.alternations]:x[ids]=0
        self.active[ids]=False;self.succeeded[ids]=False;self.ref[ids]=0
        self.previous_contact[ids]=False;self.last_side[ids]=-1
        self.since_alt[ids]=1e6;self.since_push[ids]=1e6
    def update(self,cmd,velocity,contact,landed_air,pushed):
        magnitude=np.linalg.norm(cmd[:,:2],axis=1);active=magnitude>=.05
        refnorm=np.linalg.norm(self.ref,axis=1)
        dot=(cmd[:,:2]*self.ref).sum(1)/np.maximum(magnitude*refnorm,1e-9)
        changed=active&((~self.active)|(dot<.5)|(np.abs(magnitude-refnorm)>.15))
        push_age=self.since_push.copy()
        self.reset(np.flatnonzero(changed|(~active)))
        self.since_push[:]=push_age
        self.ref[changed]=cmd[changed,:2];self.active[:]=active
        direction=cmd[:,:2]/np.maximum(magnitude[:,None],1e-9)
        along=(velocity[:,:2]*direction).sum(1)
        self.age+=active*self.dt;self.progress+=along*active*self.dt
        self.speed+=(1-np.exp(-self.dt/.5))*(along-self.speed)
        self.since_alt+=self.dt;self.since_push+=self.dt;self.since_push[pushed]=0
        touch=contact&(~self.previous_contact)&(landed_air>=.08)
        single_touch=touch.sum(1)==1;side=touch.argmax(1)
        alternating=single_touch&(self.last_side>=0)&(side!=self.last_side)&active
        self.alternations+=alternating;self.since_alt[alternating]=0
        self.last_side[single_touch]=side[single_touch];self.previous_contact[:]=contact
        success=active&(~self.succeeded)&(self.progress>=.04)&(self.alternations>=2)&(self.since_push>1.5)
        self.succeeded|=success
        # Both meaningful progression and recent alternating landings are needed.
        bad=active&(self.age>2.)&((self.speed<.02)|(self.since_alt>1.))&(self.since_push>1.5)
        self.stall=np.where(bad,self.stall+self.dt,0.)
        failed=self.stall>=1.5
        progress_bonus=.4*np.clip(self.speed/.08,0.,1.)*active*(self.age<5.)*(self.since_push>1.5)
        return progress_bonus,success,bad,failed
